(function ($) {
	function RemoteDataView(options) {
		var self = this,
			idProperty = options.idProperty || 'id',
			filterArgs,
			sortAsc = options.sortAsc || true,
			sortField = options.sortField || idProperty,
			rows = [],
			request,
			rowsById,
			extendItems = options.extendItems || $.noop,

			// pagination
			pagesize = 0,
			pagenum = 0,
			totalRows = 0,

			// events
			onRowCountChanged = new Slick.Event(),
			onRowsChanged = new Slick.Event(),
			onPagingInfoChanged = new Slick.Event();

		function setFilterArgs(args) {
			filterArgs = args;
		}

		function getItems() {
			return { length: totalRows };
		}

		function requestItems() {
			request && request.abort && request.abort();
			request = $.getJSON(options.requestFilteredAndPagedItems, {
				filtering: filterArgs,
				sorting: { sortField: sortField, ascending: sortAsc },
				paging: { pagesize: pagesize, pagenum: pagenum }
			});
			return request;
		}

		function fastSort(field, ascending) {
			sortField = field;
			sortAsc = ascending;

			refresh();
		}

		function refresh() {
			var countBefore = rows.length;
			var totalRowsBefore = totalRows;

			requestItems()
				.done(function (page) {
					if (!page || !('totalRows' in page) || !('rows' in page)) return;
					invalidateCache();
					extendItems(page.rows);

					totalRows = page.totalRows;
					rows = page.rows;

					var paging = getPagingInfo();
					if (paging.totalPages <= paging.pageNum) //not avalable page
						return setPagingOptions(paging); //get avalable page
					
					if (totalRowsBefore != page.totalRows)
						onPagingInfoChanged.notify(getPagingInfo(), null, self);

					if (countBefore != page.rows.length)
						onRowCountChanged.notify({ previous: countBefore, current: rows.length }, null, self);

					onRowsChanged.notify({ rows: rows }, null, self);
				});
		}

		function invalidateCache() {
			rowsById = undefined;
		}

		function setPagingOptions(args) {
			if (args.pageSize != undefined) {
				pagesize = args.pageSize;
				pagenum = pagesize ? Math.min(pagenum, Math.max(0, Math.ceil(totalRows / pagesize) - 1)) : 0;
			}

			if (args.pageNum != undefined) {
				pagenum = Math.min(args.pageNum, Math.max(0, Math.ceil(totalRows / pagesize) - 1));
			}

			onPagingInfoChanged.notify(getPagingInfo(), null, self);

			refresh();
		}

		function getPagingInfo() {
			var totalPages = pagesize ? Math.max(1, Math.ceil(totalRows / pagesize)) : 1;
			return { pageSize: pagesize, pageNum: pagenum, totalRows: totalRows, totalPages: totalPages };
		}

		function getItemById(id) {
			for (var idx in rows)
				if (rows[idx][idProperty] == id)
					return rows[idx];
		}

		function ensureRowsByIdCache() {
			if (!rowsById) {
				rowsById = {};
				for (var i = 0, l = rows.length; i < l; i++)
					rowsById[rows[i][idProperty]] = i;
			}
		}

		function getRowById(id) {
			ensureRowsByIdCache();
			return rowsById[id];
		}

		/***
		* Wires the grid and the DataView together to keep row selection tied to item ids.
		* This is useful since, without it, the grid only knows about rows, so if the items
		* move around, the same rows stay selected instead of the selection moving along
		* with the items.
		*
		* NOTE:  This doesn't work with cell selection model.
		*
		* @param grid {Slick.Grid} The grid to sync selection with.
		* @param preserveHidden {Boolean} Whether to keep selected items that go out of the
		*     view due to them getting filtered out.
		* @param preserveHiddenOnSelectionChange {Boolean} Whether to keep selected items
		*     that are currently out of the view (see preserveHidden) as selected when selection
		*     changes.
		* @return {Slick.Event} An event that notifies when an internal list of selected row ids
		*     changes.  This is useful since, in combination with the above two options, it allows
		*     access to the full list selected row ids, and not just the ones visible to the grid.
		* @method syncGridSelection
		*/
		function syncGridSelection(grid, preserveHidden, preserveHiddenOnSelectionChange) {
			var self = this;
			var inHandler;
			var selectedRowIds = mapRowsToIds(grid.getSelectedRows());
			var onSelectedRowIdsChanged = new Slick.Event();

			function setSelectedRowIds(rowIds) {
				if (selectedRowIds.join(",") == rowIds.join(",")) {
					return;
				}

				selectedRowIds = rowIds;

				onSelectedRowIdsChanged.notify({
					"grid": grid,
					"ids": selectedRowIds
				}, new Slick.EventData(), self);
			}

			function update() {
				updateData();
				updateSelected();
			}

			function updateSelected() {
				if (selectedRowIds.length > 0) {
					inHandler = true;
					var selectedRows = mapIdsToRows(selectedRowIds);
					if (!preserveHidden) {
						setSelectedRowIds(mapRowsToIds(selectedRows));
					}
					grid.setSelectedRows(selectedRows);
					inHandler = false;
				}
			}

			function updateData() {
				grid.setData(self);
				grid.render();
			}

			function clearSelectedItems() {
				setSelectedRowIds([]);
			}

			grid.onSelectedRowsChanged.subscribe(function (e, args) {
				if (inHandler) { return; }
				var newSelectedRowIds = mapRowsToIds(grid.getSelectedRows());
				if (!preserveHiddenOnSelectionChange || !grid.getOptions().multiSelect) {
					setSelectedRowIds(newSelectedRowIds);
				} else {
					// keep the ones that are hidden
					var existing = $.grep(selectedRowIds, function (id) { return getRowById(id) === undefined; });
					// add the newly selected ones
					setSelectedRowIds(existing.concat(newSelectedRowIds));
				}
			});

			this.onRowsChanged.subscribe(update);
			this.onRowCountChanged.subscribe(updateSelected);

			return $.extend({}, onSelectedRowIdsChanged, { clearSelectedItems: clearSelectedItems });
		}

		function mapRowsToIds(rowArray) {
			var ids = [];
			for (var i = 0, l = rowArray.length; i < l; i++) {
				if (rowArray[i] < rows.length) {
					ids[ids.length] = rows[rowArray[i]][idProperty];
				}
			}
			return ids;
		}

		function mapIdsToRows(idArray) {
			var rows = [];
			for (var i = 0, l = idArray.length; i < l; i++) {
				var row = getRowById(idArray[i]);
				if (row != null) {
					rows[rows.length] = row;
				}
			}
			return rows;
		}

		function getLength() {
			return rows.length;
		}

		function getItem(i) {
			return rows[i];
		}

		$.extend(this, {
			// methods
			"setPagingOptions": setPagingOptions,
			"getPagingInfo": getPagingInfo,
			"getItems": getItems,
			"fastSort": fastSort,
			"getItemById": getItemById,
			"getRowById": getRowById,
			"setFilterArgs": setFilterArgs,
			"refresh": refresh,
			"syncGridSelection": syncGridSelection,

			//data provider
			"getItem": getItem,
			"getLength": getLength,

			// events
			"onRowCountChanged": onRowCountChanged,
			"onRowsChanged": onRowsChanged,
			"onPagingInfoChanged": onPagingInfoChanged,

			"setRefreshHints": $.noop//duck typing
		});
	}

	$.extend(true, window, { Slick: { Data: { RemoteDataView: RemoteDataView } } });
})(jQuery);
