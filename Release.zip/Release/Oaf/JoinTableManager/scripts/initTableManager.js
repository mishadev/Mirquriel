﻿$(document).ready(function () {
	'use strict'

	var apiUri = '/api/JointableManager/' + $(".join-table-manager-api-key").val();
	var configuration = null;

	var dataView = null;
	var grid = null;
	var selectedRowIds = [];
	var clearSelectedItems = $.noop;

	$.getJSON(apiUri + "/Configuration").then(function (data) {
		configuration = data;

		$(".join-table-manager-page-title").text(data.Label);
		setUpSelect(configuration.Messages.Add, data.LeftTable, ".join-table-manager-left-select-label", ".join-table-manager-left-select", true);
		setUpSelect(configuration.Messages.To, data.RightTable, ".join-table-manager-right-select-label", ".join-table-manager-right-select", false);
		$(".join-table-manager-add-mapping").on("click", addMapping);

		updateBulkAdd(".join-table-manager-add-left-mapping", data.RightTable, true);
		updateBulkAdd(".join-table-manager-add-right-mapping", data.LeftTable, false);

		$(".join-table-manager-delete-bulk-mapping").click(bulkDelete);
		$(".join-table-manager-clear-selection").click(function () { clearSelectedItems(); });

		showTableInformation(configuration);
		setUpFilters(configuration);
		setUpTable(configuration);
		reloadTableData();

		$(document.body).on('click', '.join-table-manager-delete-mapping', deleteMapping);
	});

	function setUpSelect(labelText, table, labelSelector, selectSelector, isLeft) {
		$(labelSelector).text(labelText);

		$(selectSelector).select2({
			placeholder: table.Label,
			allowClear: false,
			minimumResultsForSearch: 10,
			ajax: {
				url: apiUri + '/Options/' + (isLeft ? 'LeftTable' : 'RightTable'),
				dataType: 'json',
				quietMillis: 250,
				data: function(term, page) { // page is the one-based page number tracked by Select2
					return {
						q: term, //search term
						page: page // page number
					};
				},
				results: function (data, page) {
					var items = data.Items.map(function(item) { return { id: item.Value, text: item.Name }; });
					// we return the value of more so Select2 knows if more results can be loaded
					return { results: items, more: data.HasMore };
				}
			},
		});
	}

	function reloadTableData() {
		if (configuration.UseClientSideDataView) {
			$.ajax(apiUri + "/List", {
				cache: false
			}).then(function (data) {
				extendByCompositeKey(data);

				dataView.beginUpdate();
				dataView.setItems(data, "CompositeKey");
				dataView.endUpdate();
			});
		}

		if (dataView.setFilter)
			dataView.setFilter(dataFiltering);
		else
			updateFilter();
	}

	function extendByCompositeKey(itemsArray) {
		for (var i in itemsArray)
			$.extend(itemsArray[i], { CompositeKey: compositeKey(itemsArray[i].LeftValue, itemsArray[i].RightValue) });
	}

	function compositeKey(left, right) {
		return left + "-" + right;
	}

	function decompositeKey(item) {
		var compositeKey = item.split("-");

		return { LeftValue: compositeKey[0], RightValue: compositeKey[1] };
	}

	function dataFiltering(item, options) {
	    if (options === undefined)
	        return true;

	    if (textFilterDoesNotMatch(options.leftValue, item.LeftName))
	        return false;

	    if (textFilterDoesNotMatch(options.rightValue, item.RightName))
	        return false;
	  
	    return true;
	}

	function textFilterDoesNotMatch(filter, value) {
	    value = value ? value.toUpperCase() : "";
	    return filter && value.indexOf(filter.toUpperCase()) == -1;
	}

	function updateFilter() {
	
	    dataView.setFilterArgs({
	        leftValue: $(".join-table-manager-left-filter-value").val(),
	        rightValue: $(".join-table-manager-right-filter-value").val(),
	    });
	    dataView.refresh();
	}

	function setUpFilters(configuration) {
	    $(".join-table-manager-left-filter-label").text(configuration.LeftTable.Label);
	    $(".join-table-manager-right-filter-label").text(configuration.RightTable.Label);
	    $(".join-table-manager-filter-button").click(updateFilter);
	    $("#filter-form").submit(function(e) {
	    	e.preventDefault();
        	return false;
	    });
	}

	function showTableInformation(configuration) {
		if (!configuration.TableInformation)
			return;

		$(".join-table-manager-show-debugging-label").append(configuration.Messages.ShowTableInformation)
			.show();

		$(".join-table-manager-show-debugging").click(function () {
			$(".join-table-manager-table-information-section").toggle();
		});

		fillTableInformationHeader(configuration.Messages);
		fillTableRow(configuration.TableInformation.LeftTable, "left", configuration.Messages);
		fillTableRow(configuration.TableInformation.RightTable, "right", configuration.Messages);
		fillJoinTable(configuration.TableInformation.JoinTable, configuration.Messages);
	}

	function fillTableInformationHeader(messages) {
		$(".join-table-manager-table-information-section-label-header").text(messages.Table);
		$(".join-table-manager-table-information-section-table-header").text(messages.NameInDatabase);
		$(".join-table-manager-table-information-section-columns-header").text(messages.Columns);
	}

	function fillJoinTable(table, messages) {
		$(".join-table-manager-table-information-section-label-join").text(table.Label);
		$(".join-table-manager-table-information-section-table-join").text(table.TableName);
		$(".join-table-manager-table-information-section-columns-join").text(messages.LeftKey + ": " + table.LeftKeyColumnName + ", " + messages.RightKey+ ": " + table.RightKeyColumnName);
	}

	function fillTableRow(table, classPostfix ,messages) {
		$(".join-table-manager-table-information-section-label-" + classPostfix).text(table.Label);
		$(".join-table-manager-table-information-section-table-" + classPostfix).text(table.TableName);
		$(".join-table-manager-table-information-section-columns-" + classPostfix).text(messages.Key + ": " + table.KeyColumnName + ", " + messages.Description + ": " + table.DescriptionColumnName);
	}

	function setUpTable(configuration) {
		var columns = [
			{ id: "LeftName", name: configuration.LeftTable.Label, field: "LeftName", maxWidth: configuration.LeftTable.Width, sortable: true, formatter: textFormatter },
			{ id: "RightName", name: configuration.RightTable.Label, field: "RightName", maxWidth: configuration.RightTable.Width, sortable: true, formatter: textFormatter },
			{ id: "delCol", field: 'del', name: 'Delete', formatter: buttonFormatter }
		];

		var checkboxSelector = new Slick.CheckboxSelectColumn({		
			width: 40,
			cssClass: "join-table-manager-checkbox-select"
		});

		columns.unshift(checkboxSelector.getColumnDefinition());

		var options = {
			enableColumnReorder: false,
			autoHeight: true,
			rowHeight: 35,
			forceFitColumns: true
		};
		
		dataView = configuration.UseClientSideDataView ?
			new Slick.Data.DataView():
			new Slick.Data.RemoteDataView({ requestFilteredAndPagedItems: apiUri + "/Page", idProperty: "CompositeKey", sortField: "LeftName", extendItems: extendByCompositeKey });

		grid = new Slick.Grid(".join-table-manager-table-grid", dataView, columns, options);
		grid.setSelectionModel(new Slick.RowSelectionModel({ selectActiveRow: false }));
		grid.registerPlugin(checkboxSelector);

		var pager = new Slick.Controls.Pager(dataView, grid, $(".join-table-manager-pager"));

		dataView.onRowCountChanged.subscribe(function (e, args) {
			grid.updateRowCount();
			grid.render();
		});

		dataView.onRowsChanged.subscribe(function (e, args) {
			grid.invalidateRows(args.rows);
			grid.render();
		});
		
		grid.onSort.subscribe(function (e, args) {
			var sortdir = args.sortAsc;
			var sortcol = args.sortCol.field;

			dataView.fastSort(sortcol, sortdir);
		});

		grid.setSortColumn("LeftName", true);

		//this is required to skip filtering 
		//otherwise if user enters data and does not click on filter button filtering would be performed on raw data        
		dataView.setRefreshHints({ isFilterUnchanged: true });		
		dataView.setPagingOptions({ pageSize: configuration.PageSize });

		var sync = dataView.syncGridSelection(grid, true, true);
		sync.subscribe(function (e, data) {
			selectedRowIds = data.ids;
			updateSelectedRecordsMessage();
		});

		clearSelectedItems = function() {
			grid.setSelectedRows([]);//unselecting previously selected rows
			selectedRowIds = [];
			if ($.isFunction(sync.clearSelectedItems))
				sync.clearSelectedItems();
			$(".join-table-manager-records-selected").hide();
		}
	}

	function updateSelectedRecordsMessage(hide) {
		$(".join-table-manager-records-selected").text(selectedRowIds.length + " record(s) selected");
		$(".join-table-manager-records-selected").show();
	}

	function buttonFormatter(row, cell, value, columnDef, dataContext) {
		var button = "<button class='join-table-manager-delete-mapping' data-composite-key='" + dataContext.CompositeKey + "'>Delete</button>";
		return button;
	}

	function textFormatter(row, cell, value, columnDef, dataContext) {
		return "<span>" + value + "</span>";
	}

	function updateBulkAdd(selector, table, isLeft) {
		$(selector).append(table.Label);
		$(selector).click(function () { addBulkMapping(isLeft) });
	}

	function addBulkMapping(isLeft) {
		var operationSelect = isLeft ? ".join-table-manager-left-select" : ".join-table-manager-right-select";		
		
		var selectedValue = $(operationSelect).select2('val');
		if ('' === selectedValue) {
			showOperationResult(configuration.Messages.MappingSelectValue);
			return;
		}
			
		var model = {
			LeftToRight: isLeft,
			OperationKey: selectedValue
		};

		$.post(apiUri+"/Bulk", model).then(function (data) {
			var message = configuration.Messages.MappingFailed;
			if (data) {
				message = configuration.Messages.MappingAdded;
				reloadTableData();
			}

			showOperationResult(message);
		});
	}

	function addMapping() {
		var record = decompositeKey(compositeKey($(".join-table-manager-left-select").select2('val'), $(".join-table-manager-right-select").select2('val')));

		if (!record.LeftValue || !record.RightValue) {
			showOperationResult(configuration.Messages.MappingSelectValues);
			return;
		}

		$.post(apiUri, record).then(function (data) {
			var message = configuration.Messages.MappingFailed;
			if (data) {
				message = configuration.Messages.MappingAdded;
				reloadTableData();
			}

			showOperationResult(message);
		});
	}

	function bulkDelete() {
		if (!selectedRowIds.length)
			return showOperationResult(configuration.Messages.MappingDeletionFailed);

		if (!confirm(configuration.Messages.MappingDeleteConfirmation))
			return;

		var records = $.map(selectedRowIds, decompositeKey);

		$.ajax({
			url: apiUri + "/BulkDelete",
			type: 'POST',
			data: JSON.stringify(records),
			contentType: "application/json"
		}).then(function (data) {
			clearSelectedItems();
			var message = configuration.Messages.MappingDeletionFailed;
			if (data) {
				message = configuration.Messages.MappingDeleted;
				reloadTableData();
			}
			showOperationResult(message);
		});
	}

	function deleteMapping() {
		if (!confirm(configuration.Messages.MappingDeleteConfirmation))
			return;

		var record = decompositeKey($(this).data('composite-key'));

		$.ajax({
			url: apiUri,
			type: 'DELETE',
			data: record
		}).then(function (data) {
			var message = configuration.Messages.MappingDeletionFailed;
			if (data) {
				message = configuration.Messages.MappingDeleted;
				reloadTableData();
			}
			showOperationResult(message);
		});
	}

	function showOperationResult(message) {
		$(".join-table-manager-mapping-message").text(message).show().delay(2000).fadeOut(1);
	}
});
