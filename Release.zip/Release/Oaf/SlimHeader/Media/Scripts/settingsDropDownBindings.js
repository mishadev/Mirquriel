﻿(function () {

    function setupDropdown($, ko) {
        // $ and ko may be overwritten by client project's jquery and knockout variables after this plugin is loaded
        var _$ = $;
        var _ko = ko;

        _ko.bindingHandlers.settingsDropdown = {
            init: function (element) {
                element.isExpanded = _ko.observable(false);

                _$(document.body).click(function () { element.isExpanded(false); });

                _$(element).click(function (event) {
                    element.isExpanded(!element.isExpanded());
                    event.stopPropagation();
                });

                element.isExpanded.subscribe(function (newValue) {
                    if (newValue) {
                        _$(element).addClass("settingsBoxExpanded");
                    } else {
                        _$(element).removeClass("settingsBoxExpanded");
                    }
                });
            }
        };
    }

    if (typeof define === 'function' && define.amd)
        define(['jquery', 'knockout'], setupDropdown);
    else
        setupDropdown($, ko);

})();