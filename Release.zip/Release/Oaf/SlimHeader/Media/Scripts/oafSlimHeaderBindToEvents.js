﻿(function (root, factory) {
    if (typeof define === 'function' && define.amd)
        return define(['jquery', 'knockout', 'bootstrap-tooltip', 'bootstrap-popover', 'bootstrap-clickover', 'settingsDropDownBindings'], factory);
    else 
        return root.oafSlimHeaderBindToEvents = factory(root.jQuery, root.ko);
}(this, function ($, ko) {
    'use strict'

    return function oafSlimHeaderBindToEvents(model) {
        $(function(){
            //TODO - GM - All these selectors need a context parameter

            $('#user').clickover({
                html: true,
                placement: 'bottom',
                content: $('#userPartialContainer').html(),
                onShown: function () {
                    var elem = $(this.$tip[0]);
                    var arrow = elem.find('.arrow');
                    // reconstituting the language drop-down HTML from a template each time, so we need to re-bind KO to the drop-down
                    setupKO(elem[0], ko, model);

                    var left = elem.position().left;
                    // TODO AG: make this readjustment a function of width rather than assuming the widths of the current design
                    elem.css('left', left - 20);
                    arrow.css('left', 120);
                }
            });

            $('#question').clickover({
                html: true,
                placement: 'bottom',
                onShown: function () {
                    var elem = $(this.$tip[0]);
                    var arrow = elem.find('.arrow');
                    var left = elem.position().left;
                    // TODO AG: make this readjustment a function of width rather than assuming the widths of the current design
                    elem.css('left', left - 110);
                    arrow.css('left', 236);
                }
            });

            $('html').on('click dblclick touchstart',function () {
                $('.tool-menu').hide(); //TODO - This could easily interfere with other applications
            });

            $('.menu-container').click(function (event) {
                var menuForThisMenuContainer = $(this).find('.tool-menu');
                menuForThisMenuContainer.show();
                $('.tool-menu').not(menuForThisMenuContainer).hide();
                event.stopPropagation();
            });
        });
    };

    function setupKO(elem, ko, model) {

		function setCulture(language, locale) {
			return $.post("/_oaf/local/culture", { language: language, locale: locale });
		}

		function setObservablesFromCulture(value, options, observables) {
			if (value) {
				options.forEach(function (option, index) {
					if (option.Abbreviation.toUpperCase() === value.toUpperCase()) {
						observables.forEach(function (observable) {
							observable(option);
						});
					};
				});
			}
		}

		function initModel(culture, viewModel) {
			var splittedLanguage = culture.language.split('-'),
				language = splittedLanguage[0],
				locale = culture.locale || splittedLanguage[1];

			// if languages are provided, prepare languages part of viewmodel
			if (model.languages && model.languages.length > 0) {
				var languages = model.languages;
				viewModel.languages = languages;
				viewModel.selectedLanguage = ko.observable(languages[0]);
				viewModel.originallySelectedLanguage = ko.observable(languages[0]);
				setObservablesFromCulture(language, languages, [viewModel.selectedLanguage, viewModel.originallySelectedLanguage]);
			}

			// if locales are provided, prepare locales part of viewmodel
			if (model.locales && model.locales.length > 0) {
				var locales = model.locales;
				viewModel.locales = locales;
				viewModel.selectedLocale = ko.observable(locales[0]);
				viewModel.originallySelectedLocale = ko.observable(locales[0]);
				setObservablesFromCulture(locale, locales, [viewModel.selectedLocale, viewModel.originallySelectedLocale]);
			}
		}

		var viewModel = {};
		viewModel.saveSettings = function () {
			var language;
			if (viewModel.selectedLanguage && viewModel.selectedLanguage())
				language = viewModel.selectedLanguage().Abbreviation;

			var locale;
			if (viewModel.selectedLocale && viewModel.selectedLocale())
				locale = viewModel.selectedLocale().Abbreviation;

			if (language || locale)
				setCulture(language, locale)
					.done(function () { document.location.reload(true); });
		}

		initModel(model.current, viewModel);

		ko.cleanNode(elem);
		ko.applyBindings(viewModel, elem);
	}
}));