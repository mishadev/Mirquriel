﻿define([
    'd3',
    'underscore',
    '../OgrePlugins/owColors'
], function (d3, underscoreJS, owColors) {
    'use strict';

    // if no height given, dynamically compute height of grid based on number of rows of data
    var getGridHeight = function (gridProperties) {
        if (gridProperties.height !== undefined) {
            return gridProperties.height;
        }

        if (gridProperties.definition !== undefined) {
            return gridProperties.definition.length * 120 / 7;
        }

        return 150;
    };

    function checkDataSource(container, dataSource, text) {

        if (text === undefined) {
            text = "Missing data";
        }

        if (dataSource === undefined || dataSource.length === 0) {
            container.append('div')
                .classed('no-data', true)
                .text(text);

            return false;
        }

        return true;
    }

    var graphs = {

        generateBarChartAndGrid: function (graphProperties) {
            /// <summary>Generates a bar chart with a grid of aligned data below using the specified graph properties.</summary>
            /// <param name="graphProperties">The graph properties.</param>
            /// <returns type="Object">The graph object.</returns>

            try {

                // If debug is defined as a property and the developer window is open, enter debug mode.
                if (graphProperties.debug !== undefined) {
                    debugger;
                }

                // Check for required parameters
                if (graphProperties.chart === undefined) { throw "Parameter section 'chart' is required."; }
                if (graphProperties.grid === undefined) { throw "Parameter section 'grid' is required."; }

                var graphObject = {
                    container: graphProperties.parent.append('div')
                };

                graphObject.container
                    .classed('graph', true)
                    .classed('bar-and-grid', true);

                // Set defaults
                graphProperties.grid.height = getGridHeight(graphProperties.grid);

                // Generate header
                graphObject.header = this.generateHeader(graphObject.container, graphProperties);

                // Check the data sources
                if (checkDataSource(graphObject.container, graphProperties.chart.data, graphProperties.noDataText) &&
                    checkDataSource(graphObject.container, graphProperties.grid.data, graphProperties.noDataText)) {

                    // Generate bar chart
                    var chartProperties = graphProperties.chart;
                    chartProperties.parent = graphObject.container;
                    chartProperties.width = graphProperties.width;
                    chartProperties.height = graphProperties.height - graphProperties.grid.height - graphObject.header.height;

                    graphObject.chart = this.generateBarChart(chartProperties);

                    // Generate grid
                    graphObject.grid = this.generateAlignedGridForBarChart(graphProperties);

                } else {
                    graphObject.noData = true;
                }

                graphObject.properties = graphProperties;
                return graphObject;

            } catch (err) {
                throw "Error creating bar and grid: \r\n" + err;
            }

        },

        generateSkyLine: function (graphProperties) {
            /// <summary>Generates a skyline chart using the specified graph properties.</summary>
            /// <param name="graphProperties">The graph properties.</param>
            /// <returns type="Object">The graph object.</returns>

            try {

                graphProperties.SkyLine = true;

                var graphObject = this.generateBarChart(graphProperties);

                return graphObject;

            } catch (err) {
                throw "Error creating skyline: \r\n" + err;
            }
        },

        generateBarChart: function (graphProperties) {
            /// <summary>Generates a bar chart using the specified graph properties.</summary>
            /// <param name="graphProperties">The graph properties.</param>
            /// <returns type="Object">The graph object.</returns>

            try {

                // If debug is defined as a property and the developer window is open, enter debug mode.
                if (graphProperties.debug !== undefined) {
                    debugger;
                }

                graphProperties = this.parseAndNormalizeGraphProperties(graphProperties);

                // Create object to return. All created elements should be part of this so that they can be modified/rearranged outside of the function.
                var graphObject = {
                    container: graphProperties.parent.append("div")
                };

                graphObject.container
                    .classed('graph', true)
                    .classed(graphProperties.SkyLine ? 'skyline' : 'bar', true);

                // Set default properties if not defined
                graphProperties.marginTop = graphProperties.marginTop === undefined ? 20 : graphProperties.marginTop;
                if (graphProperties.axis.y.width === undefined) {
                    graphProperties.axis.y.width = graphProperties.axis.y.title === undefined ? 60 : 140;
                }
                if (graphProperties.axis.x.height === undefined) {
                    graphProperties.axis.x.height = graphProperties.axis.x.title === undefined ? 40 : 100;
                }

                // Generate the chart headers
                graphObject.header = this.generateHeader(graphObject.container, graphProperties);

                // Check data source
                if (checkDataSource(graphObject.container, graphProperties.data, graphProperties.noDataText)) {

                    // Generate legend
                    if (graphProperties.legend !== undefined && graphProperties !== null) {
                        graphObject.legend = this.generateLegend(graphObject.container, graphProperties);
                    } else {
                        graphProperties.legend = {
                            width: 0
                        };
                    }

                    // Create the chart graphics object
                    var chartSvg = graphObject.container.append("svg");
                    chartSvg.width = graphProperties.width - graphProperties.legend.width;
                    chartSvg.height = graphObject.header === undefined ? graphProperties.height : graphProperties.height - graphObject.header.height;
                    chartSvg.style('width', chartSvg.width + 'px');
                    chartSvg.style('height', chartSvg.height + 'px');

                    graphObject.axisTitles = this.generateAxisTitles(chartSvg, graphProperties);


                    // Create graph SVG
                    var chart = chartSvg.append('svg');
                    chart.dataSet = graphProperties.data;
                    chart.width = chartSvg.width - graphProperties.axis.y.width;
                    chart.height = chartSvg.height - graphProperties.marginTop - graphProperties.axis.x.height;


                    // If SkyLine chart, calculate cumulative widths
                    // This is used to determine where the subsequent bar will start from
                    if (graphProperties.SkyLine) {
                        var i, cumWidth = 0;

                        for (i = 0; i < chart.dataSet.length; i++) {
                            console.log('Getting width from key : ' + chart.dataSet[i][graphProperties.axis.x.key]);
                            chart.dataSet[i][graphProperties.axis.x.key] = +chart.dataSet[i].width;
                            chart.dataSet[i].cumWidth = cumWidth;
                            cumWidth = cumWidth + chart.dataSet[i].width; // force addition not concatenation
                        }
                    }


                    graphObject.axisScales = {
                        y: this.getYAxisScaleFunction(chart.dataSet, graphProperties.axis.y, chart.height),
                        x: d3.scale.linear()
                                   .domain([0, (graphProperties.SkyLine ? cumWidth : chart.dataSet.length)])
                                   .range([0, chart.width])
                    };

                    // Create Y Axis
                    graphObject.axis = {
                        y: this.generateYAxisScale(chart, graphProperties.axis.y, graphObject.axisScales.y, graphProperties.axis.y.width, graphProperties.marginTop).classed('y', true)
                    };

                    // X Axis
                    // Use scaled values for SkyLine, labels for bar chart
                    if (graphProperties.SkyLine) {
                        graphObject.axis.x = this.generateXAxisScale(chart, chart, graphProperties.axis.x, graphObject.axisScales.x, graphProperties.axis.y.width, graphProperties.marginTop);
                    } else {
                        // Create X Axis Labels
                        graphObject.axis.x = this.generateAxisLabels(chart, chart, graphProperties, graphObject.axisScales.x, graphProperties.axis.y.width, graphProperties.marginTop);
                        // Draw x-axis line - uses 0 position on Y axis to calculate
                        graphObject.axis.x.append('path')
                               .attr('d', 'm ' + graphProperties.axis.y.width + ' ' + (graphProperties.marginTop + graphObject.axisScales.y(0)) + ' H ' + (chart.width + graphProperties.axis.y.width));
                    }

                    // Set class on x axis
                    graphObject.axis.x.classed('x', true);

                    // Create data bars
                    graphObject.data = this.generateBars(chart, chart, graphProperties, graphObject.axisScales.x, graphObject.axisScales.y, graphProperties.axis.y.width, graphProperties.marginTop);

                    // Create data labels
                    graphObject.dataLabels = this.generateBarDataLabels(chart, chart, graphProperties, graphObject.axisScales.x, graphObject.axisScales.y, graphProperties.axis.y.width, graphProperties.marginTop);

                } else {
                    graphObject.noData = true;
                }

                graphObject.properties = graphProperties;
                return graphObject;

            } catch (err) {
                throw "Error creating bar chart: \r\n" + err;
            }

        },

        generateLineChart: function (graphProperties) {
            /// <summary>Generates a line chart using the specified graph properties.</summary>
            /// <param name="graphProperties">The graph properties.</param>
            /// <returns type="Object">The graph object.</returns>

            try {

                // If debug is defined as a property and the developer window is open, enter debug mode.
                if (graphProperties.debug !== undefined) {
                    debugger;
                }

                graphProperties = this.parseAndNormalizeGraphProperties(graphProperties);

                // Create object to return. All created elements should be part of this so that they can be modified/rearranged outside of the function.
                var graphObject = {
                    container: graphProperties.parent.append("div")
                };

                graphObject.container
                    .classed('graph', true)
                    .classed('line', true);

                // Set default properties if not defined
                graphProperties.marginTop = graphProperties.marginTop === undefined ? 40 : graphProperties.marginTop;
                if (graphProperties.axis.y.width === undefined) {
                    graphProperties.axis.y.width = graphProperties.axis.y.title.text === null ? 60 : 140;
                }
                if (graphProperties.axis.x.height === undefined) {
                    graphProperties.axis.x.height = graphProperties.axis.x.title.text === null ? 40 : 100;
                }

                if (graphProperties.axis.y.dataType === undefined) {
                    graphProperties.axis.y.dataType = "numeric";
                }
                if (graphProperties.axis.x.dataType === undefined) {
                    graphProperties.axis.x.dataType = "count";
                }

                if (graphProperties.axis.y.seriesColors === undefined) {
                    graphProperties.axis.y.seriesColors = owColors.orderedLineChartColors;
                }

                // Generate the chart headers
                graphObject.header = this.generateHeader(graphObject.container, graphProperties);

                // Check data source
                if (checkDataSource(graphObject.container, graphProperties.data, graphProperties.noDataText)) {

                    // Generate legend
                    if (graphProperties.legend !== undefined && graphProperties !== null) {
                        graphObject.legend = this.generateLegend(graphObject.container, graphProperties);
                    } else {
                        graphProperties.legend = {
                            width: 0
                        };
                    }

                    // Create the chart graphics object
                    var chartSvg = graphObject.container.append("svg");
                    chartSvg.width = graphProperties.width - graphProperties.legend.width;
                    chartSvg.height = graphObject.header === undefined ? graphProperties.height : graphProperties.height - graphObject.header.height;
                    chartSvg.style('width', chartSvg.width + 'px');
                    chartSvg.style('height', chartSvg.height + 'px');

                    graphObject.axisTitles = this.generateAxisTitles(chartSvg, graphProperties);

                    // Create graph SVG
                    var chart = chartSvg.append('svg');
                    chart.dataSet = graphProperties.data;
                    chart.width = chartSvg.width - graphProperties.axis.y.width;
                    chart.height = chartSvg.height - graphProperties.marginTop - graphProperties.axis.x.height;

                    // Create Y Axis
                    chart.yScale = this.getYAxisScaleFunction(chart.dataSet, graphProperties.axis.y, chart.height);

                    graphObject.axis = {
                        y: this.generateYAxisScale(chart, graphProperties.axis.y, chart.yScale, graphProperties.axis.y.width, graphProperties.marginTop).classed('y', true)
                    };

                    // Create X Axis
                    chart.xScale = this.getXAxisScaleFunction(chart.dataSet, graphProperties.axis.x, chart.width);

                    graphObject.axis.x = this.generateXAxisScale(chart, chart, graphProperties.axis.x, chart.xScale, graphProperties.axis.y.width, graphProperties.marginTop).classed('x', true);

                    // Create data lines
                    graphObject.lines = this.generateLines(chart, chart, graphProperties, graphProperties.axis.y.width, graphProperties.marginTop);
                } else {
                    graphObject.noData = true;
                }

                graphObject.properties = graphProperties;
                return graphObject;

            } catch (err) {
                throw "Error creating line chart: \r\n" + err;
            }

        },

        parseAndNormalizeGraphProperties: function (graphProperties) {
            /// <summary>Parses the specified graph properties by normalizing values into the standard object graph
            /// where requried and setting defaults where optional values are omitted.</summary>
            /// <param name="graphProperties" type="Object">The graph properties object graph.</param>
            /// <returns type="Object">The parsed graph properties object graph.</returns>

            // Check for required parameters
            if (graphProperties.axis === undefined || graphProperties.axis === null) { throw "Parameter section 'axis' is required."; }
            if (graphProperties.axis.x === undefined || graphProperties.axis.x === null) { throw "Parameter section 'axis.x' is required."; }
            if (graphProperties.axis.y === undefined || graphProperties.axis.y === null) { throw "Parameter section 'axis.y' is required."; }
            if (graphProperties.axis.x.key === undefined || graphProperties.axis.x.key === null) { throw "Parameter 'axis.x.key' is required."; }
            if (graphProperties.axis.y.key === undefined || graphProperties.axis.y.key === null) { throw "Parameter 'axis.y.key' is required."; }

            // if a string is supplied as the X title value, treat this as the title text, and set the default position
            graphProperties.axis.x.title = graphProperties.axis.x.title === undefined
                ? { text: null, position: 'center' }
                : graphProperties.axis.x.title;

            if (typeof graphProperties.axis.x.title !== 'object') {
                graphProperties.axis.x.title = { text: graphProperties.axis.x.title, position: 'center' };
            }

            graphProperties.axis.x.title.position = graphProperties.axis.x.title.position || 'center';

            // if a string is supplied as the Y title value, treat this as the title text, and set the default position
            graphProperties.axis.y.title = graphProperties.axis.y.title === undefined
                ? { text: null, position: 'middle' }
                : graphProperties.axis.y.title;

            if (typeof graphProperties.axis.y.title !== 'object') {
                graphProperties.axis.y.title = { text: graphProperties.axis.y.title, position: 'middle' };
            }

            graphProperties.axis.y.title.position = graphProperties.axis.y.title.position || 'middle';

            return graphProperties;
        },

        /*
        Generates the headers for a chart
        */
        generateHeader: function (parent, graphProperties) {

            var headerObject = {
                height: 0
            };

            if (graphProperties.header !== undefined) {

                try {

                    headerObject.height = graphProperties.headerHeight === undefined ? 90 : graphProperties.headerHeight;

                    headerObject.container = parent.append("div").attr('class', 'graphTitle');

                    if (graphProperties.axis && graphProperties.axis.y && graphProperties.axis.y.width) {
                        headerObject.container.style("margin-left", graphProperties.axis.y.width + "px");
                    }

                    headerObject.title = headerObject.container.append("h3")
                                                               .text(graphProperties.header.title);

                    if (graphProperties.header.subtitle !== undefined) {

                        headerObject.subtitle = headerObject.container.append("h4")
                                                                      .text(graphProperties.header.subtitle);

                    }

                } catch (err) {
                    throw "Unable to create chart headers: \r\n" + err;
                }
            }

            return headerObject;

        },

        /*
        Generates x and y axis titles for a chart
        */
        generateAxisTitles: function (parent, graphProperties) {
            // Maps title position values to SVG text-anchor values
            var TEXT_ANCHOR_MAP = { left: 'start', center: 'middle', right: 'end', top: 'end', middle: 'middle', bottom: 'start' };

            try {

                if (graphProperties.axis.x.offsetX === undefined) { graphProperties.axis.x.offsetX = 0; }
                if (graphProperties.axis.x.offsetY === undefined) { graphProperties.axis.x.offsetY = 0; }
                if (graphProperties.axis.y.offsetX === undefined) { graphProperties.axis.y.offsetX = 0; }
                if (graphProperties.axis.y.offsetY === undefined) { graphProperties.axis.y.offsetY = 0; }

                // constants and outputs
                var titleObject = {};

                // X axis title
                var xAxisXOrigin = graphProperties.axis.x.offsetX + graphProperties.axis.y.width;
                var xAxisXCoordinate = xAxisXOrigin + ((parent.width - graphProperties.axis.y.width) / 2);

                if (graphProperties.axis.x.title.position === 'left') {
                    xAxisXCoordinate = xAxisXOrigin;
                }
                else if (graphProperties.axis.x.title.position === 'right') {
                    xAxisXCoordinate = xAxisXOrigin + (parent.width - graphProperties.axis.y.width);
                }

                var xAxisYCoordinate = parent.height + graphProperties.axis.x.offsetY - 20;
                titleObject.x = parent.append('text')
                    .attr('x', xAxisXCoordinate)
                    .attr('text-anchor', TEXT_ANCHOR_MAP[graphProperties.axis.x.title.position] || 'middle')
                    .attr('y', xAxisYCoordinate)
                    .attr('class', 'axis x title')
                    .text(graphProperties.axis.x.title.text);

                // Y axis title
                var yAxisXCoordinate = graphProperties.axis.y.width + graphProperties.axis.y.offsetX - 80;
                var yAxisHeight = parent.height - graphProperties.marginTop - graphProperties.axis.x.height;

                // default position is for top; add required offsets for middle and bottom
                var yAxisYCoordinate = graphProperties.marginTop + (yAxisHeight / 2);
                if (graphProperties.axis.y.title.position === 'top') {
                    yAxisYCoordinate = graphProperties.marginTop;
                }
                else if (graphProperties.axis.y.title.position === 'bottom') {
                    yAxisYCoordinate = graphProperties.marginTop + yAxisHeight;
                }

                titleObject.y = parent.append('text')
                    .attr('x', yAxisXCoordinate)
                    .attr('text-anchor', TEXT_ANCHOR_MAP[graphProperties.axis.y.title.position] || 'middle')
                    .attr('y', yAxisYCoordinate)
                    .attr('transform', 'rotate(-90 ' + yAxisXCoordinate + ',' + yAxisYCoordinate + ')')
                    .attr('class', 'axis y title')
                    .text(graphProperties.axis.y.title.text);

                return titleObject;

            } catch (err) {
                throw "Unable to create axis titles: \r\n" + err;
            }

        },

        /*
        Generates data labels for a bar chart
        */
        generateBarDataLabels: function (parent, svgParent, graphProperties, xScaleFunction, yScaleFunction, offsetX, offsetY) {

            if (graphProperties.dataLabels !== undefined) {
                var alignment = graphProperties.dataLabels.alignment === undefined
                    ? { normal: 'middle', rotated: 'middle' }
                    : graphProperties.dataLabels.alignment;

                var normalLabelAlign = alignment.normal === undefined ? 'middle' : alignment.normal;
                var rotatedLabelAlign = alignment.rotated === undefined ? 'middle' : alignment.rotated;

                try {

                    var dataLabelObject = {};

                    dataLabelObject.group = parent.append("g")
                                                  .attr("class", "dataLabels")
                                                  .attr("transform", "translate(" + graphProperties.axis.y.width + "," + graphProperties.marginTop + ")");

                    if (graphProperties.SkyLine) {
                        // minus 6px to give a margin from the bottom of the graph
                        var labelVAlign = svgParent.height - 6;
                        var texts = [];
                        var isRotateText = function (d, i, fontSizePixels) {
                            fontSizePixels = fontSizePixels === undefined ? 10 : fontSizePixels;

                            var barWidth = Math.abs(xScaleFunction(d[graphProperties.axis.x.key]));
                            var estimatedTextWidth = texts[i].length * fontSizePixels;

                            // If the bar is wider than 100px there should be no need to rotate the label
                            return barWidth < Math.min(estimatedTextWidth, 100);
                        };

                        dataLabelObject.group.selectAll('text')
                            .data(svgParent.dataSet).enter()
                            .append('text')
                            .text(function (d, i) {
                                var text;

                                // If label is a function , pass values to that function to produce custom label
                                if (underscoreJS.isFunction(graphProperties.axis.x.label)) {
                                    text = graphProperties.axis.x.label(d);
                                } else {
                                    // Otherwise set to standard label of name + value
                                    text = d[graphProperties.axis.x.label] + " " + graphProperties.dataLabels.formatter(+d[graphProperties.axis.x.key]);
                                }

                                // If bar width is less than 7px, don't show any label to prevent clutter
                                text = xScaleFunction(d.width) < 7 ? '' : text;

                                // set the text value in the outer array so we can access it further down:
                                texts[i] = text;

                                return text;
                            })
                            // This is a skyline chart so set X to middle of current bar
                            .attr('x', function (d) {
                                return xScaleFunction(d.cumWidth + d[graphProperties.axis.x.key] / 2.0);
                            })
                            // Set Y position according to parameter, or "middle" by default
                            .attr('y', function (d, i) {
                                var isRotated = isRotateText(d, i);
                                var isMiddleAligned = (isRotated && rotatedLabelAlign === 'middle') 
                                    || (!isRotated && normalLabelAlign === 'middle');

                                return isMiddleAligned ? yScaleFunction(+d[graphProperties.axis.y.key] / 2) : labelVAlign;
                            })
                            .attr('text-anchor', function (d, i) {
                                return isRotateText(d, i) && rotatedLabelAlign === 'bottom' ? 'start' : 'middle';
                            })
                            .attr('transform', function (d, i) {
                                var rotatedY = rotatedLabelAlign === 'middle' ? yScaleFunction(+d[graphProperties.axis.y.key] / 2) : labelVAlign;

                                return isRotateText(d, i)
                                    ? 'rotate(-90 ' + (xScaleFunction(d.cumWidth + d[graphProperties.axis.x.key] / 2.0)) + ',' + rotatedY + ')'
                                    : '';
                            })
                            .classed('highlight', function (d) {
                                return (graphProperties.axis.x.highlightKey !== undefined
                                    && d[graphProperties.axis.x.highlightKey] !== undefined
                                    && d[graphProperties.axis.x.highlightKey] === true);
                            });

                    } else {

                        var YAxisZero = yScaleFunction(0);

                        underscoreJS(svgParent.dataSet).each(function (d, i) {

                            // Gather required information for bar dimensions and position.
                            var seriesKeys = (!jQuery.isArray(graphProperties.axis.y.key)) ? [graphProperties.axis.y.key] : graphProperties.axis.y.key;
                            var series = [];

                            underscoreJS(seriesKeys).each(function (s) {
                                series.push(dataLabelObject.group.append('g'));
                            });

                            var centre = xScaleFunction(i + 0.5);
                            var xWidth = xScaleFunction(0.75);
                            var barWidth = xWidth / seriesKeys.length;

                            underscoreJS(seriesKeys).each(function (s, si) {

                                var yVal = d[seriesKeys[si]];

                                var x = centre - (xWidth / 2) + (barWidth * (si + 0.5));
                                var y = Math.abs(yScaleFunction(yVal)) - 8;

                                series[si].append('text')
                                    .text(graphProperties.dataLabels.formatter(yVal))
                                    // When chart is not skyline, use start of bar
                                    .attr('x', x)
                                    .attr('y', y)
                                    .attr('text-anchor', 'middle')
                                    .classed('highlight', function () {
                                        return (graphProperties.axis.x.highlightKey !== undefined
                                            && d[graphProperties.axis.x.highlightKey] !== undefined
                                            && d[graphProperties.axis.x.highlightKey] === true);
                                    });

                            });

                        });

                    }

                    return dataLabelObject;

                } catch (err) {
                    throw "Unable to create data labels: \r\n" + err;
                }

            }
        },

        getYAxisScaleFunction: function (dataSet, axis, chartHeight) {
            /// <summary>Gets the function used when calculating the y axis scale.</summary>
            /// <param name="dataSet" type="Object">The datasets used to calculate the max value.</param>
            /// <param name="axis" type="Object">The axis object containing the key value and (optionally)
            /// the max value override value.</param>
            /// <param name="chartHeight" type="Object">The chart's height.</param>
            /// <returns type="Function">The y-axis scaling function.</returns>

            var keys = axis.key;

            var maxValueOverride = (axis.range !== undefined
                && axis.range.max !== undefined
                && typeof axis.range.max === "number")
                    ? axis.range.max
                    : null;

            // Calculate the highest value across the datasets, or, when specified, use the max value override 
            // if this is higher than the datasets highest value.
            var maxValue = 0;
            var s = 0;

            if (jQuery.isArray(keys)) {

                for (s = 0; s < keys.length; s++) {

                    var highestSeriesValue = d3.max(dataSet, function (d) { return d[keys[s]]; });

                    if (highestSeriesValue > maxValue) {
                        maxValue = highestSeriesValue;
                    }
                }

            } else {
                maxValue = d3.max(dataSet, function (d) { return d[keys]; });

            }

            if (maxValueOverride !== null) {
                maxValue = Math.max(maxValue, maxValueOverride);
            }

            // Create the scale function for the axis.
            return d3.scale.linear()
                .domain([0, maxValue])
                .range([chartHeight, 0])
                .nice();

        },

        /*
        Gets the function used for returning the data. This formats the data so that it is using the correct type
        (e.g. the dataType date is formatted as a javascript Date object.
        */
        getValueFunction: function (key, dataType) {

            if (dataType === "date") {
                return function (d) {
                    return new Date(d[key]);
                };
            }

            if (dataType === "int") {
                return function (d) {
                    return parseInt(d[key], 0);
                };
            }

            if (dataType === "numeric") {
                return function (d) {
                    return parseInt(d[key], 2);
                };
            }

            return function (d) {
                return d[key];
            };
        },

        /*
        Gets the function used when calculating the x axis scale.
        */
        getXAxisScaleFunction: function (dataSet, xAxisProperties, chartWidth) {

            var xValueFunc = this.getValueFunction(xAxisProperties.key, xAxisProperties.dataType);

            var func;
            if (xAxisProperties.dataType === "date") {
                func = d3.time.scale();
            } else {
                func = d3.scale.linear();
            }

            func = func.domain([d3.min(dataSet, xValueFunc), d3.max(dataSet, xValueFunc)])
                .range([0, chartWidth]);

            return func;

        },

        /*
        Generates a scaled y-axis for a chart
        */
        generateYAxisScale: function (parent, axisProperties, scale, offsetX, offsetY) {

            try {

                if (axisProperties.ticks === undefined) { axisProperties.ticks = 5; }

                var axis = d3.svg.axis()
                                 .scale(scale)
                                 .orient('left');

                if (jQuery.isArray(axisProperties.ticks)) {
                    axis.tickValues(axisProperties.ticks);
                } else {
                    axis.ticks(axisProperties.ticks);
                }

                if (axisProperties.formatter !== undefined) {
                    axis.tickFormat(axisProperties.formatter);
                }

                var axisDom = parent.append('g')
                                    .attr('class', 'axis')
                                    .attr('transform', 'translate(' + offsetX + ', ' + offsetY + ')')
                                    .call(axis);

                return axisDom;

            } catch (err) {
                throw "Unable to create axis scale: \r\n" + err;
            }

        },

        /*
        Generates a scaled x-axis for a chart
        */
        generateXAxisScale: function (parent, parentSvg, axisProperties, scale, offsetX, offsetY) {

            try {

                var axis = d3.svg.axis()
                    .scale(scale)
                    .orient('bottom');

                // Set the function to use when calculating the ticks based on the available properties.
                if (axisProperties.ticks === undefined) { axisProperties.ticks = 10; }

                if (axisProperties.ticks.step !== undefined) {
                    axis.ticks(axisProperties.ticks.interval, axisProperties.ticks.step);
                } else {
                    axis.ticks(axisProperties.ticks);
                }

                if (axisProperties.formatter !== undefined) {
                    axis.tickFormat(axisProperties.formatter);
                }

                var axisDom = parent.append('g')
                                    .attr('class', 'axis')
                                    .attr('transform', 'translate(' + offsetX + ', ' + (offsetY + parentSvg.height) + ')')
                                    .call(axis);

                return axisDom;

            } catch (err) {
                throw "Unable to create axis scale: \r\n" + err;
            }

        },

        /*
        Generates bars (vertical only) for a bar chart
        */
        generateBars: function (parent, parentSvg, graphProperties, xScaleFunction, yScaleFunction, offsetX, offsetY) {

            try {

                // Store the position of the Y Axis zero
                var YAxisZero = yScaleFunction(0);

                var dataBars = parent.append("g")
                                     .attr("class", "bars")
                                     .attr("transform", "translate(" + offsetX + "," + offsetY + ")");

                underscoreJS(parentSvg.dataSet).each(function (d, i) {

                    if (graphProperties.SkyLine) {

                        dataBars.append('rect')
                            .attr('x', xScaleFunction(d.cumWidth))
                            // Set top left Y coordinate of bar to the data value. If this is a negative, then it is set to 0 so that the bar appears below the 0 axis line.
                            .attr('y', yScaleFunction(Math.max(0, d[graphProperties.axis.y.key])))
                            // Set height of bar to be a positive value
                            .attr('height', Math.abs(yScaleFunction(d[graphProperties.axis.y.key]) - YAxisZero))
                            .attr('width', xScaleFunction(d[graphProperties.axis.x.key]))
                            .classed('highlight', function (d) {
                                return (graphProperties.axis.x.highlightKey !== undefined
                                    && d[graphProperties.axis.x.highlightKey] !== undefined
                                    && d[graphProperties.axis.x.highlightKey] === true);
                            });

                    } else {

                        // Gather required information for bar dimensions and position.
                        var seriesKeys = (!jQuery.isArray(graphProperties.axis.y.key)) ? [graphProperties.axis.y.key] : graphProperties.axis.y.key;
                        var series = [];

                        underscoreJS(seriesKeys).each(function (s) {
                            series.push(dataBars.append('g'));
                        });

                        var centre = xScaleFunction(i + 0.5);
                        var xWidth = xScaleFunction(0.75);
                        var barWidth = xWidth / seriesKeys.length;

                        // If a maxBarWidth has been supplied, re-adjust the widths to adhere to it.
                        if (graphProperties.axis.x.maxBarWidth !== undefined) {
                            barWidth = Math.min(barWidth, graphProperties.axis.x.maxBarWidth);
                            xWidth = barWidth * seriesKeys.length;
                        }

                        underscoreJS(seriesKeys).each(function (s, si) {

                            var yVal = d[seriesKeys[si]];

                            var x = centre - (xWidth / 2) + (barWidth * si);
                            var y = Math.min(YAxisZero, yScaleFunction(yVal));
                            var height = Math.abs(yScaleFunction(yVal) - YAxisZero);

                            var bar = series[si].append('rect')
                                .attr('x', x)
                                // Set top left Y coordinate of bar to the data value. If this is a negative, then it is set to 0 so that the bar appears below the 0 axis line.
                                .attr('y', y)
                                // Set height of bar to be a positive value
                                .attr('height', height)
                                .attr('width', barWidth)
                                .classed('highlight', function () {
                                    return (graphProperties.axis.x.highlightKey !== undefined &&
                                        d[graphProperties.axis.x.highlightKey] !== undefined &&
                                        d[graphProperties.axis.x.highlightKey] === true);
                                });

                            if (graphProperties.axis.y.seriesColors !== undefined) { bar.attr('fill', graphProperties.axis.y.seriesColors[si]); }

                        });
                    }

                });

                return dataBars;

            } catch (err) {
                throw "Unable to create data bars: \r\n" + err;
            }

        },

        /*
        Generate lines for line chart
        */
        generateLines: function (parent, parentSvg, graphProperties, offsetX, offsetY) {

            // If the key property is not an array, convert it to one.
            if (!(jQuery.isArray(graphProperties.axis.y.key))) {
                graphProperties.axis.y.key = [graphProperties.axis.y.key];
            }

            var line = [];
            var s = 0;

            var xPositionFunction;
            if (graphProperties.axis.x.dataType === undefined) {
                xPositionFunction = function (d, i) { return parentSvg.xScale(i) + offsetX; };
            } else {
                var xValueFunction = this.getValueFunction(graphProperties.axis.x.key, graphProperties.axis.x.dataType);
                xPositionFunction = function (d, i) {
                    var val = xValueFunction(d, i);
                    var pos = parentSvg.xScale(val) + offsetX;
                    return pos;
                };
            }

            for (s = 0; s < graphProperties.axis.y.key.length; s++) {
                line.push(d3.svg.line()
                    .x(xPositionFunction)
                    .y(function (d) { return parentSvg.yScale(d[graphProperties.axis.y.key[s]]) + offsetY; })
                );
            }

            try {

                var returnLines = {
                    container: parent.append('g'),
                    lines: []
                };

                // Loop through the array adding each value as a series on the graph
                for (s = 0; s < line.length; s++) {
                    returnLines.lines.push(returnLines.container.append('path')
                        .datum(parentSvg.dataSet)
                        .attr("d", line[s])
                        .style('fill', 'none')
                        .style('stroke', graphProperties.axis.y.seriesColors[s])
                        .style('stroke-width', '1.5px')
                    );
                }

                return returnLines;

            } catch (outerErr) {
                throw "Error drawing lines: \r\n" + outerErr;
            }

        },

        /*
        Generates axis labels for a chart
        */
        generateAxisLabels: function (parent, parentSvg, graphProperties, xScaleFunction, offsetX, offsetY) {

            function xAxisCoord(d, i) {
                var centre = xScaleFunction(i + 0.5);

                return {
                    y: parentSvg.height + offsetY + 20,
                    x: offsetX + centre
                };
            }

            try {

                var axis = parent.append("g").attr("class", "axis x");

                axis.selectAll('text')
                    .data(parentSvg.dataSet)
                        .enter()
                            .append('text')
                            .text(function (d) { return d[graphProperties.axis.x.label === undefined ? graphProperties.axis.x.key : graphProperties.axis.x.label]; })
                            .attr('text-anchor', 'middle')
                            .attr('transform', function (d, i) {

                                var coord = xAxisCoord(d, i);
                                var translate = 'translate(' + coord.x + ',' + coord.y + ')';

                                return graphProperties.axis.x.labelTransformation === undefined ? translate : translate + graphProperties.axis.x.labelTransformation;
                            })
                            .classed('highlight', function (d) {
                                return (graphProperties.axis.x.highlightKey !== undefined &&
                                    d[graphProperties.axis.x.highlightKey] !== undefined &&
                                    d[graphProperties.axis.x.highlightKey] === true);
                            });

                return axis;

            } catch (err) {
                throw "Unable to create axis labels: \r\n" + err;
            }

        },

        /*
        Generates the grid for a bar chart.
        */
        generateAlignedGridForBarChart: function (graphProperties) {

            try {

                // If debug is defined as a property and the developer window is open, enter debug mode.
                if (graphProperties.grid.debug !== undefined) {
                    debugger;
                }

                // Validate the grid properties
                if (graphProperties.grid.data === undefined) { throw "No dataset was provided."; }
                if (graphProperties.grid.definition === undefined) { throw "No grid definition was provided."; }

                var result = {
                    rows: []
                };

                // Get the keys in the same order as the chart
                var colKeys;
                try {
                    colKeys = underscoreJS(graphProperties.chart.data).pluck(graphProperties.chart.axis.x.key);
                } catch (err) {
                    throw "Cannot obtain chart column keys: " + err;
                }

                // Create the grid table
                result.grid = graphProperties.parent.append('table').classed('grid', true);
                result.grid.width = graphProperties.width - graphProperties.chart.legend.width;
                var dataWidth = graphProperties.width - graphProperties.chart.axis.y.width - graphProperties.chart.legend.width;
                result.grid.dataCellWidth = dataWidth / colKeys.length;
                result.grid.style('width', result.grid.width + 'px');

                underscoreJS(graphProperties.grid.definition).each(function (rowDefinition, rowIndex) {

                    result.rows.push(result.grid.append('tr'));

                    // Create the row label
                    result.rows[rowIndex].append('td')
                        .style('width', graphProperties.chart.axis.y.width + 'px', 'important')
                        .text(rowDefinition.label)
                        .classed('gridheader', true);

                    // Create each column for the row
                    underscoreJS(colKeys).each(function (xKey, colIndex) {

                        var record = underscoreJS(graphProperties.grid.data).filter(function (row) {

                            var gridKey = (graphProperties.grid.axis === undefined
                                || graphProperties.grid.axis.x === undefined
                                || graphProperties.grid.axis.x.key === undefined)
                                    ? graphProperties.chart.axis.x.key
                                    : graphProperties.grid.axis.x.key;

                            return row[gridKey] === xKey;

                        });

                        var cellData = '-';
                        if (record.length && record[0][rowDefinition.field] !== null) {
                            cellData = rowDefinition.formatter === undefined ? record[0][rowDefinition.field] : rowDefinition.formatter(record[0][rowDefinition.field]);
                        }

                        result.rows[rowIndex].append('td')
                            .text(cellData)
                            .style('table-layout', 'fixed', 'important') // These styles must be applied to ensure the table is aligned.
                            .style('width', result.grid.dataCellWidth + 'px', 'important')
                            .style('padding-left', '0px')
                            .style('padding-right', '0px');
                    });

                });

                result.properties = graphProperties.grid;
                return result;

            } catch (outerErr) {
                throw "Unable to create aligned grid for bar chart: \r\n" + outerErr;
            }

        },

        /*
        Generates the legend for a chart
        */
        generateLegend: function (parent, graphProperties) {

            // Set legend defaults if not supplied
            if (graphProperties.legend.position === undefined) { graphProperties.legend.position = "right"; }
            if (graphProperties.legend.labels === undefined) { graphProperties.legend.labels = graphProperties.axis.y.key; }

            // HACK: Allow graph to display full size for a custom legend position
            if (graphProperties.legend.width === undefined) {
                if (graphProperties.legend.position === "custom") {
                    graphProperties.legend.width = 0;
                } else {
                    graphProperties.legend.width = 200;
                }
            }

            // Create the legend
            var legend = parent.append("div").classed("legend", true);
            var s = 0;

            for (s = 0; s < graphProperties.legend.labels.length; s++) {
                var entry = legend.append("div").classed("legendEntry", true);

                entry.append("span")
                    .classed("colorFill", true)
                    .style("background-color", graphProperties.axis.y.seriesColors[s]);

                entry.append("span")
                    .text(graphProperties.legend.labels[s]);
            }

            // Move the legend into to correct location
            legend.style("position", "absolute")
                .style("left", graphProperties.width - graphProperties.legend.width + 50)
                .style("top", (graphProperties.height - legend[0][0].clientHeight) / 2);

            return legend;

        }

    };

    return graphs;
});