define([
     'underscore'
    ,'d3'
], function (_, d3) {
'use strict';

var pd = preprocess;
return pd;

function preprocess(data) {
	var isNumeric = /^\d+(\.\d+)?$/;

    return {
    	 data: _.map(data, tryParseNumericProperties)
    };

    function tryParseNumericProperties(datum) {
    	return _.mapObject(datum, function(val, key){
    		return [key, tryParseNumeric(val)];
    	});
    }
    function tryParseNumeric(val) {
    	return isNumeric.test(val) ? parseFloat(val, 10) : val;
	}
}

});