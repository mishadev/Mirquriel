define([
    'd3'
], function (d3) {
'use strict';

var format = d3.format(',.2s'); // ,.2f for 2 decimal places, ,.2s for 2 significant figures

var simpleBarChart = function (ctxOrNot, opOrData) {
    var op, ctx = ctxOrNot;

    if(!isContext(ctxOrNot)) {
        ctx = this.s;
        opOrData = ctxOrNot;
    }
    
    op = (opOrData.data && opOrData) || { data: opOrData };

    _.defaults(op, {
         mainText:              "" 
        ,subText:               "" 
    });
    
    return buildChart(ctx, op);
}

return simpleBarChart;

function buildChart(node, op) {

    var dataExtent = [0, d3.max(op.data, function (d) { return +d.y; })]
    var chartSvg = node.append('svg');

    if(op.mainText)
        chartSvg.append('text').text(op.mainText)
            .attr('x', 200).attr('y', 155)
            .attr('class', 'twelve-point')
            .style('font-weight', 'bold').style('fill', 'rgb(237,114,27)');
    if(op.subText)
        chartSvg.append('text').text(op.subText)
            .attr('x', 200).attr('y', 180)
            .attr('class', 'twelve-point')
            .style('fill', 'rgb(237,114,27)');

    var yaxisTitle = chartSvg.append('text')
        .attr('class', 'y-axis-title ten-point')
        .attr('x', 65).attr('text-anchor', 'middle').attr('y', 340)
        .attr('transform', 'rotate(-90 65,270)');

    var chart = chartSvg.append('g').classed('chart-group', true);
    chart.attr('transform', 'translate(220,190)');
    //chart.barPadding = 5;
    chart.dataSet = op.data;
    chart.width = 750;
    chart.height = 170;
    chart.yScale = d3.scale.linear().domain(dataExtent).range([chart.height, 0]);
    chart.yAxis = d3.svg.axis().scale(chart.yScale).orient('left').ticks(5).tickFormat(format);
    chart.selectAll('rect')
        .data(chart.dataSet).enter()
        .append('rect')
            .attr('x', function (d, i) { return i * chart.width / chart.dataSet.length; })
            .attr('y', function (d) { return chart.yScale(d.y); })
            .attr('height', function (d) { return chart.height - chart.yScale(d.y); })
            .attr('width', chart.width / chart.dataSet.length / 2)
            .attr('fill', 'rgb(237,114,27)')
            .style('cursor', 'pointer')
            .attr('data-key', function (d) { return d.xKey; })
            .attr('data-name', function (d) { return d.x; });
        
    // data labels
    chart.selectAll('text')
        .data(chart.dataSet).enter()
        .append('text').text(function (d) { return format(d.y); })
            .attr('x', function (d, i) { return 20 + i * chart.width / chart.dataSet.length; })
            .attr('y', function (d) { return chart.yScale(d.y) + 12; })
            .attr('text-anchor', 'middle')
            .attr('fill', 'white')
            .style('font-size', '12px');

    function xaxisCoord(d, i) {
        return {
            x: 15 + i * chart.width / chart.dataSet.length + (100 / chart.dataSet.length),
            y: chart.height + 10 // + (i % 2) * 20 to stagger them vertically 
        };
    }

    chart.append('g')
        .attr('class', 'axis').attr('transform', 'translate(-20,0)')
        .call(chart.yAxis);
    chart.selectAll('text.xaxis')
        .data(chart.dataSet).enter()
        .append('text').text(function (d) { return d.x; })
            .attr('class', 'xaxis')
            .attr('class', 'seven-point')
            .attr('text-anchor', 'end')
            .attr('x', function (d, i) { return xaxisCoord(d, i).x; })
            .attr('y', function (d, i) { return xaxisCoord(d, i).y; })
            .attr('transform', function (d, i) { return 'rotate(-45 ' + xaxisCoord(d, i).x + ',' + xaxisCoord(d, i).y + ')'; });

    chart.append('line')
        .attr('class', 'axis').attr('transform', 'translate(-20,0)')
        .attr('x1', 0).attr('y1', chart.height)
        .attr('x2', chart.width).attr('y2', chart.height);

    return chartSvg;
}

function isContext(obj) { return obj instanceof d3.selection || obj instanceof d3.selection.enter }

});