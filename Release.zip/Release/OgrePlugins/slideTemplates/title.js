﻿define(function () {

    return {
        name: "title",
        template: function (ogre, config) {
            /// <summary>
            /// Creates the default layout for a title slide.
            /// </summary>
            /// <param name="config">The JSON configuration object.</param>

            // Check required parameters
            if (!ogre) throw new Error("Ogre parameter is required.");
            if (!config) throw new Error("Config parameter is required.");
            if (!config.title) throw new Error("'title' property of config parameter is required.");

            // Supply defaults for optional parameters
            var subtitle = config.subtitle || "";
            var created = config.created || "";

            // Set slide class based on slide type
            ogre.s.classed('titleSlide', true);

            // Create slide content
            ogre.s.append('img').attr('src', ow.appPath + 'Images/client-logo.png').classed('logo', true);

            // Create the slide header
            var header = ogre.s.append('header');
            header.append('h1').text(config.title);
            header.append('h2').text(config.subtitle);

            // Create the slide footer
            var footer = ogre.s.append('footer');
            footer.append('p').text(created).classed('createdOn', true);

        }
    }

});