﻿define(function () {

    return {
        name: "master",
        template: function (ogre, config) {
            /// <summary>
            /// Creates the default layout for a generic slide.
            /// </summary>
            /// <param name="config">The JSON configuration object.</param>
            /// <returns>A d3 div element to be used for the content of the slide.</returns>

            // Check required parameters
            if (!ogre) throw new Error("Ogre parameter is required.");
            if (!config) throw new Error("Config parameter is required.");
            if (!config.title) throw new Error("Title is required.");

            // Supply defaults for optional parameters
            var subtitle = config.subtitle || "";
            var confidential = config.confidential || "";

            // Create the slide header
            var header = ogre.s.append('header');
            header.append('h1').text(config.title);
            header.append('h2').text(config.subtitle);

            // Create the slide footer
            // Note: Add the footer first so that we can dynamically size the content pane.
            var footer = ogre.s.append('footer');
            footer.append('hr');
            footer.append('img').attr('src', ow.appPath + 'Images/client-logo.png').classed('logo', true);
            footer.append('div').text(confidential).classed('confidential', true);
            footer.append('p').text(ogre.b.pageNumber - 1).classed('pagenum', true);

            // Create the slide content area
            var contentPane = ogre.s.append('div').classed('contentPane', true);

            return contentPane;

        }
    };

});