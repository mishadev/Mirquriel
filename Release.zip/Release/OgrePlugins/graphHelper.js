define([
    'd3',
    'underscore',
	'../OgrePlugins/textWrapper'
], function (d3, _, textWrapper) {
    'use strict';

    var graphHelper = {

        textTransformations: {

            // Wrap x-axis labels
            // - This function checks the length of the x-axis label and wraps words onto new
            //   lines if required. It will also wrap individual words onto new lines (via a '-') if
            //   the word is too long.
            //
            // input - graph object and chart data (d.chart)
            wrapXAxisLabels: function (graph, data) {

                _.each(data, function (e, i) {

                    // calculates the corrected offset for the text wrapping when a max bar width
                    // value is specified.
                    var barWidth = graph.axisScales.x(0.75),
                        offsetX = (barWidth / 2);

                    if (graph.properties.axis !== undefined
                        && graph.properties.axis.x !== undefined
                        && graph.properties.axis.x.maxBarWidth !== undefined) {
                        offsetX = Math.min(offsetX, graph.properties.axis.x.maxBarWidth);
                    }

                    // Declare variables
                    var text = d3.select(graph.axis.x[0][0].childNodes[i]),
						initialText = text.text(),
                        tspan = text.text(null).append("tspan").attr("dx", (-offsetX) + 3),
						isTooLongLine = function isTooLong(input) {
							tspan.text(input);
							return tspan.node().getComputedTextLength() >= barWidth;
						};
                    text.attr("text-anchor", "start");

					var lines = textWrapper.wrap(initialText, isTooLongLine);
					tspan.text(_.first(lines));
					_.each(_.rest(lines), function (line) {
						tspan = text.append("tspan").text(line).attr("dy", "1.1em").attr("dx", -tspan.node().getComputedTextLength());
					});
                });
            }
        }
    };

	return graphHelper;
});