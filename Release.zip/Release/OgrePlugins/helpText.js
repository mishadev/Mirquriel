﻿define([], function () {
    "use strict";

    /// <summary>
    /// Contains methods for generating help text boxes on OGRE slides.
    /// </summary>

    var defaults = {
        width: 400,
        callout: {
            offset: 10,
            length: 40,
            width: 25
        }
    },
    helpText = {
        createHelpTextBox: function (defaultParent, parameters) {
            if (arguments.length < 2) {
                throw 'createHelpTextBox :: Parameters object or parameters array for help text box not supplied.';
            }

            // If an object was provided for the parameters, wrap it in an array. This allows the function to be used 
            // for creating single or multiple help text boxes.
            if (Object.prototype.toString.call(parameters) !== '[object Array]') {
                parameters = [parameters];
            }

            // Loop through the parameter objects for each help text object
            parameters.forEach(function (p, index) {
                var outerElement,
                    textBoxElement,
                    c,
                    boxHeight,
                    boxWidth,
                    aX,
                    aY,
                    bX,
                    bY,
                    cX,
                    cY,
                    hypotenuse,
                    borderWidth = 0,
                    textLeft = 0,
                    textTop = 0,
                    jQTextBox,
                    CALLOUT_POSITIONS = ['top left', 'top right', 'right top', 'right bottom', 'bottom right', 'bottom left', 'left bottom', 'left top'];

                // delete null text / html properties (i.e., treat these as undefined when null)
                if (p.text === null) {
                    delete p.text;
                }

                if (p.html === null) {
                    delete p.html;
                }

                // Validate parameters: text and html properties are mutually exclusive
                if (p.text === undefined && p.html === undefined) {
                    throw 'createHelpTextBox :: Parameters object at index ' + index + ' does not have a valid "text" or "html" property supplied.';
                }

                if (p.text !== undefined && p.html !== undefined) {
                    throw 'createHelpTextBox :: Parameters object at index ' + index + ' cannot have both "text" or "html" properties defined.';
                }

                // Determine horizontal position of text box
                p.x = p.x !== undefined && p.x > 0 ? p.x : 0;

                // Determine vertical position of text box
                p.y = p.y !== undefined && p.y > 0 ? p.y : 0;

                // Determine width of the text box
                p.width = p.width || defaults.width;

                // Trim the title of the text box if supplied
                p.title = p.title !== undefined
                    && typeof p.title === 'string'
                    && p.title.trim().length > 0
                        ? p.title.trim()
                        : null;

                // Detemine the parent D3 element to attach the help text box to
                p.parent = p.parent || defaultParent;

                // Set the callout marker properties (see wiki page for details)
                if (typeof p.callout === 'string') {
                    p.callout = {
                        position: p.callout,
                        offset: defaults.callout.offset,
                        length: defaults.callout.length,
                        width: defaults.callout.width
                    };
                }

                // A callout marker is only used when it has a valid position indicator.
                if (typeof p.callout === 'object'
                    && p.callout.hasOwnProperty('position')) {
                    if (CALLOUT_POSITIONS.indexOf(p.callout.position.toLowerCase()) >= 0) {
                        p.callout.position = p.callout.position.toLowerCase();

                        // Define helper properties
                        p.callout.edge = p.callout.position.split(/\s/)[0];
                        p.callout.side = p.callout.position.split(/\s/)[1];

                        if (p.callout.offset === undefined || typeof p.callout.offset !== 'number') {
                            p.callout.offset = defaults.callout.offset;
                        }

                        if (p.callout.length === undefined || typeof p.callout.length !== 'number') {
                            p.callout.length = defaults.callout.length;
                        }

                        if (p.callout.width === undefined || typeof p.callout.width !== 'number') {
                            p.callout.width = defaults.callout.width;
                        }

                        p.callout.offset = p.callout.offset < 0 ? 0 : p.callout.offset;

                        textTop = p.callout.edge === 'top' ? p.callout.length : 0;
                        textLeft = p.callout.edge === 'left' ? p.callout.length : 0;
                    }
                    else {
                        throw 'createHelpTextBox :: Parameters object at index ' + index + ' has invalid callout position value "' + p.callout.position.toString() + '".';
                    }
                }
                else {
                    p.callout = null;
                }

                // Ensures multiple help boxes overlap gracefully
                parameters.zIndex = index + 1;

                // the text content of the text box; each member of the array is created as a paragraph.
                if (p.text !== undefined
                    && Object.prototype.toString.call(p.text) !== '[object Array]') {
                    p.text = [p.text];
                }

                // the text content of the text box; all members of the array are concatenated into one HTML string.
                if (p.html !== undefined
                    && Object.prototype.toString.call(p.html) !== '[object Array]') {
                    p.html = [p.html];
                }

                // CCS class(es) to apply to the text box (in addition to the "help" class that all text boxes receive)
                if (p.cssClass === undefined) {
                    p.cssClass = [];
                } else if (Object.prototype.toString.call(p.cssClass) !== '[object Array]') {
                    p.cssClass = [p.cssClass];
                }

                // add the mandatory 'help' class to the beginning of the list of classes
                p.cssClass.unshift('help');

                // begin rendering the elements - the callout textbox is placed within a parent div to allow the
                // callout triangle to be positioned above or to the left of it, if required.
                outerElement = p.parent.append('div')
                    .style('position', 'absolute')
                    .style('top', p.y)
                    .style('left', p.x)
                    .style('z-index', parameters.zIndex);

                textBoxElement = outerElement.append('div')
                    .style('position', 'absolute')
                    .style('top', textTop)
                    .style('left', textLeft)
                    .style('width', p.width || null)
                    .attr('class', p.cssClass.join(" "));

                // add the title text if it exists
                if (p.title !== null) {
                    textBoxElement.append('h6')
                        .text(p.title);
                }

                // add the tooltip's content as paragraphs or HTML, depending which property is used
                if (p.text !== undefined) {
                    p.text.forEach(function (paragraphText) {
                        textBoxElement.append('p')
                            .text(paragraphText);
                    });
                }

                if (p.html !== undefined) {
                    // join HTML using carriage returns for easier debugging
                    textBoxElement.html(p.html.join(String.fromCharCode(13)));
                }

                if (p.callout !== null) {
                    // draw the callout marker if it has been specified
                    boxHeight = textBoxElement.node().offsetHeight;
                    boxWidth = textBoxElement.node().offsetWidth;
                    jQTextBox = $(textBoxElement.node());
                    borderWidth = parseFloat(jQTextBox.css('border-width'));

                    c = p.callout;

                    // the callout marker is translated to the absolute position of point 'A'
                    aX = c.edge === 'left' ? borderWidth :
                        (c.edge === 'right' ? boxWidth - borderWidth :
                            (c.side === 'left' ? c.offset :
                                (boxWidth - c.offset < 0 ? c.width : boxWidth - c.offset)));
                    aX += textLeft;

                    aY = c.edge === 'top' ? borderWidth :
                        (c.edge === 'bottom' ? boxHeight - borderWidth :
                            (c.side === 'top' ? Math.min(c.offset, boxHeight - c.width) :
                                (boxHeight - c.offset < 0 ? c.width : boxHeight - c.offset)));
                    aY += textTop;

                    // Points 'B' and 'C' of the callout marker are calculated relative to point 'A'
                    // (point 'A' has co-ordinates of [0,0])
                    bX = c.edge === 'left' ? -c.length : c.edge === 'right' ? c.length : 0;
                    bY = c.edge === 'top' ? -c.length : c.edge === 'bottom' ? c.length : 0;

                    cX = c.edge === 'left' ? 0 :
                        (c.edge === 'right' ? 0 : (
                            c.side === 'left' ? c.width : -c.width));
                    cY = c.edge === 'top' ? 0 :
                        (c.edge === 'bottom' ? 0 : (
                            c.side === 'top' ? c.width : -c.width));

                    // Calculate hypotenuse and use this to only draw a border on two sides of the callout
                    // marker triangle (using the 'stroke-dasharray' property)
                    hypotenuse = Math.sqrt(Math.pow(c.length, 2) + Math.pow(c.width, 2));

                    outerElement.append('svg')
                        .append('g')
                            .attr('transform', 'translate(' + aX + ',' + aY + ')')
                            .append('polygon')
                                .attr('stroke-linecap', 'butt')
                                .attr('stroke-dasharray', (c.length + hypotenuse) + ',' + c.width)
                                .attr('class', p.cssClass.join(" "))
                                .attr('points', '0,0 ' + bX + ',' + bY + ' ' + cX + ',' + cY)
                                // map the text box CSS properties to equivalent SVG styles for the callout
                                .style('fill', jQTextBox.css('background-color'))
                                .style('stroke', jQTextBox.css('border-color'))
                                .style('stroke-width', jQTextBox.css('border-width'));
                }
            });

            return parameters;
        }
    };

    return helpText;
});