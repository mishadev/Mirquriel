define([
    'd3'
], function (d3) {
'use strict';

var defaultReplacements = {
    'netSalesChangeVsLy': 'Index Umsatz VJ',
    'percentNetScanMargin' : 'Nettomarge',
    'percentNetScanMarginPointsChangeVsLy' : 'Diff. Nettomarge VJ %-Pkt',
    'percentGrossMargin' : 'Bruttomarge',
    'percentGrossMarginPointsChangeVsLy' : 'Diff. Bruttomarge VJ %-Pkt',
    'percentOfNetSalesOnPromo' : 'Anteil Aktionsumsatz %',
    'percentOfNetSalesOnPromoChangeVsLy' : 'Diff. Aktionsumsatz VJ %-Pkt'
};

var simpleTableGrid = function (ctxOrNot, opOrData) {
    var op, ctx = ctxOrNot;

    if(!isContext(ctxOrNot)) {
        ctx = this.s;
        opOrData = ctxOrNot;
    }
    
    op = (opOrData.data && opOrData) || { data: opOrData };

    _.defaults(op, {
         replacements:          defaultReplacements
        ,currencyFormat:        d3.format(',.2f')
    });
    
    return buildGrid(ctx, op);
}

return simpleTableGrid;

function buildGrid(node, op) {
    var grid = node.append('table');

    var gridRowGroups = grid.selectAll('tr')
        .data(op.data).enter()
        .append('tr').attr('class', function (d, i) { return (i % 2) ? 'odd-row' : '' });

    gridRowGroups.append('td')
        .text(function (d) { return displayTextFor(d.label, op.replacements); });

    gridRowGroups.selectAll('td.cells')
        .data(function (d) { return d.data; })
        .enter().append('td')
        .attr('class', 'cells')
        .text(function (d) {  return op.currencyFormat(d); })
        .attr('text-anchor', 'end');

    return grid;
}

function displayTextFor(colName, replacements) {
    return replacements[colName] || colName;
}

function isContext(obj) { return obj instanceof d3.selection || obj instanceof d3.selection.enter }

});