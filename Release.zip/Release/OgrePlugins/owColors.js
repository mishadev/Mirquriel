﻿/*global define*/
/*jslint unparam: true, vars: true, browser: true, indent: 4, maxerr: 10, maxlen: 100 */
define(function () {
    'use strict';

    var darkSapphire = '#002C77';
    var owSapphire = '#008AB3';
    var lightSapphire = '#9DE0ED';
    var owOnyx = '#5F5F5F';
    var lightOnyx = '#BEBEBE';
    var owTopaz = '#E29815';
    var lightTopaz = '#FFCF89';
    var owEmerald = '#41A441';
    var lightEmerald = '#BDDDA3';
    var owIolite = '#646EAC';
    var lightIolite = '#C5CAE7';
    var owCitrine = '#DD712C';
    var lightCitrine = '#FDCFAC';
    var owTurquoise = '#079B84';
    var lightTurquoise = '#A8DAC9';
    var owRuby = '#CB225B';
    var lightRuby = '#F8B8BC';

    var colors = {
        darkSapphire: darkSapphire,
        owSapphire: owSapphire,
        lightSapphire: lightSapphire,
        owOnyx: owOnyx,
        lightOnyx: lightOnyx,
        owTopaz: owTopaz,
        lightTopaz: lightTopaz,
        owEmerald: owEmerald,
        lightEmerald: lightEmerald,
        owIolite: owIolite,
        lightIolite: lightIolite,
        owCitrine: owCitrine,
        lightCitrine: lightCitrine,
        owTurquoise: owTurquoise,
        lightTurquoise: lightTurquoise,
        owRuby: owRuby,
        lightRuby: lightRuby,

        orderedChartColors: [
            owSapphire,
            lightSapphire,
            owOnyx,
            lightOnyx,
            owTopaz,
            lightTopaz,
            owEmerald,
            lightEmerald,
            owIolite,
            lightIolite,
            owCitrine,
            lightCitrine,
            owTurquoise,
            lightTurquoise,
            owRuby,
            lightRuby
        ],

        orderedLineChartColors: [
            owEmerald,
            owIolite,
            owCitrine,
            owTopaz,
            owTurquoise,
            owRuby,
            lightEmerald,
            lightIolite,
            lightCitrine,
            lightTopaz,
            lightTurquoise,
            lightRuby
        ]
    };

    return colors;
});