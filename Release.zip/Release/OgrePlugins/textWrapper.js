﻿define(['underscore'], function textWrapper() {
	function wrapReducer(separator, isTooLong) {
		this.reduce = function (lines, item) {
			var line = lines.pop(),
				contender = trim(line + separator + item, separator);
			if (isTooLong(trim(contender, '-'))) { //ignore initial '-'
				if (!_.isEmpty(line))
					lines.push(line); //done

				lines.push(item); //next
			} else {
				lines.push(contender); //next
			}
			return lines;
		}

		var trim = function (input, target) {
			if (!input || !target)
				return input;

			target = escape(target);
			var rx = new RegExp("^" + target + "|" + target + "$", 'gm');
			return input.replace(rx, '');
		}
		var escape = function (input) {
			//this regexp is used for escape system characters such (?, $, ect)
			return input.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
		}
	}

	return {
		wrap: function (text, isTooLong) {
			text = text.trim();
			if (!isTooLong(text)) return [text];

			var wordWrap = new wrapReducer(' ', isTooLong),
				charWrap = new wrapReducer('', isTooLong),
				lines = _.chain(text.split(/\s+/))
					.reduce(_.bind(wordWrap.reduce, wordWrap), [''])
					.map(function (line) {
						if (!_.contains(line, ' ') && isTooLong(line)) { //it's long word
							return _.chain(line.split(''))
								.reduce(_.bind(charWrap.reduce, charWrap), [''])
								//we don't know lines.length, so let's reverse
								.reverse()
								.map(function (line, idx) { //add '-' to end of all lines except the last one (the first one after reverse)
									return (idx !== 0 && _.last(line) !== '-') ? line + '-' : line;
								})
								.reverse()
								.value();
						}
						return line;
					})
					.flatten()
					.value();

			return lines;
		}
	}
});