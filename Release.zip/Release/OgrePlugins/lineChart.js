define([
	 'underscore'
	,'d3'
    ,'../OgrePlugins/toolbox'
],
function lineChart(_, d3, toolboxFn) {
'use strict'


var lineChart = function (ctxOrNot, op) {
    var ctx = ctxOrNot;
    if(!isContext(ctxOrNot)) {
    	ctx = this.s;
    	op = ctxOrNot;
    }

    _.ensureHasKeys(op, 'data');
    _.defaults(op, {
         line: d3.svg.line().x(_.identity).y(function(d,i){return i})
        ,xExtent: [0, op.data.length]
        ,yExtent: d3.extent(op.data)
    });

    var toolbox = toolboxFn.call(this);
    ctx = ctx.append('g').attr('class','line-chart');

    drawLine();

    if(op.axis) {
      var ax = op.axis;
      _.ensureHasKeys(ax, 'xScale', 'yScale')
      _.defaults(ax,{
         ticks: false
        ,xLine: true
      });
      if(ax.ticks === true) ax.ticks = {};          //ticks: true should be the same as an empty object (with all default properties)
      if(ax.xLine === true) ax.xLine = defaultXLine;
      if(ax.yLine === true) ax.yLine = defaultYLine;
      
      ax.xLine && ax.xLine(ctx, ax.xScale, ax.yScale);
      ax.yLine && ax.yLine(ctx, ax.xScale, ax.yScale);
      ax.ticks && drawTicks(ax.ticks, ax.xScale, ax.yScale);
    }
    return ctx;

    function drawLine() {
      return ctx.append('path')
                .attrObj({
                   d: op.line(op.data)
                  ,'class': 'line-chart-line'
                  ,fill: 'none'
                  ,stroke: 'black'
                })
    }

    function drawTicks(ticks, xScale, yScale) {
        _.defaults(ticks, {x: true, y: true});

        if(ticks.x===true) ticks.x = {};
        if(ticks.y===true) ticks.y = {};

        _.defaults(ticks.x, {
             y: yScale(op.yExtent[0])
            ,ticks: xScale.ticks(op.xExtent[1]-op.xExtent[0])
            ,text: _.identity
        });
        _.defaults(ticks.y, {
             x: xScale(op.xExtent[0])
            ,ticks: yScale.ticks(op.yExtent[1]-op.yExtent[0])
            ,text: _.identity
        });

        if(ticks.x) {
            ctx.selectAll('.xLabel')
              .data(ticks.x.ticks)
              .enter().append('text')
              .text(ticks.x.text)
              .attr('class', 'xLabel')
              .attr('x', xScale)
              .attr('y', ticks.x.y)
              .attr('dx', -8);
        }
        if(ticks.y) {
            ctx.selectAll('.yLabel')
              .data(ticks.y.ticks)
              .enter().append('text')
              .text(ticks.y.text)
              .attr('class', 'yLabel')
              .attr('x', ticks.y.x)
              .attr('y', yScale)
              .attr('dy', 4);
        }
    }

    function defaultXLine(ctx, xScale, yScale) {
      toolbox.line(ctx, {
        x1: xScale(op.xExtent[0]), y1: yScale(op.yExtent[0]),
        x2: xScale(op.xExtent[1]), y2: yScale(op.yExtent[0]),
      }).attr('class', 'x-axis');
    }
    function defaultYLine(ctx, xScale, yScale) {
      toolbox.line(ctx, {
        x1: xScale(op.xExtent[0]), y1: yScale(op.yExtent[0]),
        x2: xScale(op.xExtent[0]), y2: yScale(op.yExtent[1]),
      }).attr('class', 'y-axis');
    }
};

return lineChart;

function isContext(obj) { return obj instanceof d3.selection || obj instanceof d3.selection.enter }
function noop() {}
});