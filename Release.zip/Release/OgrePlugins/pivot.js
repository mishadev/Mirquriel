define(function pivot() {

var pivot = function (data, colKeys, keyField) {
    var label;
    // gridRows[0] will be the first row, 
    // gridRows[0].data[2] is the 3rd element in first row,
    // gridRows[0].label is the label for the first row
    var gridRows = [];

    // Set up one row in gridRows for each column in data[0] (assume following data elements have same columns as data[0])
    for (label in data[0]) {
        if (data[0].hasOwnProperty(label)) {
            gridRows.push({ label: label, data: [] });
        }
    }

    function findKey(key, array) {
        var i;
        for (i = 0; i < array.length; i++) {
            if (array[i][keyField] === key) {
                return array[i];
            }
        }
    }

    // populate gridRows
    var cell, srcColumn, value, rowLabel;
    for (i = 0; i < gridRows.length; i++) {
        rowLabel = gridRows[i].label;
        for (j = 0; j < colKeys.length; j++) {
            var colKey = colKeys[j];
            srcColumn = findKey(colKey, data);
            value = srcColumn[rowLabel];
            gridRows[i].data.push(value);
        }
    }
    return gridRows;
};

return pivot;

});