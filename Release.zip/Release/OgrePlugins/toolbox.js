define([
	 'underscore'
	,'d3'
],
function toolbox(_, d3) {
'use strict'

var toolbox = function () {
    var  svg = this.s
    	,exportFn = _.compose(setContext, paramsOrOptions);		//standard set of function export wrappers

    return {
    	 wrappingText: 	exportFn(wrappingText, 'x', 'y', 'width', 'height')
    	,table: 		exportFn(table, 'x', 'y', 'width', 'height', 'rows')
    	,rect: 			exportFn(rect, 'x', 'y', 'width', 'height', 'fill', 'stroke')
    	,line: 			exportFn(line, 'x1', 'y1', 'x2', 'y2', 'stroke')
    	,translatedGroup:exportFn(translatedGroup, 'left', 'top', 'margins')
        ,adjustedDecimalDomain: adjustedDecimalDomain
    }

    function isContext(obj) { return obj instanceof d3.selection || obj instanceof d3.selection.enter }
    function setContext(fn) {											//if the first object is a d3, pass it as 'this', otherwise, pass svg
    	return function setContext(d3SelectionOrNot) {
    		if(isContext(d3SelectionOrNot))
    			return fn.apply(d3SelectionOrNot, _.tail(arguments));
    		return fn.apply(svg, arguments);
    	};
    }

}

return toolbox;

////////////////////////////////////////////////////////////
// Plugins
////////////////////////////////////////////////////////////


function wrappingText(op) {
	_.defaults(op, {x: 0, y: 0, width: 200, height: 800});
	return embeddedHtml.call(this, op).append('xhtml:p');
}

function table(table) {
	var tableEl = embeddedHtml.call(this, table).append('xhtml:table');
	configureHtmlFromObj(tableEl, table);
	_.each(table.rows, function(row,i){
		//TODO - GM - append classes for even/odd/row/colnum
		var rowEl = configureHtmlFromObj( tableEl.append('xhtml:tr'), row);
		addClasses(rowEl, 'r'+i, (i%2 ? 'even' : 'odd') );
		_.each(row.cells, function(cell){
			var cellEl = configureHtmlFromObj( rowEl.append('xhtml:td'), cell);
			addClasses(cellEl, 'c'+i, (i%2 ? 'even' : 'odd') );
		});
	});
	return tableEl;
}

function rect(op){
	_.defaults(op, {
		 x: 0 ,y: 0 ,width: 100 ,height: 100 ,fill: 'none',stroke: 'black'
	});
	return configureSvgFromObj(this.append('rect'), op);
}

function line(op){
	_.defaults(op, {
		 x1: 0, y1: 0, x2: 100, y2: 100, stroke: 'black'
	});
	return configureSvgFromObj(this.append('line'), op);
}

function translatedGroup(op){
	function margins(m){ return m.length==4 ? [m[3],m[0]] : m } 									// if there are 4 margins then take the 1st and 3rd
	var by = margins(op.margins ? op.margins : _.isArray(op.left) ? op.left : [op.left, op.top]); 	//allow left,top, or a margins key, if margins are in the left key figure it out
	_.defaults(by, [0,0]);
	return this.append('g').attr('transform', 'translate('+by[0]+','+by[1]+')')
}

function adjustedDecimalDomain(naturalMin, naturalMax, decimalPlaces, numberOfTicks) {
    // Use case: https://trello.com/c/MbpBpZMb/69-add-a-minimum-unit-for-a-chart-scale
    // Line graphs with very close Y values can suffer from duplicate tick marks when a format (eg 2-decimal-places) is specified 
    decimalPlaces = decimalPlaces === undefined ? 2 : decimalPlaces;
    numberOfTicks = numberOfTicks === undefined ? 10 : numberOfTicks; // 10 is default number of ticks (https://github.com/mbostock/d3/wiki/SVG-Axes)
    var min, max;
    var minimumTickIncrement = Math.pow(10, -1 * decimalPlaces);
    // if natural domain is not enough to differentiate ticks (multiple ticks with same displayed value), expand it
    if ((naturalMax - naturalMin) < minimumTickIncrement * numberOfTicks) {
        min = naturalMin * (1 - minimumTickIncrement * numberOfTicks / 2);
        max = naturalMax * (1 + minimumTickIncrement * numberOfTicks / 2);
    } else {
        min = naturalMin;
        max = naturalMax;
    }
    return [min, max];
}

////////////////////////////////////////////////////////////
// Helpers
////////////////////////////////////////////////////////////

function embeddedHtml(op) {
	return this.append('foreignObject')
	  .attr('width', op.width)
	  .attr('height', op.height)
	  .attr('x', op.x)
	  .attr('y', op.y)
	  .attr('requiredFeatures','http://www.w3.org/TR/SVG11/feature#Extensibility');
}

function configureHtmlFromObj(el, obj) {
	var  funcNames 		= ['text', 'html']
		,attrNames 		= ['id', 'class', 'width', 'height', 'colspan', 'rowspan']
		;
	_.each(_.pick(obj, attrNames), function(val, attrName) {
		el = el.attr(attrName, val);
	});
	_.each(_.pick(obj, funcNames), function(val, fnName){
		el = el[fnName](val);
	});
	return el;
}
function configureSvgFromObj(el, obj) {
	var  funcNames 		= ['text', 'html']
		,attrNames 		= ['x', 'y', 'width', 'height', 'fill', 'stroke', 'x1', 'y1', 'x2', 'y2']
		;
	_.each(_.pick(obj, attrNames), function(val, attrName) {
		el = el.attr(attrName, val);
	});
	_.each(_.pick(obj, funcNames), function(val, fnName){
		el = el[fnName](val);
	});
	return el;
}

function addClasses(el, classes) {
	classes = _.tail(arguments);
	var concatenatedClasses = _.reduce(classes, function(m, cn){ return m+' '+cn}, el.attr('class')||'');
	return el.attr('class', concatenatedClasses);
}

/*
	Wrap the given function in a parameter check: if the first param is an object, pass it to fn, otherwise create one from parameters (in order of paramNames)
		var printHiFn = function (p){
				console.log("Hello "+p.first +" "+p.last );
			},
			printHi = paramsOrOptions(printHiFn, 'first', 'last');
		printHi('Fred', 'Flintstone');
		//or
		printHi({first: 'Fred', last: 'Flintstone'});
*/
function paramsOrOptions(fn, paramNames) {		
	paramNames = _.tail(arguments);
	return function paramsOrOptions(maybeOpObj) {
    	if( _.isObject(maybeOpObj) && _.chain(maybeOpObj).keys().intersection(paramNames).any().value() )  //this is an object that contains as a key at least one of the parameter names
    		return fn.apply(this, arguments);
    	var  args = _.toArray(arguments)
    		,op = _.mapObject(paramNames, function(param, i){
    			return [param, args[i]];
	    	});
	    return fn.call(this, op);
	};
}

});