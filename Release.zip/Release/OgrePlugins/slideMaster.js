﻿/*global define*/
/*jslint unparam: true, vars: true, browser: true, indent: 4, maxerr: 10, maxlen: 100 */

/* DO NOT UPDATE the ~/OgrePlugins/slideMaster.js copy of this file, as it gets overwritten on deploy */
/* ONLY UPDATE the ~/Config/XXX/slideMaster.js copy of this file */

define(function () {
    'use strict';

    var slideMaster = function (o, config) {
        if (o != this) {
            config = o;
            o = this;
        }

        var header = o.s.append('div').classed('header', true);
        header.append('div').text(config.title).classed('title', true);
        header.append('div').text(config.subtitle).classed('subtitle', true);
        // remove header for now (not displayed in DTP deck for RMT)
        // header.append('img').classed('logo', true).attr('src', o.b.slideAssetsPath + 'Images/client-logo.png');

        var footer = o.s.append('div').classed('footer', true);
        footer.append('span').html('&copy; Oliver Wyman').classed('copyright', true);
        footer.append('span').text(o.b.pageNumber).classed('pagenumber', true);

        var contentPane = o.s.append('div').classed('contentPane', true);
        if (config.heading) contentPane.append('div').classed('heading', true).text(config.heading);
        if (config.subheading) contentPane.append('div').classed('subheading', true).text(config.subheading);
        contentPane.append('div').classed('source-field', true).text(config.source);
        return contentPane;
    };
    
    return slideMaster;
});