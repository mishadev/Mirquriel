﻿define([
    'underscore',
    // To add a template, simply add it to the list of files below in the same format.
    '../OgrePlugins/slideTemplates/master',
    '../OgrePlugins/slideTemplates/title'
], function (_) {
    'use strict'

    var ogre;

    // Determine the available templates for the arguments supplied to this function.
    var templates = _.object(_.map(_.tail(arguments), function (x) {
        return [
            x.name,
            // Generate a function to automatically supply the ogre slide-container object to the template function.
            function (config) { x.template(ogre, config) }
        ];
    }));

    // Return the plugin object.
    return function () {
    	// Store the slide-container object (in the layout code, referred to as "ogre" or "o") for later use. 
    	// Holds a reference to the slide object so plugins can attach elements to it.
        ogre = this;

        // Return the template objects.
        return templates;

    };

});