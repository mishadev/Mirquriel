define([
     'underscore'
    ,'d3'
],
function formatters(_, d3) {
    'use strict';

    ////////////////////////////////////////////////////////////
    // Plugins
    ////////////////////////////////////////////////////////////

    function fr(formatString, postfixCurrency) {
        if (!postfixCurrency) {
            postfixCurrency = '';
        }

        var d3format = d3.format(formatString);
        return function (number) {
            return d3format(number).replace(/,/g, ' ').replace('.', ',').replace(/G/, 'B').replace(/k/, 'K') + postfixCurrency;
        };
    }

    function toPascalCase(str, preserveWords) {
        // ensures known abbreviations are unaffected
        preserveWords = preserveWords === undefined ? [] : preserveWords;
        
        return str.replace(/\w\S*/g, function(txt) {
            if (preserveWords.indexOf(txt) === -1) {
                txt = txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
            }
        
            return txt;
        });
    }

    return {
        fr: fr,
        toPascalCase: toPascalCase
    };
});