define(function editableText() {

var editableText = function (ctxOrNot, label) {
    var ctx = ctxOrNot;
    if(!isContext(ctxOrNot)) {
    	ctx = this.s;
    	label = ctxOrNot;
    }
    return ctx.append(isSvg(ctx.node()) ? 'text' : 'span')
    	.attr('data-editable', true).attr('data-editablelabel', label);
}
return editableText;

function isContext(obj) { return obj instanceof d3.selection || obj instanceof d3.selection.enter }

function isSvg(node) {
	var  ancestors = _.chain([node]).union($(node).parents().toArray()).pluck('nodeName').invoke('toLowerCase').value()  //tag names of node up to the root
    	,svgLoc = _.indexOf(ancestors, 'svg')
    	;
    	//must have an ancestor <svg> without a closer <foreignObject>
    	return ~svgLoc &&  !_.contains( ancestors.slice(0, svgLoc), 'foreignObject' )
}
});