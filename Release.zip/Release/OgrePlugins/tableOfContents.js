﻿/*global define*/
/*jslint unparam: true, vars: true, browser: true, indent: 4, maxerr: 10, maxlen: 100 */
define(function () {
    'use strict';

    var tableOfContentsPlugin = function (o, config) {
        if (o != this) {
            config = o;
            o = this;
        }
        var contentPane = config.parentElement || o.s;
        var data = config.contents || [];

        var columnContainer = contentPane.append('div').attr('id', 'TableOfContents');
        var leftColumn = columnContainer.append('div').attr('id', 'left');
        var rightColumn = columnContainer.append('div').attr('id', 'right');
        _.each(data, function (d, i) {
            var thingToAppendTo = data.length > 3 && i >= data.length / 2 ? rightColumn : leftColumn;
            thingToAppendTo.append('h2').text(i + 1 + '. ' + d.header);
            if (d.items) {
                _.each(d.items, function (dd) {
                    thingToAppendTo.append('li').text(dd);
                });
            }
        });

        return contentPane;
    };

    return tableOfContentsPlugin;
});