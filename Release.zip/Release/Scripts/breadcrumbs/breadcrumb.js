﻿define(["jquery",
		"knockout",
		"underscore"],
	function ($, ko, _) {
		"use strict";
	
		//ViewModel for Breadcrumb Bar item containing user selected item + list of items depending on selection in previous item (parent)
		//Required to parentViewModel - previous bar item or null if it is first item
		//hierarchyParameterModel - the model for bar item containing: { DisplayName: "", EvaluationSource: "[{key: "1", desc: "1", parentKey: ""}, {key:"2", desc: "2", parentKey: ""}]"
		//userSelection: selected object
		//Name: system name of the bar item
		//DisplayName: user friendly name of the bar item
		//options: contains all options
		//availableOptions: contains options which can be chosen in current context
		return function breadcrumbs(parentViewModel, hierarchyParameterModel) {
			var options = _.sortBy(hierarchyParameterModel.Options, function (option) { return option.Description });

			var _viewModel = {
				userSelection: ko.observable()
				, options: ko.observableArray(options)
				, Name: ko.observable(hierarchyParameterModel.Name)
				, DisplayName: ko.observable(hierarchyParameterModel.DisplayName)
			};

			_viewModel.hasSelection = function () { return !!_viewModel.userSelection() };

			_viewModel.userSelection.subscribe(function (selection) {
				if (parentViewModel && selection && !parentViewModel.userSelection())
					parentViewModel.setUserSelection(selection.ParentKey);
			});
	
			if (parentViewModel)
				parentViewModel.userSelection.subscribe(function (selection) {
					_viewModel.userSelection(undefined);
				});

			_viewModel.setUserSelection = function (selectedKey) {
				if (selectedKey == null) {
					_viewModel.userSelection(undefined);
				} else {
					var option = _.findBy(_viewModel.availableOptions(), selectedKey, 'Key');
					if (option) _viewModel.userSelection(option);
				}
			};

			_viewModel.availableOptions = ko.computed(function () {
				var allOptions = _viewModel.options();
				if (!parentViewModel)
					return allOptions;
	
				var parentSelection = parentViewModel.userSelection();
				var relatedParentOptions = parentSelection ? [parentSelection] : parentViewModel.availableOptions();

				return _.filter(allOptions, function (option) {
					return _.findBy(relatedParentOptions, option.ParentKey, 'Key');
					});
			});

			//Returns false if the selectedKey is invalid. For instance when user type incorrect URL.
			_viewModel.setSelectedAndCheckIsValid = function (selectedKey) {
				var option = _.findBy(_viewModel.availableOptions(), selectedKey, 'Key');

				_viewModel.userSelection(option ? option : null);

				return !!option;
			};

			return _viewModel;
		}
	}
);