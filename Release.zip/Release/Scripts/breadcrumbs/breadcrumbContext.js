﻿define(["jquery",
		"knockout",
		"underscore",
		"breadcrumbs/breadcrumb"
],

	function ($, ko, _, breadcrumb) {
		"use strict";

		//ViewModel for the Breadcrumb Bar.
		//Requires to hierarchyModel to be passed to having {HierarchyParameters: [hierarchyParameter1, hierarchyParameter2]}
		//  to see hierarchyParameters API see hierarchyParametersViewModel
		//params: contains all hierarchyParamnetersViewModels
		//events.selectionChanged: Notifies when hierarchyParameter selection changed
		//allSelections: array of all selected hierarchyParameters in correct order
		//bannerClick: clears all selections - uses in _BreadcrumbBar.cshtml -> #client-logo-breadcrumb
		return function breadcrumbContext(hierarchyModel) {
			var _barViewModel = {
				 params:                 ko.observableArray(buildParameters(hierarchyModel))
				,events: {
					 selectionsChanged:  $.Callbacks()
				}
			};

			_barViewModel.allSelections				= ko.computed(getSelectionsKeys);
			_barViewModel.allSelectionsDescs		= ko.computed(getSelectionsDescriptions);
			_barViewModel.allSelectionsWithDescs	= ko.computed(getSelectionsWithDescs);

			_.each(_barViewModel.params(), function (param) {
				return param.userSelection.subscribe(function () {
					_barViewModel.events.selectionsChanged.fire(param.Name());
				});
			});

			_barViewModel.bannerClick = function () {
				_.each(_barViewModel.params(), function (p) {
					var isRootParameter = p.userSelection() && _.isNull(p.userSelection().ParentKey);
					isRootParameter && p.setUserSelection(undefined);
				});
			};

			return _barViewModel;

			function getValidSelections() {
				return _.filter(_barViewModel.params(), function (param) {
					return param.userSelection() && param.userSelection().Key !== null
				});
			}

			function getSelectionsWithDescs(){
				return _.extend(getSelectionsKeys(), getSelectionsDescriptions());
			}

			function getSelectionsKeys() {
				return _.mapObject(getValidSelections(), function (param) {
					return [param.Name(), param.userSelection().Key];
				});
			}

			function getSelectionsDescriptions() {
				return _.mapObject(getValidSelections(), function (param) {
					return [param.Name() + 'Desc', param.userSelection().Description];
				});
			}

			function buildParameters(hierarchyModel) {
				var previousParameter = null;
				return _.map(hierarchyModel.HierarchyParameters, function (parameterModel) {
					return previousParameter = breadcrumb(previousParameter, parameterModel);
				});
			}
		};
	});
