define(
['ogre.resizables', 'ow.widgets.persistState', 'ogre.widgets.slideSizeSlider', 'ogre.widgets.collapsible', 'ogre.widgets.slideWidgets', 'ogre.dialogs'],
function($) {
});