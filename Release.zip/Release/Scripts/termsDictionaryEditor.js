﻿define(['knockout'],
function(ko) {
	'use strict';
	
	return function() {
		var _termsEditor = {
			errorMessage:		ko.observable(''),
			uploadProgressValue:ko.observable(0),
			isProgressVisible:	ko.observable(false),
			uploadStart:		uploadStart,
			uploadDone:			uploadDone,
			uploadProgress:		uploadProgress,
			uploadFail:			uploadFail
		};
		return _termsEditor;

		function uploadStart(e, data) {
			_termsEditor.isProgressVisible(true);
			_termsEditor.uploadProgressValue(0);
			_termsEditor.errorMessage('');
		}

		function uploadDone(e, data) {
			_termsEditor.uploadProgressValue(100);
			setTimeout(function () { _termsEditor.isProgressVisible(false) }, 300);
		}

		function uploadProgress(e, data) {
			var progress = parseInt(data.loaded / data.total * 100, 10);
			_termsEditor.uploadProgressValue(progress);
		}

		function uploadFail(e, data) {
			_termsEditor.isProgressVisible(false);
			_termsEditor.errorMessage(data.jqXHR && data.jqXHR.responseJSON && data.jqXHR.responseJSON.ExceptionMessage || data.errorThrown || data.textStatus);
		}
	}
});