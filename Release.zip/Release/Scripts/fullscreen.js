/*
*	Sets or gets the fullscreen state whether fullscreen Api is supported or not.
* 
*	@param {boolean=} state
*		True to enable fullscreen mode, false to disable it. If not
*		specified then the current fullscreen state is returned.
*	@return {boolean|Element|jQuery}
*		When querying the fullscreen state then the current fullscreen
*		element is returned when browser is currently in full screen mode. 
*		False is returned if browser is not in full screen mode. 
*		When setting the fullscreen state then the current jQuery selection is returned for chaining.
*/
define([
	'jquery', 'underscore', 'modernizr',
	'jquery.fullscreen'
],
function (
	$, _, modernizr
) {
	'use strict'
	var beforeFullScreenState = null;

	return function(element, state) {
		var doc;

		// Do nothing when not an element
		if (!_.isElement(element) && !element.documentElement) return;

		// Find the real element and the document (Depends on whether the
		// document itself or a HTML element)
		if (element.ownerDocument)
			doc = element.ownerDocument;
		else
			doc = element, element = doc.documentElement;

		if(!modernizr.fullscreen){
			initImitation(doc);
			return fullScreenAPIImitation(doc, element, state);
		} else {
			return $(element).fullScreen(state); //use API
		}
	}
		
	function initImitation(doc) {
		if (!_.isFunction(doc["cancelFullScreen"])) {
			doc["cancelFullScreen"] = function () {
				try {
					exitFullScreen(doc);

					restoreWindowState();
					$(doc).trigger(new $.Event("fullscreenchange"));
				} catch (e) {
					$(doc).trigger(new $.Event("fullscreenerror"));
				}
			};
		}

		if (!_.isFunction(doc["requestFullScreen"])) {
			doc["requestFullScreen"] = function () {
				try {
					exitFullScreen(doc);
					enterFullScreen(doc, this);

					setFullScreenWindowState();
					$(doc).trigger(new $.Event("fullscreenchange"));
				} catch (e) {
					$(doc).trigger(new $.Event("fullscreenerror"));
				}
			};
		}
	}

	function exitFullScreen(doc) {
		doc["fullScreen"] = false;
		$(doc["fullScreenElement"]).removeClass('fullscreen');
		doc["fullScreenElement"] = undefined;
	}

	function enterFullScreen(doc, element) {
		doc["fullScreen"] = true;
		$(element).addClass('fullscreen');
		doc["fullScreenElement"] = element;
	}

	function setFullScreenWindowState() {
		saveWindowState();
		var state = getFullScreenWindowState();
		//we have to move window first then resize it
		if (state) {
			window.moveTo(state.left, state.top);
			window.resizeTo(state.width, state.height);
		}
	}

	function restoreWindowState() {
		var state = beforeFullScreenState;
		//we have to resize window first then move it
		if (state) {
			window.resizeTo(state.width, state.height);
			window.moveTo(state.left, state.top);
		}
	}

	function getFullScreenWindowState() {
		return {
			width: screen.availWidth,
			height: screen.availHeight,
			top: 0,
			left: 0
		};
	}

	function saveWindowState() {
		beforeFullScreenState = {
			width: window.outerWidth,
			height: window.outerHeight,
			top: window.screenY,
			left: window.screenX
		};
	}

	function fullScreenAPIImitation(doc, element, state) {
		// When no state was specified then return the current state.
		if (state == null) {

			// Check fullscreen state
			state = !!doc["fullScreen"];
			if (!state) return state;

			// Return current fullscreen element
			return doc["fullScreenElement"];
		}

		// When state was specified then enter or exit fullscreen mode.
		if (state)
			doc["requestFullScreen"].call(element); // Enter fullscreen
		else
			doc["cancelFullScreen"].call(doc); // Exit fullscreen

		return $(element);
	}
});
