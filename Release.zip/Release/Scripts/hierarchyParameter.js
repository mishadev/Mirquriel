﻿define(
['knockout', 'underscore', 'apiUrls', 'knockout-hashParamerterBinding', 'knockout.mapping'],
function (ko, _, api, hashParamerterBinding, mapping) {
    'use strict';

    var SQL_PARAM_REGEX = /@(\w+)/g; // @-character followed by one or more non-whitespace characters

    return function createParam(config) {
        var dependencies = config.publish
            , getAllSelections = config.getAllSelections          
            , getParamOptions = config.getParamOptions || getDefaultParamOptions
            , choicesUpdated = fireChoicesUpdated(config.choicesUpdated)

            , xhrEvaluationRequest // hold reference to ajax request, so we can abort the in-flight request if we make a new request before in-flight one has completed
        ;

        var mappedParam = mapping.fromJS(mapping.toJS(config.data), { copy: ['Id'] });
        var _param = _.extend({
             DefaultSelection: ko.observable(null)
            , userSelection: ko.observable(null)
            , evaluationErrorMessage: ko.observable(null)
            , evaluatedValues: ko.observableArray([]) // will get calculated by evaluateChoices 
            , loading: ko.observable(false)
            , missingPrereqs: ko.observable(false) // gets updated by updateChoicesFromSql
        }, mappedParam);
        _param.Prereqs = ko.computed(prereqs);  //invoked immediately and needs other properties to exist already
        _param.templateName = ko.computed(_.partial(templateForParam, _param));
        _param.userSelection.equalityComparer = _.isEqual; //The default compare doesn't do an equality by reference check, use this more robust one so when things get reassigned to themselves it doesn't trigger subscribe
        _param.optionsCannotBeEvaluated = ko.computed(function () {
        	return !!(_param.missingPrereqs() || _param.evaluationErrorMessage());
        });

        // when our user selection changes, publish our name for the sake of dependents
        _param.userSelection.subscribe(function updateDependeciesWithSelf() {
            // this is a little tricky due to optimizations in knockout. Basically, if 'paramA' gets changed twice in a row, knockout won't trigger the 'valueHasMutated' the second time,
            // because technically the value hasn't mutated (it's still 'paramA'), so in that case we just need to trigger valueHasMutated ourselves
            if (dependencies() === _param.Name()) {
                dependencies.valueHasMutated();
            } else { // on the other hand, if the previous user selection was a different param (say paramX), then we need to publish the name of paramA as usual:
                dependencies(_param.Name())
            }
        });
        // and listen out for others publishing names, as they may be our prereqs
        dependencies.subscribe(updateChoicesIfPrereq);

        _param.refreshChoices = function () {
        	evaluateChoices(getAllSelections());
        };      

        _param.evaluatedValues.subscribe(trySelectDefault);
        _param.DefaultSelection.subscribe(function (newVal) { config.data.DefaultSelection = newVal });

        evaluateChoices({});
      
        return _param;

        ////////////////////////////////////////////////////////////////////////

        function trySelectDefault() {
            var defaultSelection = tryJsonParse(ko.unwrap(_param.DefaultSelection));
            if (!defaultSelection) return;
            var defaultInChoices = _.find(_param.evaluatedValues, function (x) { return _.isEqual(x, defaultSelection) });
            if (defaultInChoices) {
                //defer until we can be sure that all selection options loaded
                _.defer(function () { _param.userSelection(defaultInChoices) });
            }
        }

        function updateChoicesIfPrereq(name) {
            if (~_param.Prereqs().indexOf(name))
            	evaluateChoices(getAllSelections());
        }

        function evaluateChoices(allSelections) {
            _param.userSelection(null);
            if (_param.IsEvaluationTypeJson())
            	return evaluateChoicesFromJson();
            if (_param.IsEvaluationTypeSql())
                return updateChoicesFromSql(allSelections);

            _param.evaluatedValues(null); //to clean up content
            _param.evaluationErrorMessage(null);
            choicesUpdated();  //TODO - GM - can't this just be a subscriber to evaluatedValues, whats the need for this at all?
        }
        function evaluateChoicesFromJson() {
            try {
            	_param.evaluatedValues(JSON.parse(_param.EvaluationSource()));
            	_param.evaluationErrorMessage(null);
            } catch (err) {
            	_param.evaluationErrorMessage(err.message || err);
            }
            choicesUpdated(_param.evaluatedValues());
        }
        function updateChoicesFromSql(allSelections) {
            // if we are missing some prereqs, show no choices
            // if we have all needed prereqs, call the server to get the choices from SQL
            if (_.any(_param.Prereqs)) {
                var missing = missingPrereqs(allSelections);
                if (_.any(missing)) {
                    _param.missingPrereqs(true);
                    return _param.userSelection(null);
                }
            }
            _param.missingPrereqs(false);
            _param.loading(true);

            xhrEvaluationRequest && xhrEvaluationRequest.abort && xhrEvaluationRequest.abort();
            xhrEvaluationRequest = getParamOptions(allSelections, _param.Id).done(setEvaluated).always(_.partial(_param.loading, false));
        }
        function setEvaluated(response) {
        	if (response.Error) {
        		_param.evaluatedValues(null);
		        _param.evaluationErrorMessage(response.Error.Message);
	        } else {
		        _param.evaluatedValues(response.Result);
		        _param.evaluationErrorMessage(null);
	        }
	        choicesUpdated(_param.evaluatedValues());
        }

        function getDefaultParamOptions(allSelections) {
        	return api.getHierarchyParamOptions(_param, allSelections);
        }

    	// If EvaluationType == SQL and the EvaluationSource SQL string contains @parameters, 
        // returns a string[] of the parameter names, otherwise returns empty array
        function prereqs() {
        	if (!_param.IsEvaluationTypeSql()) return [];

            var matches = _param.EvaluationSource() && _param.EvaluationSource().match(SQL_PARAM_REGEX);
            var list = _.map(matches, function (m) {
                return m.substring(1);           // eg "@supplierKey" -> "supplierKey"
            }) || [];
            var filteredList = _.reject(list, function (m) {
                return m.toLowerCase() === 'username';   // remove 'username' from the list, if present, since this isn't a prereq; it's an always-availabe parameter that's supplied automatically on the server-side
            });
            return _.unique(filteredList);
        }

        function missingPrereqs(allSelections) {
            return _.filter(_param.Prereqs(), function (prereq) {
                return !_(allSelections).has(prereq) || !allSelections[prereq]
            });
        };

        function fireChoicesUpdated(callback) {
            var boundCallback = !callback ? _.identity
                                : callback.fire ? callback.fire.bind(callback)
                                : callback;
            return function () {
                boundCallback.apply(undefined, _.union([_param], arguments));
            }
        }

    };
    //////////////////////////////////////////////////////////////////////

    function templateForParam(p) {
    	var templateName = "tmpl-param-" + ko.unwrap(p.ParamType).toLowerCase();
    	return templateName || console.error("Nonexistent template for " + templateName);
    };

    function tryJsonParse(str) {
        if (!str) return;
        try { return JSON.parse(str); } catch (e) { }
    }
});