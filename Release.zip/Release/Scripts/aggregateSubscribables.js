define(['jquery', 'knockout', 'underscore'], function($, ko, _){
//Takes an object or array and return a knockout subscribable that will notify subscribers
//whenever any subscribable property navigable to from the object changes. Will re-evaluate its subscriptions
//at this point to pick up any new subscriptions. In this respect this structure is similar to a computed
//with the exception that it visits all relevant properties for you and that it passes to it's subscribers
//an object representing what propery was triggered (including property name).
//Examples:
//var m = {age: ko.observable(null), mother: ko.observable(null)};
//aggregateSubscribable(m).subscribe(Function.prototype.bind.call(console.log, console));
//m.age(31)
//Will output {name: 'age', target: m.age }
//m.mother({name: ko.observable(null)})
//m.mother().name("Amy")
//Will output {name: 'mother', target: m.mother }, {name: 'name', target: m.mother().name }
//See aggregateSubscribable.specs.coffee for more examples
//Takes a second options parameter.
//	shouldNavigateProperty - test whether a given property node should be visited. For example properties begining with '_' should probably not be visited for subscribables
return function aggregateSubscribables(models, op) {
	op = _.defaults(op||{}, {
		shouldNavigateProperty: function(x){ return /^([a-z]|[A-Z]|[0-9])/.test(x.name) }
	});
	var  subscriptionsToDependencies = []
		,model                       = createRecord(models) 
		,notNavigableTests           = [_.isFunction, _.isString, _.isNumber, _.isNull, _.isBoolean, _.isElement, _.isUndefined, _.isDate, _.isRegExp]
		;
	var _aggregate = function() {};
	ko.subscribable.call(_aggregate);

	evaluateNow();

	return _aggregate;
	///////////////////////////////

	function evaluateNow() {
		_.invoke(subscriptionsToDependencies, 'dispose');
		subscriptionsToDependencies = [];
		_.visit(model, subscribeToSubscribable, descendableProperties([]));
	}
	function subscribeToSubscribable(x) {
		if(!ko.isSubscribable(x.target))
			return;
		subscriptionsToDependencies.push( x.target.subscribe(function notifyAndEvaluate(){
			_aggregate.notifySubscribers(x);
			evaluateNow();
		}));
	}
	function descendableProperties(visited) { return function descendableProperties(x) {
		if(ko.isObservable(x.target))
			return descendableProperties(createRecord( ko.unwrap(x.target), x.name));
		visited.push(x.target)
		if(_.any(notNavigableTests, function(test){ return test(x.target) }))
			return [];
		return _.chain(x.target).map(createRecord)
				.filter(op.shouldNavigateProperty).filter(function(cx){
					return !_.contains(visited, cx.target)
				}).value();
	} }

	function createRecord(v, n) {
		return {target: v, name: n}
	}
}
})