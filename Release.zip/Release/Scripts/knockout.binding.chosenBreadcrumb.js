﻿define(['jquery', 'knockout', 'underscore', 'chosen'], function ($, ko, _, chosen) {
	'use strict';

	// Custom KO binding for breadcrumbs use of ChosenJS jquery widget; updates breadcrumb HTML and handles open/close behavior
	// Use: <select data-bind="
	//					disable: Parameter.missingPrereqs,
	//					options: Parameter.evaluatedValues,
	//					optionsText: 'desc',
	//					optionsValue: 'key',
	//					optionsCaption: Parameter.DisplayName(),
	//					chosenBreadcrumb: { selectionObservable: Parameter.userSelection }"></select>
	ko.bindingHandlers.chosenBreadcrumb = {
		init: function (element, valueAccessor, allBindingsAccessor) {
			var $element = $(element),
			$parent = $element.parent(),
			config = _.extend({
				optionsCaption: ko.unwrap(allBindingsAccessor().optionsCaption || ""),
				optionsValue: ko.unwrap(allBindingsAccessor().optionsValue),
			}, ko.unwrap(valueAccessor())),
			options = allBindingsAccessor().options,
			disable = allBindingsAccessor().disable,
			setHeader = _.partial(refreshHeader, $element, config);

			if (ko.isObservable(options)) {
				initHTML($element, config);
				if (options || options.length) {
					initChosen($element, config, options);
				} else {
					options.subscribe(function (newOptions) {
						initChosen($element, config, newOptions);
					});
				}
			}

			if (ko.isObservable(config.selectionObservable))
				config.selectionObservable.subscribe(setHeader);

			if (config.selectionObservable())
				setHeader(config.selectionObservable());

			if (ko.isObservable(disable))
				disable.subscribe(function (value) {
					var selectedContainer = $element.data('selectedContainer');
					if (selectedContainer && selectedContainer.length)
						selectedContainer.text(config.optionsCaption);
				});
		},
		update: function (element) {
			var $element = $(element);

			updateDropdown($element, $element.parent());
		}
	};

	function initChosen($element, config, options) {
		$element.chosen();
		addChangeListeners($element, config, options);
	}

	function refreshHeader($element, config, value) {
		var selectedContainer = $element.data('selectedContainer'),
			val = value ? value[config.optionsValue] : "";
		$element.val(val).trigger('change.chosen');

		var selectedOption = $element.find(':selected');
		if (selectedContainer && selectedContainer.length && selectedOption)
			selectedContainer.text(selectedOption.text());
	}

	function initHTML($element, config) {
		var selectedContainer = $('<a>').text(config.optionsCaption),
		optionsContainer = $('<div>').addClass('dropdown');

		$element.before(selectedContainer);
		$element.after(optionsContainer);
		$element.data('selectedContainer', selectedContainer);
		$element.data('optionsContainer', optionsContainer);

		optionsContainer.append($element);

		close(selectedContainer, optionsContainer); // set initial state
		addMouseListeners($element, selectedContainer, optionsContainer);
		addLostFocusListeners($element, selectedContainer, optionsContainer, config.onSelectedChange);
	}

	function addMouseListeners($element, $selected, $options) {
		$selected.on('click', function (event) {
			if (!$element.prop('disabled')) {
				open($selected, $options);

				updateDropdown($element, $options);
				expandDropdown($options);
			}
			event.cancelBubble = true;
			if (event.stopPropagation) event.stopPropagation();
			if (event.preventDefault) event.preventDefault();
		});
	}

	function open($selected, $options) {
		$selected.hide();
		$options.show();
	}

	function close($selected, $options) {
		$selected.show();
		$options.hide();
	}

	function addLostFocusListeners($element, $selected, $options, onSelectedChange) {
		$("html").on("click touchstart", function (e) {
			var $clickedContainer = $(e.target).closest(".chzn-container");
			if (!$clickedContainer.length)
				close($selected, $options);
		});
		$element.on("chzn:hiding_dropdown", function () {
			close($selected, $options);
		});
		$(window).blur(function () {
			close($selected, $options);
		});
	}

	function addChangeListeners($element, config, options) {
		$element
			.off('change.chosen')
			.on('change.chosen', function (event) {
				var key = $element.val() ? $element.val() : null;
				var selectedObject = _.findBy(options, key, config.optionsValue);

				if (ko.isObservable(config.selectionObservable))
					if (selectedObject != config.selectionObservable())
						config.selectionObservable(_.isObject(selectedObject) ? selectedObject : undefined);

				refreshChosen();

				event.cancelBubble = true;
				if (event.stopPropagation) event.stopPropagation();
				if (event.preventDefault) event.preventDefault();
		});
	}

	function updateDropdown($element, $options) {
		var width = $element.outerWidth() * 1.1;
		$options.find('.chzn-single, .chzn-drop, .chzn-container').width(width);
		$options.find('.chzn-search input').width(width - 26);
		$element.trigger("liszt:updated");
	};

	function expandDropdown($options) {
		$options.find(".chzn-container").trigger("mousedown");
	};

	function refreshChosen() {
		$("html").trigger("click"); //hack to refresh chosen
	}
});