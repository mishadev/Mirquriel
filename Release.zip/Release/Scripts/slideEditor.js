define([
     'jquery', 'knockout', 'underscore', 'knockout.mapping'
    , 'slideRenderer', 'apiUrls'
    , 'ogrePlugins', 'warnOnPageUnloadAfterChanges'
    , 'parameters/parametersContext', 'serverUtils'
    , 'slideDeckDownloader', 'breadcrumbs/breadcrumbContext'
	, 'bindKeyboardShortcuts', 'asyncComputed'
    , 'ogre.widgets.codeEditors'
    , 'jquery.form', 'jquery.fileDownload'
	, 'knockoutExtensions'
],
function (
	$, ko, _, mapping,
	newSlideRenderer, api,
	ogrePlugins, warnOnPageUnloadAfterChanges,
	newParamContext, requestUtils,
	slideDeckDownloader, breadcrumbContext,
	bindKeyboardShortcuts, asyncComputed
) {
	'use strict';

	// From here on out, all persistState widgets should save to a key generic to all slideset Editors, not just the editor for this slide
	// This global way of adjusting the persistState base persistenceKey only works so long as the slide editor is a separate page to itself.
	$.ow.persistState.prototype.options.persistenceKey = 'slide-editor';

	return function slideEditor(model) {
		var  slideRenderer = null
			,saveToServer = _.debounce(saveToServerNow, 500)
			,saved = $.Callbacks()
			,editors = {}
			,slide = mapping.fromJS(_.defaults(model.Slide, {
					 Name: ""
					,SqlCode: ""
					,RepeatableParameterSql: ""									
				}), { copy: ['SlideId'] })
			,initializingEditors = $.Deferred()

			//these are needed to check if sql code changed after save and trigger a redraw
			,prevSqlCode = ko.unwrap(slide.SqlCode)
			,prevRepeatableParameterSql = ko.unwrap(slide.RepeatableParameterSql);

		var _editor = {
			 slide: ko.observable(null)							//set after param context is initialized
			,slideSet: ko.observable(null)
			,slideSets: ko.observableArray(model.SlideSets)
			,errorReport: ko.observableArray([])
			,successReport: ko.observableArray([])
			,currentData: ko.observable(null)
			,generatedSql: ko.observable(null)
			,ogrePluginNames: _.keys(ogrePlugins)
			,takeThumbnailSnapshot:  _.debounce(takeThumbnailSnapshot, 1000, true)
			,options: {
				 fixPreview: ko.observable(false)
				,disableDrag: ko.observable(false)
				,isHelpVisible: ko.observable(false)
			}

			,highlightEditableAreas: getEditableAreaHighligher()
			,save: saveToServer
			,saving: ko.observable(false)
			,toPdf: _.partial(downloadAsset, api.SlideDeckPdf)
			,toPptx: _.partial(downloadAsset, api.SlideDeckPptx)
			,fullScreenSlide: fullScreenSlide
			,downloadQueryReport: downloadQueryReport
			,downloadDetailedQueryReport: ko.computed(function () { return (slide.DetailedReportSqlCode() || "").trim() && downloadDetailedQueryReport }) //computed that returns null or a function
			
			,repeatableParameterData: ko.observable(null)
			,selectedRepeatableParameterData: ko.observable(null)

			,availableSlideAssets: ko.observable([])
			,assetUploaded: assetUploaded

			,revertPersistence: function () { $(':ow-persistState').persistState('clear') }
			,revealSlideView: function () { $(':ogre-slideView').css({ left: 0, top: 0 }) }
		};

		_editor.hierarchyParameters = asyncComputed(getHierarchyParameterContext);
		_editor.parameterContext = asyncComputed(getParamContext);

		_editor.slideSet.subscribe(function () {
			var slideSetId = _editor.slideSet().Id;
			//updating url
			history.pushState({ id: slideSetId }, null, "/" + api.slideConfigurationUrlTemplate(slideSetId, slide.Id()));

		});

		_editor.parameterContext.subscribe(function () {
			if (!_editor.parameterContext())
				return;

			initParamContext(function (params) {
				//these operate on the DOM, wait for ko to update everything on this event loop before proceeding
				_.defer(function () {
					initSlideRenderer(params);
					setupCodeEditors(initializingEditors);
					var unsavedUnloadMonitor = warnOnPageUnloadAfterChanges({
						watch: _editor.slide
						, shouldNavigateProperty: function (x) { return /^([A-Z]|[0-9])/.test(x.name) }	//watch all properties (and descendants) that begin with an upper case (so don't watch isRedrawing)
					});
					saved.add(unsavedUnloadMonitor.reset);
				});
			});
		});

		_editor.slideSet(_.find(model.SlideSets, function (ss) { return ss.Id === model.ActiveSlideSetId }));

		var usedSlides = mapping.fromJS(model.UsedSlides)();
		_editor.usedSlide = ko.computed(function() { return _.findBy(usedSlides, _editor.slideSet().Id, 'SlidesetId') });
		_.each(usedSlides, function(us){ us.Name.subscribe(_.debounce(_.partial(saveUsedSlide, us), 500)) });

		_editor.options.fixPreview.subscribe(_editor.revealSlideView);
		_editor.selectedRepeatableParameterData.subscribe(updateRepeatableParameterData);

		_editor.toggleHelp = function () {
			_editor.options.isHelpVisible(!_editor.options.isHelpVisible());
		}

		// use slide.Name as page title, to more easily distinguish slides when we have multiple Slide Editor tabs open in the browser
		setDocumentTitle(ko.unwrap(slide.Name));
		slide.Name.subscribe(setDocumentTitle);

		initializingEditors.done(tryUpdatePreview(true));
		setupKeybindingShortcuts();
		getAvailableSlideAssets();

		return _editor;


		///////////////////////////////////////

		function getHierarchyParameterContext() {
			if (!_editor.slideSet()) return null;

			var datamart = _editor.slideSet().DatamartConnectionStringName;
			return api.getDatamartHierarchyParameterValues(datamart)
					.then(function (hp) {
						return breadcrumbContext({
							DatamartName: datamart,
							HierarchyParameters: hp
						});
					});
		}

		function getParamContext() {
			if (!_editor.slideSet() || !_editor.hierarchyParameters()) return null;
			var currentSlideSet = _editor.slideSet();
			return api.getSlideSetParameters(currentSlideSet.Id)
				.then(function (parameters) {
					return newParamContext(parameters, _editor.hierarchyParameters().params, { getParameterOptions: getSlideSetParamOptions });
				});
		}

		function getSlideSetParamOptions(parameter, allSelections) {
			return api.getSlideSetParamOptions({
				slideSetId: _editor.slideSet().SlideSetId
				, parameterId: parameter.Id
				, allSelections: allSelections
			});
		}

		function saveUsedSlide(us) {
			api.updateSlideSlidesetContext({slideId: us.SlideId(), slidesetId: us.SlidesetId(), name: us.Name()})
		}

		function getAvailableSlideAssets() {
			api.getSlideAssets()
			.done(_editor.availableSlideAssets);
		}

		function assetUploaded(status, message) {
			if (status == "success") {
				getAvailableSlideAssets();
				_editor.successReport.push(message);
				_.delay(_editor.successReport, 3000, _.without(_editor.successReport, message)); //message will be visible for 3s
			} else {
				_editor.errorReport.push(message);
				_.delay(_editor.errorReport, 3000, _.without(_editor.errorReport, message)); //message will be visible for 3s
			}
		}

		function editorParameterSelections() {
			return _editor.parameterContext().allSelectionsWithoutStackingDescs();
		}

		function initParamContext(whenAllSelected) {
			var pc = _editor.parameterContext();
			pc.subscribeOnUserSelectionsChanged(_.after(_editor.parameterContext().parameters().length, function initPersistables() {
				_.defer(function () {
					var persistable = _.keys($.ow.persistState.elementPersistence).join(',')
						, $params = $('.slide-parameters ul.parameters').find(persistable)
					;
					$params.persistState({ autoRestore: true });
				});
			}));
			if (pc.isFulfilled())
				whenAllSelected(editorParameterSelections());
			else {
				var subscription = pc.isFulfilled.subscribe(function (fulfilled) {
					if (fulfilled) {
						subscription.dispose();
						whenAllSelected(editorParameterSelections());
					}
				});
			}

			initializingEditors.done(function updatePreviewOnParameterChange() {
				pc.subscribeOnUserSelectionsChanged(tryUpdatePreview(true));
				_editor.hierarchyParameters().events.selectionsChanged.add(tryUpdatePreview(true));
			});
		}
		function getQueryReportParameters() {
			return {
				sqlDataParams: _.extend(_editor.selectedRepeatableParameterData().parameters, editorParameterSelections())
				, slideId: slide.Id()
				, slideSetId: _editor.slideSet().Id
			}
		}
		function downloadQueryReport() {
			api.downloadQueryReport(getQueryReportParameters());
		}
		function downloadDetailedQueryReport() {
			api.downloadDetailedQueryReport(getQueryReportParameters());
		}
		function initSlideRenderer(params) {
			_editor.slide(slide);						//must come first as #preview does not exist before this
			slideRenderer = newSlideRenderer({
				selector: '#preview .slide iframe'
				, slide: slide
				, slideSet: _editor.slideSet()
				, editorMode: true
			});
			slideRenderer.events.dataUpdate.add(_.runWhen(isNotManual, serializeToCurrentData)); // slideRenderer is responsible for pulling new SQL data down, so here we add a hook to run after new data has been received by slideRenderer
			slideRenderer.events.dataRetrieved.add(slideDataRetrieved);
			slideRenderer.redraw({ params: params });
		}
		function isNotManual(x, manual) { return !manual; }

		function displayGeneratedSql(data) {
			var sqlObj = data.sqlQueries;
			var sql = "";
			if (sqlObj) {
				$.each(sqlObj, function (key, value) {
					sql += "-- " + key + "\r\n" + value + "\r\n\r\n";
				});
			}
			_editor.generatedSql(sql);
		}

	function serializeToCurrentData(data) {
	    _editor.currentData(JSON.stringify(data, undefined, 2));
	}

	function slideDataRetrieved(data) {
		// if we've received an array, we're dealing with repeatable-parameter data
		// regular "data code" returns an object with properties named according to the named queries
		var isRepeatableParameterData = _.isArray(data);

		if (isRepeatableParameterData) {
			if (_.isEmpty(data))
				return _editor.errorReport.push("The repeatable parameter query returns no values, so the slide cannot be evaluated.");
			
			_editor.repeatableParameterData(data);
			var firstRepeatableParameterValue = _.first(data);
			_editor.selectedRepeatableParameterData(firstRepeatableParameterValue);
			displayGeneratedSql(firstRepeatableParameterValue);
		} else {
			_editor.repeatableParameterData(null);
		}
	}
	
	function updateRepeatableParameterData(datum) {
		_editor.currentData(JSON.stringify(datum, null, 2));
	}

		function setupCodeEditors(initializingEditors) {
			editors.js = $('#js-code-editor').layoutJsCodeEditor({
				boundTo: slide.LayoutCode
				, change: tryUpdatePreview(false)
				, errorreport: function (e, x) { x.html ? _editor.errorReport([x.html]) : _editor.errorReport([]) }
			}).data('ogre-layoutJsCodeEditor');

			//For these do not try to redraw the slide now since only saved code will be used
			editors.data = $('#data-code-editor').dataSqlCodeEditor({
				boundTo: slide.SqlCode
			}).data('ogre-dataSqlCodeEditor');
			editors.repeatableParameter = $('#repeatable-parameter-editor').dataSqlCodeEditor({
				boundTo: slide.RepeatableParameterSql
				 , collapsible: function (el) { el.collapsibleToH3().persistState() }
			}).data('ogre-dataSqlCodeEditor');
			editors.detailedData = $('#detailed-data-code-editor').dataSqlCodeEditor({
				boundTo: slide.DetailedReportSqlCode
			}).data('ogre-dataSqlCodeEditor');

			editors.style = $('#style-code-editor').styleCssCodeEditor({
				boundTo: slide.StyleCode
				, change: tryUpdatePreview(false)
			}).data('ogre-styleCssCodeEditor');

			editors.currentData = $('#current-data-editor').jsonCodeEditor({
				boundTo: _editor.currentData
			}).data('ogre-jsonCodeEditor');
			_editor.currentData.subscribe(updateDataManually);

			editors.generatedSql = $('#generated-sql-editor').generatedSqlCodeEditor({
				boundTo: _editor.generatedSql
			}).data('ogre-generatedSqlCodeEditor');

			initializingEditors.resolve();
		}

		function updateDataManually(newValue) {
			if (editors.currentData.validate())
				slideRenderer.setState(JSON.parse(newValue));
			_editor.errorReport([]);
			_editor.successReport([]);
			redraw();
		}

		function tryUpdatePreview(updateData) {
			return _.debounce(function tryUpdatePreview() {
				if (!editors.js.validate())
					return;
				var selections = editorParameterSelections();
				redraw({
					params: updateData && selections	//Include descriptions since this object will be passed into the slides
				});
			}, 100);//in order to avoid unnecessary redrawing
		}

		function redraw(op) {
			slideRenderer.redraw(op).fail(function (err) {
				//We can have duplicates on page load or after save because 2 redraws can be called with different params
				var msg = err.message || err;
				_editor.errorReport(_.union(_editor.errorReport(), [msg]));
			});
		}
		function ensureAllFieldsUpdated() {				//ensure all input fields have broadcasted a change event and all editors are updated
			_.invoke(editors, 'save');
			$('#slideEditor input,textarea').trigger('change');
		}
		function saveToServerNow() {
			if (_editor.saving())
				return alert("Save already in progress! Please wait");

			ensureAllFieldsUpdated();
			var slide = mapping.toJS(_editor.slide());

			if (!slide.SlideId)
				return console.error("Saving new slides unimplemented");

			_editor.saving(true);
			api.updateSlide(slide).done(function () {
				// flash the page to indicate save is complete
				var $b = $('body').addClass('marked');
				_.delay(function () { $b.removeClass('marked') }, 2000);
			}).done(function updateLastModifiedByDate(responseBody) {
				// use the returned slide object (= the ajax response body) to update our local slide from the fields that get updated on the server:
				_editor.slide().LastModifiedBy(responseBody.LastModifiedBy);
				_editor.slide().LastModifiedOn(responseBody.LastModifiedOn);
			}).done(function redrawIfSqlCodeChanged() {
				if (trim(slide.SqlCode) === trim(prevSqlCode) &&
					trim(slide.RepeatableParameterSql) === trim(prevRepeatableParameterSql)
					) return;
				prevSqlCode = ko.unwrap(slide.SqlCode);
				prevRepeatableParameterSql = ko.unwrap(slide.RepeatableParameterSql)
				tryUpdatePreview(true)();
			})
			.done(saved.fire.bind(saved))
			.always(function () {
				_editor.saving(false);
			});
		}

		function trim(x) {
			var ux = ko.unwrap(x);
			return ux ? ux.trim() : "";
		}
		function takeThumbnailSnapshot() {
			var thumbnail = slideRenderer.getHtml();
			if (!thumbnail)
				return alert("Slide is blank; thumbnail not captured."); // warn user that we're not going to overwrite the thumbnail with a blank one, since it's probably a mistake
			var slidesetId = _editor.usedSlide().SlidesetId();
			api.updateThumbnail({
				slideId: _editor.slide().Id(),
				slideSetId: slidesetId,
				data: thumbnail
			}).then(requestUtils.getLocationHeader).then(function (newUrl) {
				var us = _.find(usedSlides, function(us) { return slidesetId == us.SlidesetId() });
				us.Thumbnail(newUrl);
				var message = "Thumbnail was successfully updated";
				_editor.successReport.push(message);
				_.delay(_editor.successReport, 3000, _.without(_editor.successReport, message));
			});
		}

		function downloadAsset(url) {
			ensureAllFieldsUpdated();
			slideDeckDownloader({
				url: url, name: ko.unwrap(slide.Name), parameterContext: _editor.parameterContext
				, slideHtmlList: [$('#preview :ogre-slideView').slideView('html')]
			});
		}

		function fullScreenSlide() {
			$('#preview :ogre-slideView').slideView('fullScreen');
		}
		function getEditableAreaHighligher() {
			var r = ko.observable(false);
			r.subscribe(function (val) {
				//TODO: 'modify' will be removed at some point, talk to George Mauer about it.
				$(':ogre-slideView').slideView('modify', function (doc) {
					d3.select(doc).selectAll('[data-editable=true]').classed('marked', val);
				});
			});
			return r;
		}

		function setDocumentTitle(newTitle) {
			document.title = newTitle;
		}

		function setupKeybindingShortcuts() {
			$(document).on('keydown', _.runWhen(isPressedCtrl("S"), preventDefault(saveToServer)));
			$(document).on('keydown', _.runWhen(isPressedCtrl("P"), preventDefault(_editor.toPdf)));
			$(document).on('keydown', _.runWhen(isPressedCtrl(122), preventDefault(fullScreenSlide))); // 122 = f11 keycode
			bindKeyboardShortcuts([{ keycodes: [191], callback: _editor.toggleHelp }]);
		}
		function isPressedCtrl(key) {
			var keyCode = typeof key === "string" ? key.charCodeAt() : key;
			return function isPressedCtrl(e) {
				return e && e.ctrlKey && e.which === keyCode;
			}
		}

		function preventDefault(fn) {
			return function (e) {
				fn.apply(this, arguments);
				e && e.preventDefault && e.preventDefault();
			}
		}
	}
});
