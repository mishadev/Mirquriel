// Various prebuild dialog configurations with specific options
define(
['jquery', 'underscore', 'knockout', 'jqueryUI'],
function ($,_,ko) {
	'use strict'
	
	$.widget('ogre.ogreDialog', $.ui.dialog, {
		 widgetEventPrefix: 'dialog'
		,options: {}
		,_create: function() {
			$.ui.dialog.prototype._create.apply(this, arguments);
			this.option('width',  .84 * $(window).width() );	//jquery ui dialogs are 300px wide by default and ugly 
		}
	});

	//Create a dialog that is regular flow-content inside the page rather than positioned absolutely. 
	//Seems useless, but really does two things
	//1. uses jquery ui dialog stylings
	//2. provides a "close" button which will remove this html element
	$.widget('ogre.inPageDialog', {
		_create: function(){
			var  outer        = '<div class="ui-dialog ogre-inplace-dialog ui-widget ui-widget-content ui-corner-all" role="dialog" />'
				,contentOuter = '<div class="ui-dialog-content ui-widget-content">'
				,titleText 	  = (this.options.title || this.element.attr('title')||"").trim()
				,titlebar     = $('<div class="ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix">')
				,title        = $('<span class="ui-dialog-title">').appendTo(titlebar)
				;
			this._setupCloseBtn(titlebar);
			titleText ? title.text(titleText) : title.html('&nbsp;'); 
			this.element.wrap(outer);
			this.element.wrap(contentOuter);
			this.element.before(titlebar);
			this.root = this.element.closest('.ogre-inplace-dialog');
		}
		,close: function() {
			this.root.remove();
		}
		,_setupCloseBtn: function(titlebar) {
			var closeBtn = $('<a href="#" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span class="ui-icon ui-icon-closethick">close</span></a>')
							.appendTo(titlebar);
			var invoke = function(name, arg) { return function() { closeBtn[name](arg)}};
			closeBtn
				.hover(invoke('addClass', 'ui-state-hover'),invoke('removeClass','ui-state-hover'))
				.focus(invoke('addClass', 'ui-state-focus'))
				.blur(invoke('removeClass', 'ui-state-focus'))
				.click(_.bind(function(ev) {
					this.close();
					return false;
				}, this));
		}
	});

	// Elements with this binding will appear as a jquery ui dialog when the bound value exists
	// This binding works similar to the 'with' data-binding in that its contents will only exist when its bound parameter is truthy.
	// Also like 'with', it will start a new binding context.
	// Unlike the 'with' binding, when the contents are visible this will not appear in place but instead be initialized in a 
	// jquery ui dialog. This dialog will close if the bounded value becomes falsy. Conversely, if the bound value is observable,
	// closing the dialog will empty the observable.
	ko.bindingHandlers.dialog = {
		 init: ko.bindingHandlers['with'].init
		,update: function(el, valueAccessor) {
			var  $el             	= $(el)
				,val             	= ko.utils.unwrapObservable(valueAccessor())
				,observable      	= ko.isObservable(valueAccessor()) && valueAccessor()
				,clearObservable 	= function(){ observable && observable(null) }
				,closeDialog     	= function () { $el.ogreDialog('close') }
				;
            _.defer(function(){
                if(!$el.is(':ogre-ogredialog'))
                    $el.ogreDialog({
                         close: 	clearObservable
                        ,buttons: 	{"Ok": closeDialog }
                    });
                $el.ogreDialog(val ? 'open' : 'close');
            });
		}
	};

	ko.bindingHandlers.dialogWithButtons = {
		 init: ko.bindingHandlers['with'].init
		,update:  function(el, valueAccessor) {
			var  $el             	= $(el)
				,val             	= ko.unwrap(valueAccessor())
				,observable      	= ko.isObservable(valueAccessor()) && valueAccessor()
				,clearObservable 	= function(){ observable && observable(null) }
				,closeDialog     	= function(){ $el.ogreDialog('close') }
				;
			observable && observable.subscribe(function(v) { !v && closeDialog() });
            _.defer(function(){
                if($el.is(':ogre-ogredialog'))
                	$el.ogreDialog('close').ogreDialog('destroy');
                if(!val)
                	return $el.ogreDialog({autoOpen: false});
                $el.ogreDialog( _.extend({
                     close: 	clearObservable
                    ,buttons: 	$('script.button', $el).map(createButtonModel(val, clearObservable)).toArray()
                }, $el.attr('title') && {title: $el.attr('title')} ));
                $el.ogreDialog(val ? 'open' : 'close');
            });
		}
	}
	function createButtonModel(val, closeDialog){return function() {
		var $buttonScript = $(this);
		return { 
			 text: $buttonScript.text()
			,click: function(){
				val && val[$buttonScript.data('bindto')] && val[$buttonScript.data('bindto')]();
				closeDialog();
			}
	   	}
	} }
});