define(
['knockout', 'underscore', 'sammy', 'mapParameterAndSlideContainer', 'slideSetInstance',
 'apiUrls', 'initializeHierarchyParamsSammyApp', 'breadcrumbs/breadcrumbContext', 'commonParametersContext',
 'slideSetConfiguration','slideSetViewer3', 'knockout-hashParamerterBinding', 'parameters/parametersContextBinder',
 'knockoutExtensions', 'knockout.clickover'],
function (
    ko, _, sammy, koMapping, slideSetInstance,
    api, initializeHierarchyParamsSammyApp, breadcrumbContext, commonParametersContext,
    slideSetConfiguration, currentSlideSetViewer, hashParameterBinding, parametersContextBinder) {
'use strict'

// This is the viewmodel for the /SlideSets/datamartConnectionString screen.  Rename to something expressing "full user interface for viewing slidesets for a particular datamart".

// Viewmodel for a slideset Viewer as spec'ed by ATF. This is initialized with a datamart which has its own set of hierarchy parameters.
// As hierarchy parameters are updated the url should update to reflect state and available slidesets should be fetched.
// This module is under test in slidesetViewer.specs.coffee
return function slideSetsViewer(model) {
	var  datamart                 = koMapping(model)
		,defaultRoute             = '#/'
	;

	var _slideSetsViewer = {
		datamart:            datamart
		,hierarchyParameters: breadcrumbContext(model.HierarchyParameters)
		,groupedSlideSets:    ko.observableArray([])
        ,openSlideSets:       ko.observableArray([])		

        ,openAReportVisible:  ko.observable(false)
		,isLoadingAvailableSlidesets: ko.observable(false)      

        ,openLeftPanelVisible:  ko.observable(true)
        ,openedReportsExpanded:  ko.observable(true)
        ,focusedSlideSet:       ko.observable(null)
		,toggleFocusedSlideSet: toggleFocusedSlideSet
        ,focusedGroup:          ko.observable(null)
		,toggleFocusedGroup:    toggleFocusedGroup

        ,toggleLeftPanelVisible:   toggleLeftPanelVisible
        ,toggleOpenAReportVisible: toggleOpenAReportVisible
        ,removeOpenSlideSets:      removeOpenSlideSets
		,isSlideSetParamVisible:   isSlideSetParamVisible
		,openSlideSetId:			ko.observable(null)
		,openSlideSetRange:			ko.observable(null)
	};

	_slideSetsViewer.currentSlideSetViewer = currentSlideSetViewer({
		openSlideSets: _slideSetsViewer.openSlideSets,
		strippedLinkVisible: true,
		fitSlideToScreen: model.fitSlideToScreen
	});

	_slideSetsViewer.commonParameters = commonParametersContext(model.CommonParameters, _slideSetsViewer.hierarchyParameters.params);
	_slideSetsViewer.commonParameters.subscribeOnUserSelectionsChanged(setParameterSelectionOfFocusedSlideSet);

	_slideSetsViewer.openSlideSetClick = function (slideSet,event) {
		if (_slideSetsViewer.currentSlideSetViewer.currentSlideSet() === slideSet) {
			return;
		}

		if (event.ctrlKey) {
			slideSet.isSelected(!slideSet.isSelected());
		} else {
			setCurrentOpenedSlideSet(slideSet);
		}
	};

	_slideSetsViewer.toggleHelp = function () {
		_slideSetsViewer.isSlideHelpVisible(!_slideSetsViewer.isSlideHelpVisible());
	}

	_slideSetsViewer.currentSlide			= ko.forcibleComputed(getSlideSetInstanceCurrentSlide);
	_slideSetsViewer.openSlideSetsCount		= ko.computed(function () { return _slideSetsViewer.openSlideSets().length });        //TODO - GM - why do we need this as a computed?
	
	_slideSetsViewer.changeOpenReportsState = function () {
		_slideSetsViewer.openedReportsExpanded(!_slideSetsViewer.openedReportsExpanded());
	}
	_slideSetsViewer.displayBreadcrumbs = ko.computed(function () {
	    return _slideSetsViewer.hierarchyParameters.params().length ||
            (model.CommonParametersInBreadcrumbs && _slideSetsViewer.commonParameters.parameters().length);
	});

    var app = sammy(initializeHierarchyParamsSammyApp(_slideSetsViewer.hierarchyParameters));

    ko.applyBindings(_slideSetsViewer, document.getElementById('main'));
    app.raise_errors = true;
    app.run(window.location.hash||defaultRoute);

    var openedSlideSetParamsUrlBinding;
    setUrlBinding(true);
	var loadSub = _slideSetsViewer.isLoadingAvailableSlidesets.subscribe(function(newValue) {
		if (!newValue) { // slidesets loaded
			loadSub.dispose();
			tryOpenAvailableSlidesetFromUrl();
		}
	});

    _slideSetsViewer.hierarchyParameters.events.selectionsChanged.add( _.immediate(queryForAvailableSlideSetDefinitions) );

    _slideSetsViewer.currentSlideSetViewer.currentSlideSet.subscribe(function (slideSet) {
    	_.each(_slideSetsViewer.openSlideSets(), function (ss) { ss.isSelected(false); });
    	slideSet && slideSet.isSelected(true);
    });

    return _slideSetsViewer;

	////////////////////////////////////////////////////////////////

	var commonParametersUrlBinding;
	function setUrlBinding(isOn) {
		if (isOn) {
			commonParametersUrlBinding = parametersContextBinder(_slideSetsViewer.commonParameters, isOn, 'cps');
			hashParameterBinding.bindToUrl({
				parameterName: 'openSlideSetId',
				observable: _slideSetsViewer.openSlideSetId,
			});
			hashParameterBinding.bindToUrl({
				parameterName: 'openSlideSetRange',
				observable: _slideSetsViewer.openSlideSetRange,
			});
		} else {
			if (commonParametersUrlBinding && _.isFunction(commonParametersUrlBinding.dispose))
				commonParametersUrlBinding.dispose();
			hashParameterBinding.unbindFromUrl(_slideSetsViewer.openSlideSetId);
			hashParameterBinding.unbindFromUrl(_slideSetsViewer.openSlideSetRange);
		}
	}

	function tryOpenAvailableSlidesetFromUrl() {
		// find slideset according to url
		var slidesetToOpen = findSlideSetBy(_slideSetsViewer.openSlideSetId());
		if (!slidesetToOpen)
			return;
		// set parameter values from url to the found slideset
		setOpenedSlideSetUrlBinding(slidesetToOpen.slideSetConfiguration.urlBinding);
		if (_slideSetsViewer.openSlideSetRange()) {
			slidesetToOpen.slideSetConfiguration.slideRangeType('Range');
			slidesetToOpen.slideSetConfiguration.slideRangeNotation(_slideSetsViewer.openSlideSetRange());
		} else {
			slidesetToOpen.slideSetConfiguration.slideRangeType('All');
		}

		// and make it current 
		_slideSetsViewer.focusedSlideSet(slidesetToOpen);

		// open slideset instance when it is ready
		if (slidesetToOpen.slideSetConfiguration.parametersContext.isFulfilled()) {
			_.defer(slidesetToOpen.loadSlideSetInstance);
		} else {
			var sub = slidesetToOpen.slideSetConfiguration.parametersContext.isFulfilled.subscribe(function (newValue) {
				if (!newValue)
					return;
				sub.dispose();
				_.defer(slidesetToOpen.loadSlideSetInstance);
			});
		}
	}

	function findSlideSetBy(slideSetId) {
		return _.chain(_slideSetsViewer.groupedSlideSets())
			.pluck("matchedSlideSets")
			.flatten()
			.find(function (ss) { return ss.slideSetConfiguration.slideSetDefinition.SlideSetId == slideSetId; })
			.value();
	}

	function resetOpenedSlideSetUrlBinding() {
		if (ko.isObservable(openedSlideSetParamsUrlBinding))
			openedSlideSetParamsUrlBinding(false);
		openedSlideSetParamsUrlBinding = null;
	}

	function setOpenedSlideSetUrlBinding(slideSetUrlBinding) {
		if (slideSetUrlBinding) {
			openedSlideSetParamsUrlBinding = slideSetUrlBinding;
			openedSlideSetParamsUrlBinding(true);
		}
	}

	function setCurrentOpenedSlideSet(slideset) {
		resetOpenedSlideSetUrlBinding();
		_slideSetsViewer.currentSlideSetViewer.currentSlideSet(slideset);
		_slideSetsViewer.openSlideSetId(slideset ? slideset.slideSetDefinition.SlideSetId : null);
		_slideSetsViewer.openSlideSetRange(slideset ? slideset.rangeNotation : null);
		setOpenedSlideSetUrlBinding(slideset ? slideset.urlBinding : null);
	}

	function isSlideSetParamVisible(param) {
    	return !(param.HideIfMatchingCommonParamExists()
			&& _.any(_slideSetsViewer.commonParameters.parameters(), function (commonParameter) {
				return commonParameter.Name() === param.Name();
    		}));
	}

	function setParameterSelectionOfFocusedSlideSet(parameter) {
    	var focusedSlideSet = _slideSetsViewer.focusedSlideSet();
    	if (focusedSlideSet && !ko.unwrap(focusedSlideSet.slideSetConfiguration.urlBinding)) // do not set parameters if they are binded to URL
    		focusedSlideSet.slideSetConfiguration.deserializeParameterWithName(parameter.Name(), parameter.serializeUserSelection());
    }

    function toggleFocusedGroup(group) {
    	if (_slideSetsViewer.focusedGroup() == group) {
    		_slideSetsViewer.focusedGroup(null);
    	} else {
    		_slideSetsViewer.focusedGroup(group);
    	}
    }

    function toggleFocusedSlideSet(slideset) {
    	if (_slideSetsViewer.focusedSlideSet() == slideset) {
    		_slideSetsViewer.focusedSlideSet(null);
    	} else {
    		_slideSetsViewer.focusedSlideSet(slideset);
    		setAllSlidesetParamsToCommonParamValues(slideset);
    	}
    }

    function setAllSlidesetParamsToCommonParamValues(slideset) {
    	_.each(_slideSetsViewer.commonParameters.parameters(), function (commonParameter) {
    		slideset.slideSetConfiguration.deserializeParameterWithName(commonParameter.Name(), commonParameter.serializeUserSelection());
    	});
    }

    function getSlideSetInstance() { return _slideSetsViewer.currentSlideSetViewer.currentSlideSet() ? _slideSetsViewer.currentSlideSetViewer.currentSlideSet().slideSetInstance : null; }

	function getSlideSetInstanceCurrentSlide() { return getSlideSetInstance() ? getSlideSetInstance().currentSlide() : null; }

	function getAvailableTags(availableSlideSet) {
		var allTags = _.map(availableSlideSet, function (slideSet) {
			return slideSet.Tags ? _.filter(_.map(slideSet.Tags.split(','), function (t) {
				return t.trim();
			}), function (tag) {
				return tag !== '';
			}) : [];
		});
		return _.uniq(_.flatten(allTags));
	}

	function queryForAvailableSlideSetDefinitions() {
		_slideSetsViewer.isLoadingAvailableSlidesets(true);
        api.availableSlideSetsDefinitionsFor(datamart.Name(), _slideSetsViewer.hierarchyParameters.allSelections()).then(function (available) {
        	var tags = getAvailableTags(available);
            var slideSetGroups = [];

            _.forEach(tags, function (tag) {
                var matchedSlideSets = _.filter(available, function(slideSet) {
                	if (slideSet.Tags) {
                		var currentTags = slideSet.Tags.split(',');//split is required to avoid partial text matches

						return _.any(currentTags, function(t) { return t.trim() === tag; });
	                }
	               	return false;
                });

                slideSetGroups.push({
                	groupName: tag,
                    groupCount: matchedSlideSets.length,
                    matchedSlideSets: _.map(matchedSlideSets, createSlideSetConfigurationViewModel)
                });
            });

            var slideSetsWithoutTags = _.filter(available, function(item) { return !item.Tags; });
            if (slideSetsWithoutTags.length) {
                slideSetGroups.push({
                	groupName: _.any(tags) ? model.DefaultGroupNameText : model.AllAvailableSlidesetsNameText, //TODO: think of localization in js as passing through model not the best option
                    groupCount: slideSetsWithoutTags.length,
                    matchedSlideSets: _.map(slideSetsWithoutTags, createSlideSetConfigurationViewModel)
                });
            }

            _slideSetsViewer.groupedSlideSets(slideSetGroups);
            if (slideSetGroups.length === 1) _slideSetsViewer.focusedGroup(_.first(_slideSetsViewer.groupedSlideSets()));

            _slideSetsViewer.isLoadingAvailableSlidesets(false);
        });
    }

	function createSlideSetConfigurationViewModel(slideSetDefinition) {
		var vm = {
			slideSetConfiguration: slideSetConfiguration(slideSetDefinition, _slideSetsViewer.hierarchyParameters.params)
            ,loadSlideSetInstance: loadSlideSetInstances
        };
		return vm;

		function loadSlideSetInstances() {
			var stackingParams = _.filter(vm.slideSetConfiguration.parametersContext.parameters(), function (p) { return p.IsStackingParameter; }),
                instance;

			resetOpenedSlideSetUrlBinding(); // removes parameters from url for a current opened slideset 
			setOpenedSlideSetUrlBinding(vm.slideSetConfiguration.urlBinding); // refreshes url according to the slideset configuration

		    if (stackingParams && _.isArray(stackingParams) && stackingParams.length) {
		    	var allCombinationsOfStackingParameterSelections = getAllCombinationsOfStackingParameterSelections(stackingParams);
		    	var iterateFunctionOverStackingParams = function iterateStackingParams(func) { _.each(stackingParams, func); }
		    	_.each(allCombinationsOfStackingParameterSelections, function (arrayOfStackingParameterSingleValuesForThisSlidesetInstance) {
		    		// The index of a particular parameter selection in the array from the cartesian join is the same as the index of that parameter in stackingParams
		    		iterateFunctionOverStackingParams(function (param, index) {
						param.selectedOptions([arrayOfStackingParameterSingleValuesForThisSlidesetInstance[index]]);
		    		});
		    		instance = loadSlideSetInstance();
		    	});
		    }
		    else {
		    	instance = loadSlideSetInstance();
		    }

		    setCurrentSlideSet(instance);
		}

		function getAllCombinationsOfStackingParameterSelections(stackingParameters) {
			return cartesianProductOf(_.invoke(stackingParameters, 'selectedOptions'));
		}
        
        function cartesianProductOf(arrays) {
				return _.reduce(arrays, function (a, b) {
					return _.flatten(_.map(a, function (x) {
						return _.map(b, function (y) {
							return x.concat([y]);
						});
					}), true);
				}, [[]]);
			}

		function loadSlideSetInstance() {
			var instance = createSlideSetInstanceNode(slideSetDefinition, vm.slideSetConfiguration.parametersContext, vm.slideSetConfiguration.range().slice(),
				vm.slideSetConfiguration.slideRangeType() === 'Range' ? vm.slideSetConfiguration.slideRangeNotation() : null);
		    _slideSetsViewer.openSlideSets.push(instance);
		    return instance;
		}

		function setCurrentSlideSet(node) {
			var currentSlideSetBeforeLoad = _slideSetsViewer.currentSlideSetViewer.currentSlideSet();
		    node.slideSetInstance.loading.done(function () {
		    	if (currentSlideSetBeforeLoad == _slideSetsViewer.currentSlideSetViewer.currentSlideSet()) //if they switched to another slideset don't change current selection
		    		setCurrentOpenedSlideSet(node);
		    });
		    _slideSetsViewer.openAReportVisible(false);
		}
	}

	function createSlideSetInstanceNode(slideSetDefinition, paramContext, slideRange, rangeNotation) {
		var selections = _.extend({}, _slideSetsViewer.hierarchyParameters.allSelectionsWithDescs(), paramContext.allSelectionsWithDescs())
            , descriptions = _.extend({}, _slideSetsViewer.hierarchyParameters.allSelectionsDescs(), paramContext.allSelectionsDescs())
		;

        var node = {
        	slideSetDefinition: slideSetDefinition
			, parameterSelections: _.map(paramContext.parameters(), function (p) {
            	return {
            		displayName: p.computedDisplayName(),
            		displayInTheTitle: p.DisplayInTheTitle(),
            		userSelectionDesc: p.userSelection() ? formatDescription(p.userSelection().desc ? p.userSelection().desc : p.userSelection()) : ""
            	}
            })
            ,descriptions:        _.compact(descriptions)
            ,slideSetInstance:    slideSetInstance(slideSetDefinition, selections, null, slideRange)
            ,parameterValuesAndDescriptionsHash: selections
            ,isSelected: ko.observable(false)
			,paramContextValuesFromUrl: ko.observable(null)
			,rangeNotation:       rangeNotation
        }

		//'node' is pretty heavy object it will contains whole slideSet data could be more than 100Mb for huge slideSets.
		//So we should be careful here and avoid any references to long leavind objects in order to make 'node' destroyed by GC
		node.isLoading = ko.computed(function () { return !node.slideSetInstance.isFullyLoaded() });
		node.title = ko.computed(function () {
			var title = this.slideSetDefinition.Name;
			var shouldDisplayParameters = _.any(this.parameterSelections, function (item) { return item.displayInTheTitle; });
			
			return !shouldDisplayParameters ? title :
				title + " - " + _.pluck(_.where(this.parameterSelections, { displayInTheTitle: true }), 'userSelectionDesc').join(", ");
		}, node);

		// urlBinding flag allows to refresh URL for a current opened slideset
		node.urlBinding = ko.observable(false);
		node.urlBinding.subscribe(function (newVal) { setParamsUrlBinding(newVal); });

		// read slideset definition parameters from url to paramContextValuesFromUrl 
		setParamsUrlBinding(true);
		// and unbind from url safely (without url modificatin) in order not to change paramContextValuesFromUrl and url.
		setParamsUrlBinding(false, false);

		return node;

		function setParamsUrlBinding(isOn, cleanUrl) {
			if (isOn) {
				hashParameterBinding.bindToUrl({
					parameterName: 'ps',
					observable: node.paramContextValuesFromUrl,
				});
			} else {
				hashParameterBinding.unbindFromUrl(node.paramContextValuesFromUrl, cleanUrl);
			}
		}
    }

    function getSlideSetsRenderingParametersForExport() {
    	var selected = _.chain(_slideSetsViewer.openSlideSets())
			.where({ isSelected: true })
			.map(function (ss) {
				return {
					slideSetId: ss.slideSetDefinition.SlideSetId
					, parameterSelections: ss.parameterValuesAndDescriptionsHash
					, name: getReportName(ss.slideSetDefinition.Name, ss)
					, includeSlideRange: JSON.stringify(ss.slideSetInstance.slideRange)
				}
			}).value();
    	return selected;
    }  	

    function toggleLeftPanelVisible() {
        var open = !_slideSetsViewer.openLeftPanelVisible();
        if (!open)
            _slideSetsViewer.openAReportVisible(open);
        _slideSetsViewer.openLeftPanelVisible(open);
    }
    function toggleOpenAReportVisible() {
        _slideSetsViewer.openAReportVisible(!_slideSetsViewer.openAReportVisible());
    }
    function removeOpenSlideSets(node) {
        _slideSetsViewer.openSlideSets.remove(node);
        setCurrentOpenedSlideSet(null);
    }
   
	function formatDescription(description) {
		try {
			var parsedJson = JSON.parse(description);
			if ($.isArray(parsedJson))
				return parsedJson.join(", ");
		} catch (exception) {}
		
		return description;
    }
}
})
