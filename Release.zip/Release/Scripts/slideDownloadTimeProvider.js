﻿define(
['knockout', 'underscore', 'clientStorage'], function (ko, _, storage) {

	'use strict'

	return function (op) {

		_.ensureHasKeys(op, 'url', 'slidesNumber');
		var model = null;
		var downloadInProgress = false;
		var defaultRenderTimeData = { executions: 1, perSlide: 2500 };
		var startTime;
		var renderTimesObj; // = storage.getOnClient('slideDeckRenderTimes') || {};
		var renderTimes; // = renderTimesObj[op.url] || (renderTimesObj[op.url] = { executions: 1, perSlide: 2500 });

		var viewModel = {
			startDownloading: startDownloading,
			getModel: function(){return model;},
			downloadFinished: downloadFinished,			
		};

		return viewModel;


		function startDownloading() {
			renderTimesObj = storage.getOnClient('slideDeckRenderTimes') || {};
			renderTimes = renderTimesObj[op.url] || (renderTimesObj[op.url] = defaultRenderTimeData);

			startTime = new Date().getTime()
			downloadInProgress = true;
			model = infoModel();
			return model;
		}

		function downloadFinished() {
			downloadInProgress = false;
			incrementSlideAverage();
			model = null;
		}

		function incrementSlideAverage() {
			var timeToDownload = new Date().getTime() - startTime
				, timePerSlide = timeToDownload / op.slidesNumber
				, weightedTimePerSlide = (renderTimes.perSlide * renderTimes.executions + timePerSlide) / (renderTimes.executions + 1)
			;
			_log("done", timeToDownload, timePerSlide, weightedTimePerSlide);
			renderTimes.executions += 1;
			renderTimes.perSlide = weightedTimePerSlide;
			storage.storeOnClient('slideDeckRenderTimes', renderTimesObj);
		}

		function timeRemainingCounter(timeSpanLength) {
			var remaining = ko.observable("");
			function checkTimer() {
				var elapsed = new Date().getTime() - startTime;
				remaining(timeSpanLength - elapsed);
				downloadInProgress && _.delay(checkTimer, 1000);
			};
			checkTimer();
			return remaining;
		}

		function infoModel() {
			var estimatedDownloadTime = 1.2 * (renderTimes.perSlide * op.slidesNumber); //pad slightly to make the system seem more responsive
			return {
				slideDeckSize: op.slidesNumber
				, estimatedDownloadTime: estimatedDownloadTime
				, estimatedTimePerSlide: renderTimes.perSlide
				, timeRemaining: timeRemainingCounter(estimatedDownloadTime, startTime)
				, error: ko.observable(null)
			};
		}

	}

});