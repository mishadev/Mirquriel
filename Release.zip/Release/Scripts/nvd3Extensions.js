﻿define(
['nvd3', 'underscore'], function(nv, _) {
	nv.dev = false;

	//Compensate for: https://github.com/novus/nvd3/issues/58
	var oldRender = nv.render;
	nv.render = _.extend(_.wrap(oldRender, tryCatch), oldRender);

	function tryCatch(fn, args) {
		args = _.tail(arguments);
		try {
			fn.apply(this, args);
		} catch(e) {
			console.log("Error", e);
		}
	}
});