﻿define(
['jquery', 'knockout', 'underscore', 'paramsPageModel', 'parametersEditorBase', 'apiUrls'],
function ($, ko, _, paramsPageModel, base, api) {
	'use strict';
	var _parametersEditor = base({
		newParameter:			api.newParameter,
		deleteParameter:		api.deleteParameter,
		saveParameter:			api.saveParameter,
		getParameterOptions:	getParameterOptions
	}, paramsPageModel.AvailableDataMarts, ['Description']);

	api.getParameters().then(function (data) {
		_parametersEditor.parametersContext.loadParameters(data);
		_.each(_parametersEditor.parametersContext.parameters(), _parametersEditor.saveOnAllChanges);
	});

	ko.applyBindings(_parametersEditor, document.getElementById('main'));

	return _parametersEditor;

	function getParameterOptions(parameter, allSelections) {
		return api.getEditorParameterOptions({
			parameterId: parameter.Id,
			datamart: parameter.datamartConnectionStringName(),
			allSelections: allSelections
		});
	}
});