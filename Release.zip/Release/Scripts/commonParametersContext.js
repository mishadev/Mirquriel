﻿//Common parameter context keeps context of shared parameters
// shared parameter concept allows to specify parameter which could be used on all slides
//and will adjust slideset parameter selection
define(["jquery", "knockout", "knockout.mapping", "underscore", "parameters/parametersContext", "apiUrls"
], function ($, ko, mapping, _, parametersContext, api) {
	"use strict";

	return function commonParametersContext(model, additionalParameters) {
		var parameters = _.map(model.CommonParameters, function (cp) { return _.extend({}, cp.Parameter, { commonParameter: cp }) });

		var _context = parametersContext(parameters, additionalParameters, { getParameterOptions: getParameterOptions });

		_context.areAllSelects = ko.computed(function () {
			return _.all(_context.parameters, function (p) { return p.ParamType() === 'SELECT' });
		});

		_context.areAllSelectsAndSearchselect = ko.computed(function () {
			return _.all(_context.parameters, function (p) { return p.ParamType() === 'SELECT' || p.ParamType() === 'SEARCHSELECT' });
		});
		return _context; 
	}

	function getParameterOptions(parameter, allSelections) {
		return api.getCommonParamOptions(allSelections, parameter.commonParameter.Id());
	}
});