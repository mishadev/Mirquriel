define(['jquery', 'underscore', 'knockout', 'aggregateSubscribables'],
function($, _, ko, aggregateSubscribables){
//Watch all observables in a viewmodel for changes and show a dialog when trying to unload the window if there are modifications. 
//Returns an object with a reset method that you can call to reset the module to a "clean" state (eg after a save, the dialog should not appear).
return function warnOnPageUnloadAfterChanges(op) {
	_.ensureHasKeys(op, 'watch');
	_.defaults(op, {
		 unloadingUnsavedChangesPrompt: ( $('#tmpl-unloading-unsaved-changes').text() || "There are unsaved changes on the page. Are you sure you want to continue?" )
		,shouldMarkDirty: function() { 
			return true }		
	});

	var  isDirty = false
	aggregateSubscribables(op.watch, op).subscribe(function(change){ 
		if(op.shouldMarkDirty(change))
			isDirty = true 
	});

	$(window).on('beforeunload', function(e){
		if(isDirty)
			return e.returnValue = op.unloadingUnsavedChangesPrompt;
	})

	return {
		reset: function() {isDirty = false }
	}

	/////////////////////////////
	function model(val, name) { return { value: val, name: name } }
}
})