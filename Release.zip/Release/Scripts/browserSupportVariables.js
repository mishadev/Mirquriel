define([], 
function () {
	"use strict";
	// define a simple implementation of the console.table() function to prevent errors in IE or PhantomJS
	console.table = console.table || function (table) {
		return console.log(JSON.stringify(table));
	}
})