﻿define(
['knockout', 'underscore', 'parameters/textParameter', 'parameters/selectParameter', 'parameters/checkboxParameter', 'parameters/multiselectParameter',  'parameters/searchSelectParameter', 'parameters/multiSearchSelectParameter'],
function (ko, _, textParameter, selectParameter, checkboxParameter, multiselectParameter, searchSelectParameter, multiSearchSelectParameter) {
	'use strict';

	return function parametersFactoryConstructor() {
		var parameterTypeToConstructorMapping = { TEXT: textParameter, SELECT: selectParameter, CHECKBOX: checkboxParameter, MULTISELECT: multiselectParameter, SEARCHSELECT: searchSelectParameter, MULTISEARCHSELECT: multiSearchSelectParameter };
		var _parametersFactory = {
			parameterTypes: ['TEXT', 'SELECT', 'CHECKBOX', 'MULTISELECT', 'SEARCHSELECT', 'MULTISEARCHSELECT']
			, createParameter: createParameter
		};
		
		return _parametersFactory;

		function createParameter(model) {
			_.ensureHasKeys(model, 'ParamType');
			var type = model.ParamType;
			var parameterConstructor = parameterTypeToConstructorMapping[type];
			if (!parameterConstructor)
				throw 'No constructor for ' + type;
			return parameterConstructor(model);
		}
	}
});