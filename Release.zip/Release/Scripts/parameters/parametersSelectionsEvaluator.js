﻿define(
['knockout', 'underscore'],
function (ko, _) {
	'use strict';

	return function parametersSelectionEvaluatorConstructor(parameters, additionalParameters) {
		var additional = additionalParameters && additionalParameters() || [];
		var allParameters = ko.computed(function getAllParameters() {
			return additional.concat(parameters());
		});

		var _selectionEvaluator = {
			getAllSelections: getAllSelections
			, getAllSelectionsDescriptions: getSelectionsDescriptions
			, getAllSelectionsWithDescriptions: getAllSelectionsWithDescriptions
			, getAllSelectionsWithoutStacking: getAllSelectionsWithoutStacking
			, getAllSelectionsWithDescriptionsWithoutStacking: getAllSelectionsWithDescriptionsWithoutStacking
		}

		return _selectionEvaluator;

		function getAllSelections() {
			return getSelectionsKeys();
		}

		function getAllSelectionsWithDescriptions() {
			return _.extend(getSelectionsKeys(), getSelectionsDescriptions());
		}

		function getSelectionsKeys() {
			return _.mapObject(allParameters(), function (parameter) {
				return [parameter.Name(), getKey(parameter)];
			});
		}

		function getSelectionsDescriptions() {
			return _.mapObject(allParameters(), function (parameter) {
				return [(parameter.Name() + 'Desc'), getDesc(parameter)];
			});
		}		

		function getAllSelectionsWithDescriptionsWithoutStacking() {
			return _.extend(getSelectionsKeysWithoutStacking(), getSelectionsDescriptionsWithoutStacking());
		}

		function getSelectionsKeysWithoutStacking() {
			return _.mapObject(allParameters(), function (parameter) {
				return [parameter.Name(), valueWithoutStacking(parameter, getKey(parameter))];
			});
		}

		function getAllSelectionsWithoutStacking() {
			return getSelectionsKeysWithoutStacking();
		}

		function getSelectionsDescriptionsWithoutStacking() {
			return _.mapObject(allParameters(), function (parameter) {
				return [(parameter.Name() + 'Desc'), valueWithoutStacking(parameter, getDesc(parameter))]
			});
		}

		function valueWithoutStacking(parameter, selection) {
			var value = parameter.IsStackingParameter && tryJsonParse(selection);
			return (_.isArray(value) && _.first(value)) || selection;
		}

		function getKey(parameter) {
			return getFirstPropertyWithName(parameter.userSelection(), ['key', 'Key']);
		}

		function getDesc(parameter) {
			return getFirstPropertyWithName(parameter.userSelection(), ['desc', 'Description']);
		}

		function getFirstPropertyWithName(selection, propertyNames) {
			if (!_.isObject(selection))
				return selection;

			var res;
			_.each(propertyNames, function (name) {
				if (_.isUndefined(res) && _.has(selection, name))
					res = selection[name];
			});

			return res;
		}

		function tryJsonParse(str, def) {
			try { if (str) return JSON.parse(str); }
			catch (e) { return def || str; }
		}
	}

});