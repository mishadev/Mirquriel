﻿define(
['knockout', 'underscore', 'parameters/parametersEvaluator', 'parameters/parametersFactory', 'parameters/parametersSelectionsEvaluator'],
function (ko, _, parametersEvaluator, parametersFactory, parametersSelectionsEvaluator) {
	'use strict';

	return function parametersContextConstructor(parameters, additionalParameters, api) {
		var factory = parametersFactory(),
			subscriptions = [],
			_parametersContext = {
				parameters: ko.observableArray(createParameters(parameters)),
				loading: ko.observable(true),
				isFulfilled: ko.observable(),
				deserializeParameterWithName: deserializeParameterWithName
			};

		_parametersContext.subscribeOnUserSelectionsChanged = _.partial(subscribeOnUserSelectionsChanged, _parametersContext.parameters());

		var selectionsEvaluator = parametersSelectionsEvaluator(_parametersContext.parameters, additionalParameters);
		_parametersContext.evaluator = parametersEvaluator(_parametersContext.parameters, additionalParameters, api, selectionsEvaluator);
		_parametersContext.evaluator.evaluateParameters().always(_.partial(_parametersContext.loading, false));

		_parametersContext.getDependentParameters = function (parameter) {
			return evaluator.getDependentParameters(parameter);
		}

		_parametersContext.isFulfilled(allHasSelections());
		subscribeOnUserSelectionsChanged(_parametersContext.parameters(), function () {
			_parametersContext.isFulfilled(allHasSelections());
		});

		_parametersContext.allSelections = ko.pureComputed(selectionsEvaluator.getAllSelections);
		_parametersContext.allSelectionsDescs = ko.pureComputed(selectionsEvaluator.getAllSelectionsDescriptions);
		_parametersContext.allSelectionsWithDescs = ko.pureComputed(selectionsEvaluator.getAllSelectionsWithDescriptions);
		_parametersContext.allSelectionsWithoutStacking = ko.pureComputed(selectionsEvaluator.getAllSelectionsWithoutStacking);
		_parametersContext.allSelectionsWithoutStackingDescs = ko.pureComputed(selectionsEvaluator.getAllSelectionsWithDescriptionsWithoutStacking);

		return _parametersContext;

		function allHasSelections() {
			return _.all(_.invoke(_parametersContext.parameters, 'hasSelection'));
		}

		function subscribeOnUserSelectionsChanged(parameters, subscriber) {
			if(_.isArray(ko.unwrap(parameters)))
				_.each(parameters, function (p) { p.userSelection.subscribe(_.partial(subscriber, p)) });
		}

		function createParameters(parameters) {
			return _.map(parameters, createParameter);
		}

		function createParameter(parameter) {
			return factory.createParameter(ko.toJS(parameter));
		}

		function deserializeParameterWithName(name, value) {
			var parameter = _.find(_parametersContext.parameters, function (parameter) { return parameter.Name() === name; });
			parameter && parameter.deserializeUserSelection(value);
		}
	}
});