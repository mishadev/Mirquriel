﻿define(
['knockout', 'underscore', 'parameters/searchSelectParameter', 'parameters/selectedOptions'],
function (ko, _, searchSelectParameter, selectedOptions) {
	'use strict';

	return function multiSearchSelectParameterConstructor(model) {
		var _parameter = searchSelectParameter(model),
			separator = "%|%";
		_parameter.separator = separator;
		_parameter.systemParameters = _.union(_.difference(_parameter.systemParameters, 'searchKey'), 'searchKeys');
		_parameter.selectedOptions = selectedOptions(_parameter);
		_parameter.deserializeWhenEvaluated = tryJsonParse(_parameter.deserializeWhenEvaluated);

		_parameter.userSearchSelection = ko.computed({
			read: function () {
				var selection = _parameter.serializeUserSelection() || [];

				return selection.join(_parameter.separator);
			}
			, write: function (value) {
				_parameter.deserializeUserSelection((value || '').split(_parameter.separator));
			}
		});

		//overwrite parameter
		_parameter.serializeUserSelection = function () {
			return _parameter.selectedOptions();
		}

		//overwrite searchSelectParameter
		_parameter.buildDataQuery = function (value) {
			value = value || [];
			return { searchTerm: '', rowsPerPage: value.length || 1, pageNumber: 1, searchKeys: value };
		}

		_parameter.trySetSelection = function (value) {
			var existingKeys = _.pluck(_parameter.evaluatedValues, 'key'),
				result = false;

			if (result = !_.any(_.difference(value, existingKeys)))
				_parameter.selectedOptions(value);

			return result;
		}

		return _parameter;
	}
	function tryJsonParse(json) {
		try {
			if (_.isString(json))
				return JSON.parse(json);
		} catch (e) {
		}
		return json;
	}
});