﻿define(
['knockout', 'underscore', 'knockout.mapping'],
function (ko, _, mapping) {
	'use strict';

	return function parameterConstructor(model, availableEvaluationTypes) {
		availableEvaluationTypes = availableEvaluationTypes || ['SQL', 'JSON', 'NONE'];
		if (!_.contains(availableEvaluationTypes, model.EvaluationType))
			throw "Parameter of this type does not support evaluation type " + model.EvaluationType;

		var mappingOptions = {
			copy: ['Id', 'IsOptionalParameter', 'IsStackingParameter', 'SelectAllByDefault', 'DefaultSelection']
		};
		var mappedObject = mapping.fromJS(mapping.toJS(model), mappingOptions);

		var _parameter = _.extend({
			userSelection: ko.observable(undefined)
			, evaluatedValues: ko.observableArray([])
			, evaluationErrorMessage: ko.observable(undefined)
			, missingPrereqs: ko.observable(true)
			, hasSelection: hasSelection
			, loading: ko.observable(false)
			, clearUserSelection: clearUserSelection
			, clearEvaluatedValues: clearEvaluatedValues
			, setEvaluatedValues: setEvaluatedValues
			, serializeUserSelection: serializeUserSelection
			, deserializeUserSelection: deserializeUserSelection
			, stringify: stringify
			, availableEvaluationTypes: availableEvaluationTypes
			, OverriddenDisplayName: ko.observable(null)
			, evaluated: ko.observable(false)
			, evaluationRequest: ko.observable()
			, createSpecificSelections: _.identity
			, systemParameters: ['username']
		}, mappedObject);

		_parameter.computedDisplayName = ko.computed(function () {
			return _parameter.OverriddenDisplayName() ? _parameter.OverriddenDisplayName() : _parameter.DisplayName();
		})

		_parameter.templateName = ko.computed(function () {
			return "tmpl-param-" + _parameter.ParamType().toLowerCase();
		});

		_parameter.optionsCannotBeEvaluated = ko.computed(function () {
			return !!(_parameter.missingPrereqs() || _parameter.evaluationErrorMessage());
		});

		_parameter.deserializeWhenEvaluated = parseDefaultSelection(); //will be set default if not changed
		_parameter.evaluated.subscribe(function (isEvaluated) {
			if (isEvaluated) {
				if (_.isUndefined(_parameter.deserializeWhenEvaluated)) return;

				var deserialize = _parameter.deserializeWhenEvaluated;
				_parameter.deserializeWhenEvaluated = undefined;//clean before deserializeUserSelection in order to let resetting of it during deserializeUserSelection
				_parameter.deserializeUserSelection(deserialize);
			}
		});

		//we have to request an evaluation if userSelection changes
		//since parameters of different types have different fields for requesting the evaluation
		//it should be done inside the parameter
		_parameter.userSelection.subscribe(function () {
			_parameter.evaluationRequest({ dependents: true });
		});

		return _parameter;

		function stringify(value) {
			if (!_.isUndefined(value) && !_.isNull(value))
				return value.toString();
		}

		function serializeUserSelection() {
			if (_parameter.userSelection())
				return _parameter.stringify(_parameter.userSelection().key);
		}

		function deserializeUserSelection(value) {
			if (!_parameter.evaluated())
				return _parameter.deserializeWhenEvaluated = value;

			value = _parameter.stringify(value);

			var selection = _.findBy(_parameter.evaluatedValues, value, "key");
			_parameter.userSelection(selection);
		}

		function parseDefaultSelection() {
			var defaultSelection = tryJsonParse(_parameter.DefaultSelection);
			
			if(_.isUndefined(defaultSelection) || _.isNull(defaultSelection))
				return;

			return defaultSelection.key;
		}

		function hasSelection() {
			return _parameter.IsOptionalParameter || !!_parameter.userSelection();
		}

		function clearUserSelection() {
			_parameter.userSelection(undefined);
		}

		function clearEvaluatedValues() {
			_parameter.evaluatedValues([]);
		}

		function setEvaluatedValues(values) {
			_.each(values, function (option) { option.key = option.key.toString() });
			_parameter.evaluatedValues(values);
		}

		function tryJsonParse(json) {
			var result = json;
			try {
				result = JSON.parse(json);
			} catch (e) {
			}
			return result;
		}
	}
});