﻿define(
['knockout', 'underscore', 'parameters/editorParametersFactory', 'parameters/parametersContext'],
function (ko, _, parametersFactory, parametersContext) {
	'use strict';

	return function editorParametersContextConstructor(api, defaultDatamart, onParameterUpdated) {
		var factory = parametersFactory(defaultDatamart, onParameterUpdated),
			_editorParametersContext = _.extend(parametersContext(ko.observableArray([]), ko.observableArray([]), api),
			{
				loadParameters: loadParameters
				, addParameter: addParameter
				, deleteParameter: deleteParameter
				, parameterUpdated: parameterUpdated
				, subscribeOnDatamartChanged: subscribeOnDatamartChanged
				, showDebugInfo: ko.observable(false)
				, getPrerequisites: getPrerequisitesForParameter
			}
		);

		return _editorParametersContext;

		function loadParameters(parametersModels) {
			_editorParametersContext.loading(true);
			_editorParametersContext.parameters(createParameters(parametersModels));
			_editorParametersContext.evaluator.evaluateParameters().always(function () {
				_editorParametersContext.loading(false);
				_.each(_editorParametersContext.parameters(), _.partial(_editorParametersContext.subscribeOnDatamartChanged));
			});
		}

		function createParameters(models) {
			return _.map(models, createParameter);
		}

		function createParameter(model) {
			return factory.createParameter(model);
		}

		function addParameter(parameterModel) {
			var parameter = createParameter(parameterModel);
			_editorParametersContext.parameters.unshift(parameter);
			_editorParametersContext.evaluator.evaluateParameters();
			return parameter;
		}

		function getPrerequisitesForParameter(parameter) {
			return _editorParametersContext.evaluator.getNamesOfPrerequisiteParameters(parameter).join(',');
		}

		function deleteParameter(parameter) {
			_editorParametersContext.parameters.remove(parameter);
			_editorParametersContext.evaluator.evaluateParameters();
		}
		
		//dependency could be changed so we have to refresh LoadOrder for this parameter
		function parameterUpdated(parameter) {
			_editorParametersContext.evaluator.addParameterToLoadOrder(parameter);
			_editorParametersContext.evaluator.evaluateParameters();
		}

		function subscribeOnDatamartChanged(parameter) {
			parameter.datamartConnectionStringName.subscribe(function () {
				_editorParametersContext.evaluator.cleanupEvaluatedFlagOnDependants(parameter, true);
				_editorParametersContext.evaluator.evaluateParameters();
			});
		}
	}
});