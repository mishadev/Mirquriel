﻿define(
['knockout', 'underscore', 'knockout-hashParamerterBinding'],
function (ko, _, hashParamerterBinding) {
	'use strict';

	return function parametersContextBinderConstructor(parametersContext, toggle, selectionsNameInUrl) {
		var toggleSubscription;
		if (ko.isSubscribable(toggle))
			toggleSubscription = toggle.subscribe(_.partial(bindToUrl));

		bindToUrl(ko.unwrap(toggle));

		return {
			dispose: function () {
				bindToUrl(false);
				if (!_.isUndefined(toggleSubscription))
					toggleSubscription.dispose();
			}
		}

		function bindToUrl(isOn) {
			var urlBindingAction = isOn ? bindParameter : unbindParameter;

			_.each(parametersContext.parameters(), urlBindingAction, parametersContext);
		}

		function bindParameter(parameter) {
			var name = parameter.Name(),
				paramSelectionsNameInUrl = selectionsNameInUrl || 'ps';

			hashParamerterBinding.bindToUrl({
				parameterName: name
				, observable: parameter.userSelection
				, getHashValue: function (params) {
					return params[paramSelectionsNameInUrl] && params[paramSelectionsNameInUrl][name];
				}
				, setHashValue: function (params, val) {
					(params[paramSelectionsNameInUrl] || (params[paramSelectionsNameInUrl] = {}))[name] = val;
				}
				, removeHashValue: function (params) {
					if (params[paramSelectionsNameInUrl])
						delete params[paramSelectionsNameInUrl][name];
				}
				, setObservable: parameter.deserializeUserSelection
				, serializableValue: parameter.serializeUserSelection
			});
		}

		function unbindParameter(parameter) {
			hashParamerterBinding.unbindFromUrl(parameter.userSelection);
		}
	}
});