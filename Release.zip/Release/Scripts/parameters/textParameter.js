﻿define(
['knockout', 'underscore', 'parameters/parameter'],
function (ko, _, parameter) {
	'use strict';

	return function textParameterConstructor(model) {
		var _parameter = parameter(model);

		_parameter.deserializeWhenEvaluated = _parameter.DefaultSelection;

		_parameter.serializeUserSelection = function () {
			return _parameter.stringify(_parameter.userSelection());
		}

		_parameter.deserializeUserSelection = function (value) {
			_parameter.userSelection(_parameter.stringify(value));
		}
		
		// 'evaluated' state will be set right after 'evaluatedValues' will be changed
		// and setting of the 'evaluated' state will cause applying of 'deserializeWhenEvaluated'
		_parameter.evaluatedValues.subscribe(function (values) {
			if (!_.any(values) || _parameter.userSelection()) return;

			var propertyValue = _.first(_.values(_.first(values)));//get first property of first object
			_parameter.deserializeWhenEvaluated = propertyValue;
		});
		return _parameter;
	}
});