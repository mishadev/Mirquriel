﻿define(
['knockout', 'underscore'],
function (ko, _) {
	'use strict';

	return function selectedOptionsConstructor(parameter, separator) {
		return ko.computed({
			read: function () {
				var userSelection = parameter.userSelection();
				if (_.isUndefined(userSelection))
					return [];

				var result = tryJsonParse(userSelection.key);
				return result ? result : [];
			}
			, write: function (value) {
				var userSelection;

				if (!_.isArray(value)) return;

				var options = _.unique(_.filter(parameter.evaluatedValues(), function (option) {
					return _.contains(value, option.key);
				}));
				if (options.length) {
					var chain = _.chain(options).compact();
					userSelection = { key: ko.toJSON(chain.pluck('key').value()), desc: ko.toJSON(chain.pluck('desc').value()) };
				}

				parameter.userSelection(userSelection);
			}
		});

		function tryJsonParse(json) {
			var result = json;
			try {
				result = JSON.parse(json);
			} catch (e) {
			}
			return result;
		}
	}
});