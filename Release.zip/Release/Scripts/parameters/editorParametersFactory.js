﻿define(
['knockout', 'underscore', 'knockout.mapping', 'parameters/parametersFactory'],
function (ko, _, mapping, parametersFactory) {
	'use strict';
	return function editorParametersFactoryConstructor(defaultDatamart, parameterUpdated) {
		var factory = parametersFactory(),
			_editorFactory = { createParameter: createParameter };

		return _editorFactory;

		function createParameter(model) {
			var parameter = factory.createParameter(model);
			return _.extend(
				parameter,
				{
					datamartConnectionStringName: ko.observable(defaultDatamart),
					parameterTypes: factory.parameterTypes,
					parameterType: ko.computed({
						read: function () { return parameter.ParamType(); },
						write: function (paramType) {
							if (!_.isEqual(paramType, parameter.ParamType())) updateParameter(parameter, paramType);
						}
					}),
					showAdditionalMessage: ko.computed(function () { return parameter.ParamType() === "CHECKBOX" })
				});
		}

		function updateParameter(parameter, paramType) {
			var model = createModel(parameter, paramType);
			var newparameter = createParameter(model);
			parameterUpdated(parameter, newparameter);
		}

		function createModel(parameter, paramType) {
			var model = mapping.toJS(parameter);
			model.ParamType = paramType;

			var availableEvaluationType = {
				CHECKBOX: 'JSON',
				SELECT: 'JSON',
				MULTISELECT: 'JSON',
				SEARCHSELECT: 'SQL',
				MULTISEARCHSELECT: 'SQL'
			}

			var evaluationSourceTemplate = {
				CHECKBOX: '[{"desc":"False", "key": false}, {"desc":"True", "key": true}]',
				SEARCHSELECT: "\/*This SQL query has to allow searching and lazy-appending parameter options in a large datasets.\n" +
				"Please use the following SQL parameters in this query:\n" +
				"@searchTerm    (mandatory):    Search string entered by user. The SQL query should ignore null or empty value or retun options with matching descriptions.\n" +
				"@searchKey     (mandatory):    Search key. The SQL query should ignore null or empty value or return an option with matching key.\n" +
				"@pageNumber    (mandatory):    1-based page number that query should return.\n" +
				"@rowsPerPage (recommended):    number of rows that query should return for the page with @pageNumber.\n" +
				"\n" +
				"Your query or stored procedure should follow this generic template (for SQL Server 2012):\n" +
				"SELECT  [key], [desc]\nFROM    [AllPossibleOptions]\n" +
				"WHERE   (NULLIF(@searchKey,  \'\') IS NULL OR [key]= @searchKey)\n" +
				"        AND \n" +
				"        (NULLIF(@searchTerm, \'\') IS NULL OR [desc] LIKE \'%\' + @searchTerm + \'%\')\n" +
				"        -- optionally filter here by additional parameters\n" +
				"ORDER BY [desc]\n" +
				"OFFSET (@pageNumber - 1) * @rowsPerPage ROWS\n" +
				"FETCH NEXT @rowsPerPage ROWS ONLY\n" +
				"*\/\n" +
				"\n" +
				"-- Example for SQL Server 2005\/2008\nSELECT [key], [desc] FROM (\n" +
				"    SELECT [key], [desc], ROW_NUMBER() OVER (ORDER BY [desc]) AS RowNum FROM (\n" +
				"        SELECT [key], [desc] FROM  (\n" +
				"            SELECT       1 AS [key], \'Jon Moor\'    AS [desc]\n" +
				"            UNION SELECT 2,          \'Colin Farrell\'\n" +
				"            UNION SELECT 3,          \'Sally Jonson\' ) AS [AllPossibleOptions]\n" +
				"        WHERE (NULLIF(@searchKey, \'\') IS NULL OR [key]= @searchKey)\n" +
				"              AND \n" +
				"              (NULLIF(@searchTerm,\'\') IS NULL OR [desc] LIKE \'%\' + @searchTerm + \'%\')\n" +
				"    ) AS Q\n" +
				") AS WithRowNum\n" +
				"WHERE RowNum BETWEEN ((@pageNumber - 1) * @rowsPerPage) + 1 AND @rowsPerPage * @pageNumber",
				MULTISEARCHSELECT: "\/*This SQL query has to allow searching and lazy-appending parameter options in a large datasets.\n" +
				"Please use the following SQL parameters in this query:\n" +
				"@searchTerm    (mandatory):    Search string entered by user. The SQL query should ignore null or empty value or retun options with matching descriptions.\n" +
				"@searchKeys    (mandatory):    Search keys predefined table type. The SQL query should ignore empty table or return an option which intersect.\n" +
				"@pageNumber    (mandatory):    1-based page number that query should return.\n" +
				"@rowsPerPage (recommended):    number of rows that query should return for the page with @pageNumber.\n" +
				"\n" +
				"Yor query or stored procedure should follow this generic template (for SQL Server 2012):\n" +
				"SELECT  [key], [desc]\nFROM    [AllPossibleOptions]\n" +
				"WHERE   (NOT EXISTS (SELECT TOP 1 * FROM @searchKeys) OR [key] IN (SELECT value FROM @searchKeys))\n" +
				"        AND \n" +
				"        (NULLIF(@searchTerm, \'\') IS NULL OR [desc] LIKE \'%\' + @searchTerm + \'%\')\n" +
				"        -- optionally filter here by additional parameters\n" +
				"ORDER BY [desc]\n" +
				"OFFSET (@pageNumber - 1) * @rowsPerPage ROWS\n" +
				"FETCH NEXT @rowsPerPage ROWS ONLY\n" +
				"*\/\n" +
				"\n" +
				"-- Example for SQL Server 2005\/2008\nSELECT [key], [desc] FROM (\n" +
				"    SELECT [key], [desc], ROW_NUMBER() OVER (ORDER BY [desc]) AS RowNum FROM (\n" +
				"        SELECT [key], [desc] FROM  (\n" +
				"            SELECT       1 AS [key], \'Jon Moor\'    AS [desc]\n" +
				"            UNION SELECT 2,          \'Colin Farrell\'\n" +
				"            UNION SELECT 3,          \'Sally Jonson\' ) AS [AllPossibleOptions]\n" +
				"        WHERE (NOT EXISTS (SELECT TOP 1 * FROM @searchKeys) OR [key] IN (SELECT value FROM @searchKeys))\n" +
				"              AND \n" +
				"              (NULLIF(@searchTerm,\'\') IS NULL OR [desc] LIKE \'%\' + @searchTerm + \'%\')\n" +
				"    ) AS Q\n" +
				") AS WithRowNum\n" +
				"WHERE RowNum BETWEEN ((@pageNumber - 1) * @rowsPerPage) + 1 AND @rowsPerPage * @pageNumber"
			}

			if (_.contains(_.values(evaluationSourceTemplate), model.EvaluationSource))
				model.EvaluationSource = null;

			if (!model.EvaluationSource)
				model.EvaluationSource = evaluationSourceTemplate[model.ParamType] || null;

			if (_.has(availableEvaluationType, model.ParamType))
				model.EvaluationType = availableEvaluationType[model.ParamType];

			return model;
		}
	}
});