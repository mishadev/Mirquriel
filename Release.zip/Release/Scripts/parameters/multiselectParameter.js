﻿define(
['knockout', 'underscore', 'parameters/parameter', 'parameters/selectedOptions'],
function (ko, _, parameter, selectedOptions) {
	'use strict';

	return function multiselectParameterConstructor(model) {
		var _parameter = parameter(model, ['SQL', 'JSON']),
			selectAllToken = "*";

		_parameter.serializeUserSelection = function () {
			return multiSelectValueAllSelected() ? selectAllToken : _parameter.selectedOptions();
		}

		_parameter.deserializeUserSelection = function (value) {
			if (!_parameter.evaluated())
				return _parameter.deserializeWhenEvaluated = value;

			var selection = value === selectAllToken ?
				_.pluck(_parameter.evaluatedValues(), 'key') :
				tryJsonParse(value);

			if (!_.isEqual(_parameter.selectedOptions(), selection))
				_parameter.selectedOptions(selection);
		}

		_parameter.selectedOptions = selectedOptions(_parameter);

		return _parameter;

		function multiSelectValueAllSelected() {
			return _.any(_parameter.selectedOptions()) && _.any(_parameter.evaluatedValues())
				&& _parameter.selectedOptions().length === _parameter.evaluatedValues().length;
		}
	}
	function tryJsonParse(json) {
		var result = json;
		try {
			if (_.isString(json))
				result = JSON.parse(json);
		} catch (e) {
		}
		return result;
	}
});