﻿define(
['knockout', 'underscore', 'parameters/parameter'],
function (ko, _, parameter) {
	'use strict';

	return function selectParameterConstructor(model) {
		var _selectParameter = parameter(model, ['SQL', 'JSON']);

		return _selectParameter;
	}

});