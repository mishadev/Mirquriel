﻿define(
['knockout', 'underscore', 'parameters/parameter'],
function (ko, _, parameter) {
	'use strict';

	return function searchSelectParameterConstructor(model) {
		var _parameter = parameter(model, ['SQL']);

		_parameter.systemParameters = _.union(_parameter.systemParameters, ['pageNumber', 'rowsPerPage', 'searchTerm', 'searchKey']);
		_parameter.createSpecificSelections = function (selections) {
			// inject search input and paging paramters to filter param choices
			// white-list of config properties so we don't accidentally overwrite other parameters being used in the SQL statement
			var dataQuery = _.defaults(_parameter.dataQuery() || {}, _parameter.buildDataQuery());
			return _.extend({}, selections, _.pick(dataQuery, _parameter.systemParameters));
		}

		_parameter.deserializeUserSelection = function (value) {
			if (!value)
				return _parameter.clearUserSelection();

			//try set option from options
			if (_parameter.trySetSelection(value))
				return;

			_parameter.deserializeWhenEvaluated = value;//will be deserialized after next evaluation

			var query = _parameter.buildDataQuery(value);
			if (!_.isEqual(query, _parameter.dataQuery()))
				_parameter.dataQuery(query);//will request new data and evaluate the parameter
		}

		// should return dummy dataQuery if no parameters has been passed
		_parameter.buildDataQuery = function (value) {
			value = value || '';
			return { searchTerm: '', rowsPerPage: 1, pageNumber: 1, searchKey: value };
		}

		_parameter.trySetSelection = function (value) {
			var option = _.findBy(_parameter.evaluatedValues, value, 'key'),
				result = false;

			if (result = (!_.isUndefined(option) && !_parameter.missingPrereqs()))
				return _parameter.userSelection(option);

			return result;
		}

		// this function is called to fetch data
		_parameter.dataQuery = ko.observable();
		_parameter.dataQuery.subscribe(function (value) {
			if (!_.isUndefined(value))
				_parameter.evaluationRequest({ self: true });
		});

		_parameter.userSearchSelection = ko.computed({
			read: _parameter.serializeUserSelection
			, write: _parameter.deserializeUserSelection
		});

		return _parameter;
	}
});