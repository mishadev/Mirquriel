﻿define(
['knockout', 'underscore', 'parameters/parameter'],
function (ko, _, parameter) {
	'use strict';

	return function checkboxParameterConstructor(model) {
		var _parameter = parameter(model, ['SQL', 'JSON']);

		_parameter.userCheckboxSelection = ko.computed({
			read: function () {
				return _parameter.evaluatedValues().indexOf(_parameter.userSelection()) === 1;
			}
			, write: function (value) {
				_parameter.userSelection(_parameter.evaluatedValues()[+value]);
			}
		});

		_parameter.evaluatedValues.subscribe(function (values) {
			if (!_.any(values) || _parameter.userSelection() || !_.isUndefined(_parameter.deserializeWhenEvaluated)) return;

			_parameter.deserializeWhenEvaluated = _parameter.evaluatedValues()[0].key;
		});

		return _parameter;
	}

});