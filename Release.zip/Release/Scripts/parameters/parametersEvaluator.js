﻿define(
['knockout', 'underscore', 'jquery'],
function (ko, _, $) {
	'use strict';
	var SQL_PARAM_REGEX = /@(\w+)/g;
	var jsonEvaluationType = 'JSON';
	var sqlEvaluationType = 'SQL';
	var noneEvaluationType = 'NONE';
	var textParameterType = 'TEXT';
	var undefinedErrorMessage = 'Undefined error';
	return function parametersEvaluatorConstructor(parameters, additionalParameters, api, selectionsEvaluator) {
		var _parametersEvaluator = {
			evaluationTypes: [noneEvaluationType, jsonEvaluationType, sqlEvaluationType]
			, getNamesOfPrerequisiteParameters: getNamesOfPrerequisiteParameters
			, getDependentParameters: getDependentParameters
			, evaluate: evaluate
			, isPrerequisitesReady: isPrerequisitesReady
			, evaluateParameters: evaluateParameters
			, cleanupEvaluatedFlagOnDependants: cleanupEvaluatedFlagOnDependants
			, addParameterToLoadOrder: addParameterToLoadOrder
			, deleteParameterFromLoadOrder: deleteParameterFromLoadOrder
			, refreshEvaluationOrder: refreshEvaluationOrder
			, createEvaluationOrder: createEvaluationOrder
		}

		var allPrerequisiteParameters = ko.computed(function getAllPrerequisiteParameters() {
			return parameters().concat(additionalParameters && additionalParameters() || []);
		});

		var orderedParameters = [],
			subscriptions = [];

		_.each(parameters, subscribeOnUserSelection);

		parameters.subscribe(function (changes) {
			_.each(changes, function (change) {
				if (change.status === 'added') addParameter(change.value);
				if (change.status === 'deleted') deleteParameter(change.value);
			});
			refreshEvaluationOrder();
		}, null, "arrayChange");

		subscribeOnUserSelectionsChanged(additionalParameters, function (dependsOn) {
			_.each(parameters(), function (dependant) {
				if (_.contains(getPrerequisiteParameters(dependant), dependsOn)) {
					cleanupEvaluatedFlagOnDependants(dependant, true);
					evaluateParameters();
				}
			});
		});

		refreshEvaluationOrder();

		return _parametersEvaluator;

		function subscribeOnUserSelectionsChanged(parameters, subscriber) {
			if (_.isArray(ko.unwrap(parameters)))
				_.each(parameters, function (p) { p.userSelection.subscribe(_.partial(subscriber, p)); });
		}

		function subscribeOnUserSelection(parameter) {
			if (ko.isObservable(parameter.evaluationRequest)) {
				subscriptions[parameter.Id + 'evaluationRequest'] = parameter.evaluationRequest.subscribe(function (evaluate) {
					var requested = false;

					if (requested = evaluate.dependents && evaluate.self)
						cleanupEvaluatedFlagOnDependants(parameter, true);
					else if (requested = evaluate.dependents)
						cleanupEvaluatedFlagOnDependants(parameter);
					else if (requested = evaluate.self)
						parameter.evaluated(false);

					if (requested)
						evaluateParameters();
				});
			}
		}

		function addParameter(parameter) {
			subscribeOnUserSelection(parameter);
			cleanupEvaluatedFlagOnDependants(parameter, true);
		}

		function deleteParameter(parameter) {
			cleanSubscription(parameter);
			cleanupEvaluatedFlagOnDependants(parameter, true);
		}

		function cleanSubscription(parameter) {
			var subscription = subscriptions[parameter.Id + 'evaluationRequest'];
			if (!_.isUndefined(subscription) && _.isFunction(subscription.dispose)) subscription.dispose();
		}

		function refreshEvaluationOrder() {
			orderedParameters = createEvaluationOrder();
		}

		function evaluate(parameter) {
			if (parameter.EvaluationType() === noneEvaluationType)
				return $.Deferred().resolve(getEvaluationResult(undefined, undefined));

			if (parameter.EvaluationType() === jsonEvaluationType)
				return evaluateJson(parameter.EvaluationSource());

			if (parameter.EvaluationType() === sqlEvaluationType)
				return evaluateSql(parameter);

		}

		function evaluateSql(parameter) {
			var deferred = $.Deferred();

			if (!_.isUndefined(parameter.request) && _.isFunction(parameter.request.abort))
				parameter.request.abort();

			var selections = parameter.createSpecificSelections(selectionsEvaluator.getAllSelections());
			parameter.request = api.getParameterOptions(parameter, selections);

			parameter.request.done(function (data) {
				var result;
				var errorMessage;
				if (data.Error)
					errorMessage = data.Error.Message || undefinedErrorMessage;
				else if (data.Result)
					result = data.Result;
				else
					errorMessage = undefinedErrorMessage;
				deferred.resolve(getEvaluationResult(result, errorMessage));
			});

			parameter.request.fail(function (xhr, errorMessage) {
				deferred.resolve(getEvaluationResult(undefined, getError(errorMessage)));
			});

			return deferred;
		}

		function evaluateJson(json) {
			var deferred = $.Deferred();
			var result;
			var errorMessage;
			try {
				result = JSON.parse(json);
			} catch (error) {
				errorMessage = getError(error);
			}
			return deferred.resolve(getEvaluationResult(result, errorMessage));
		}

		function getError(error) {
			return error.message || error || undefinedErrorMessage;
		}

		function getEvaluationResult(result, errorMessage) {
			return {
				isError: !!errorMessage
				, errorMessage: errorMessage
				, result: result
			}
		}

		function isPrerequisitesReady(parameter) {
			var prerequisites = getNamesOfPrerequisiteParameters(parameter);
			var allParameters = allPrerequisiteParameters();
			return _.all(prerequisites, function (prerequisiteName) {
				var prerequisiteParameter = _.find(allParameters, function (p) { return p.Name() === prerequisiteName });
				return prerequisiteParameter && prerequisiteParameter.hasSelection();
			});
		}

		function getPrerequisiteParameters(parameter) {
			return _.chain(getNamesOfPrerequisiteParameters(parameter))
				.map(function (parameterName) {
					return _.find(allPrerequisiteParameters(), function (parameter) { return parameter.Name() === parameterName; });
				})
				.reject(function (r) { return !r })
				.value();
		}

		function getDependentParameters(parameter) {
			var orderedParameter = _.chain(orderedParameters).flatten()
				.find(function (item) { return item.parameter.Id === parameter.Id;}).value();
			
			if (!orderedParameter) return [];

			return _.pluck(orderedParameter.dependants, 'parameter');
		}

		function getNamesOfPrerequisiteParameters(parameter) {
			if (parameter.ParamType() === textParameterType || parameter.EvaluationType() !== sqlEvaluationType || !parameter.EvaluationSource())
				return [];

			var matches = parameter.EvaluationSource().match(SQL_PARAM_REGEX);
			return _.chain(matches || [])
					.map(function (m) { return m.substring(1); })
					.reject(function (m) { return _.any(parameter.systemParameters, function (item) { return item.toLowerCase() === m.toLowerCase() }); })
					.unique()
					.value();
		}

		function createEvaluationOrder() {
			var hashSet = {};
			var notFoundPrerequisites = [];
			var params = parameters();

			_.each(params, function addToHash(parameter) { hashSet[parameter.Id] = createOrderItem(parameter) });

			_.each(params, _.partial(fillDependants, hashSet, notFoundPrerequisites));

			var ordered = [[]];

			_.each(params, function fillNoDependenciesOrder(parameter) {
				var hash = hashSet[parameter.Id];
				if (!hash.dependsOn.length)
					ordered[0].push(hash);
			});

			//Parameter evaluation logic has changed previously each change of each parameter resulted in all parameters recalculation
			//that were not filled this implementation builds unnormilized dependency tree with the parameters 
			//as a result only parameters that have all necessary selections will react to selections change
			_.each(ordered[0], _.partial(fillLevelRecursive, 0));

			_.each(params, function fillNonZeroLevels(parameter) {
				var hash = hashSet[parameter.Id];
				if (!hash.level)
					return;
				var array = ordered[hash.level] || (ordered[hash.level] = []);
				array.push(hash);
			});

			ordered.hashSet = hashSet;
			ordered.notFoundPrerequisites = notFoundPrerequisites;
			return ordered;
		}

		function createOrderItem(parameter) {
			return { parameter: parameter, dependants: [], dependsOn: [] };
		}

		function fillDependants(hashSet, notFoundPrerequisites, parameter ) {
			var prerequisites = getPrerequisiteParameters(parameter);

			_.each(prerequisites, function pushPrerequisite(prerequisite) {
				var prerequisiteHash = hashSet[prerequisite.Id];
				if (!prerequisiteHash) {
					return;
				}
				var dependantHash = hashSet[parameter.Id];
				if (!dependantHash)
					return;
				prerequisiteHash.dependants.push(dependantHash);
				dependantHash.dependsOn.push(prerequisiteHash);
			});
		}

		function fillLevelRecursive(level, item) {
			if (_.isUndefined(item.level) || item.level < level)
				item.level = level;
			if (item.dependants.length)
				_.each(item.dependants, _.partial(fillLevelRecursive, level + 1));
		};

		function evaluateParameters() {
			var deferred = $.Deferred();

			var loadLevel = function (levelIndex) {
				var d = $.Deferred();

				var callAfterCurrentDone = _.after(orderedParameters[levelIndex].length, function () {
					d.resolve(levelIndex + 1);
				});

				if (!orderedParameters[levelIndex].length) {
					callAfterCurrentDone();
					return d;
				}

				_.each(orderedParameters[levelIndex], function (parameterOrder) {
					if (parameterOrder.parameter.evaluated()) {
						callAfterCurrentDone();
						return;
					}
					parameterOrder.isPrerequisitesReady = _parametersEvaluator.isPrerequisitesReady(parameterOrder.parameter);
					parameterOrder.parameter.missingPrereqs(!parameterOrder.isPrerequisitesReady);
					if (parameterOrder.isPrerequisitesReady) {
						parameterOrder.parameter.loading(true);
						_parametersEvaluator.evaluate(parameterOrder.parameter).done(function (result) {
							if (result.errorMessage !== 'abort') {
								parameterOrder.evaluationResult = result;
								applyResult(parameterOrder, result, true);
								parameterOrder.parameter.evaluated(!result.isError);
								parameterOrder.parameter.loading(false);
							}
							callAfterCurrentDone();
						});
					} else {
						applyResult(parameterOrder, { isError: false, result: undefined }, false);
						callAfterCurrentDone();
					}
				});

				return d;
			};

			var loadLevelAsync = function (completeIndex) {
				if (completeIndex < orderedParameters.length) {
					loadLevel(completeIndex).done(loadLevelAsync);
				} else {
					deferred.resolve();
				}
			};

			loadLevelAsync(0);

			return deferred;
		}

		function applyResult(parameterOrder, evaluationResult, isPrerequisitesReady) {
			var parameter = parameterOrder.parameter;

			parameter.evaluationErrorMessage(evaluationResult.errorMessage);
			if (evaluationResult.isError || _.isUndefined(evaluationResult.result))
				parameter.clearEvaluatedValues();
			else
				parameter.setEvaluatedValues(evaluationResult.result);
		}

		function cleanupEvaluatedFlagOnDependants(parameter, cleanUpCurrent) {
			var hash = orderedParameters.hashSet[parameter.Id];
			if (!hash) return;
			if (cleanUpCurrent) {
				hash.parameter.evaluated(false);
				hash.parameter.clearUserSelection();
			}
			doActionWithParameterDependantsRecursive(hash, function (h) {
				h.parameter.evaluated(false);
				h.parameter.clearUserSelection();
			});
		}

		function doActionWithParameterDependantsRecursive(orderedItem, action) {
			_.each(orderedItem.dependants, function (dependant) {
				action(dependant);
				doActionWithParameterDependantsRecursive(dependant, action);
			});
		}

		function fillDependsOn(hashSet, dependsOn) {
			var dependsOnParameters = _.filter(parameters(), function (dependant) {
				return _.contains(getPrerequisiteParameters(dependant), dependsOn.parameter);
			});

			_.each(dependsOnParameters, function (dependant) {
				var hash = hashSet[dependant.Id];
				hash.dependsOn.push(dependsOn);
				dependsOn.dependants.push(hash);
				moveDependantToNewLevel(hash);
			});
		}

		function ensureHashSetExists() {
			//hashSet is a dictionary with the parameters related information
			//provides fast way to get parameter related data
			if (!orderedParameters.hashSet)
				orderedParameters.hashSet = {};
		}

		function addParameterToLoadOrder(parameter) {
			ensureHashSetExists();
			deleteParameterFromLoadOrder(parameter);
			var orderedItem = (orderedParameters.hashSet[parameter.Id] = createOrderItem(parameter));

			fillDependants(orderedParameters.hashSet, orderedParameters.notFoundPrerequisites, parameter);
			orderedItem.level = getDependantLevel(orderedItem);
			fillDependsOn(orderedParameters.hashSet, orderedItem);

			addOrderedItemToLevel(orderedItem);
			cleanupEvaluatedFlagOnDependants(parameter);
		}

		function deleteParameterFromLoadOrder(parameter) {
			ensureHashSetExists();
			var orderedItem = orderedParameters.hashSet[parameter.Id];
			if (!orderedItem)
				return;
			cleanupEvaluatedFlagOnDependants(parameter, true);
			_.each(orderedItem.dependants, function (d) {
				removeItemFromArray(d.dependsOn, orderedItem);
				moveDependantToNewLevel(d);
			});
			_.each(orderedItem.dependsOn, function (d) { removeItemFromArray(d.dependants, orderedItem); });

			removeItemFromArray(orderedParameters[orderedItem.level], orderedItem);
			delete orderedParameters.hashSet[parameter.Id];
		}

		function addOrderedItemToLevel(orderedItem) {
			var array = orderedParameters[orderedItem.level] || (orderedParameters[orderedItem.level] = []);
			array.push(orderedItem);
		}

		function getDependantLevel(orderedItem) {
			var maxDependsOnLevel = _.chain(orderedItem.dependsOn).pluck('level')
				.reject(_.isUndefined)
				.max()
				.value();
			return _.isFinite(maxDependsOnLevel) ? maxDependsOnLevel + 1 : 0;
		}

		function moveDependantToNewLevel(orderedItem) {
			var newLevel = getDependantLevel(orderedItem);
			if (newLevel === orderedItem.level)
				return;
			removeItemFromArray(orderedParameters[orderedItem.level], orderedItem);
			orderedItem.level = newLevel;
			addOrderedItemToLevel(orderedItem);
			_.each(orderedItem.dependants, function (dependant) {
				moveDependantToNewLevel(dependant);
			});
		}

		function removeItemFromArray(array, item) {
			var index = array.indexOf(item);
			array.splice(index, 1);
		}
	}
});