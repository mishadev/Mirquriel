define(
['jquery', '_persistState', 'localStorageWrapper'],
function ($, persistState, storage) {
	'use strict';
	$.ow.persistState.getStates = function (persistenceKey, path) {
		var stateRoot = JSON.parse(storage.getItem(persistenceKey) || '{}') || {}
			, ctxStates = tryGet(stateRoot, path)
		;
		return {
			getState: function (key) { return tryGet(ctxStates, key) }
			, save: function () {
				storage.setItem(persistenceKey, JSON.stringify(stateRoot));
			}
		};

		function tryGet(obj, key) { return obj.hasOwnProperty(key) ? obj[key] : (obj[key] = {}) }
	}

	return persistState;
});
