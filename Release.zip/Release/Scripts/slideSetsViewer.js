﻿define(
    ['jquery', 'knockout', 'constants', 'knockout.slideView'],
    function ($, ko, constants) {
        'use strict';

		// This backs the "slidesets" part of the old homepage.  Can probably go away, or be renamed something like slideSetsThumbnailStrips.

        return function slideSetsViewer(config) {
            var _slideSetsViewer = {
                slideSets: config.slideSets
            };

            _slideSetsViewer.slideSets.subscribe(function (event) {
                resize(constants.THUMBNAIL_DEFAULT_WIDTH);
            });

            return _slideSetsViewer;

            function resize(width) {
                $('#SlideSetsViewer div.thumbnail svg').css('width', width).css('height', width / constants.SLIDE_ASPECT_RATIO);
            }

        };
    }
);