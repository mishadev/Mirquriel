define(
['jquery', 'knockout', 'underscore','fullscreen'],
function ($, ko, _, fullscreen) {
'use strict';

var  unwrap                   = ko.utils.unwrapObservable
    ;
ko.bindingHandlers.fullScreen = {
	 init: function(el, valueAccessor) {
		var  op = fullScreenOptions(valueAccessor)
			;
	    $(document).on("fullscreenchange", function(e) {
	    	if(_.isFunction(op.value))
	    		op.value( isFullScreen() );
	    });
	}
	,update: function(el, valueAccessor) {
		var  op = fullScreenOptions(valueAccessor)
		;
		fullscreen(el, unwrap(op.value));
	}
};

function fullScreenOptions(valueAccessor) {
	return  valueAccessor().value ? valueAccessor() : { value: valueAccessor() };
}
function isFullScreen() { return !!fullscreen(document); }

})