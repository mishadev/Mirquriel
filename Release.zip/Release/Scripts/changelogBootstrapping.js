﻿define(
['jquery'], 
function($){
	'use strict'
	$('.version-info .version').click(function(){
		require(['text!../Content/changelog.html!strip', 'ogre.dialogs'], function(changes){
			$('<div>').html(changes).ogreDialog({
				title: "Recent Changes"
			});
		})
	})
})