define(['knockout', 'underscore'], 
function (ko,_) {
    'use strict'

    // Returns a function that will preform initialization on a sammy app that will sync a parameter context to 
    // a url eg http://localhost:55719/Datamart/#/Europe/category1/subcategory1
    // Assumes that each parameter in the parameterContext depends on all parameters that are ordered before it
    // Usage:
    //     var app = sammy(initializeHierarchyParamsSammyApp(_slideSetViewer.hierarchyParameters));
    // This module is under test in slidesetViewer.specs.coffee
    return function initializeHierarchyParamsSammyApp(paramContext) {
        return function initializeClientRouting(sammy) {
            var subscriptions = [];
            sammy.get(/\#(\/(.*))?/,function (req) {
                var parsedParts = req.params.splat[0].match(/([^\/]+)/g)
                    ,parameters = paramContext.params();
                if (!parsedParts || !parameters[0]) return;
                _.each(parameters,function (parameter,index) {
                    var item = parsedParts[index] || null; //TODO - GM - this can't be right can it? what if the key is zero?
                    if( (!parameter.userSelection() && item == null) || ( parameter.userSelection() && (item == parameter.userSelection().Key) ) ) //if things are the same
                        return
                    parameter.setSelectedAndCheckIsValid(item);
                });
            });

            // setup url to update when parameters change
            function subscribeToUserSelection() {
                var url = location.href.split('#');
                var baseUrl = url[0];
                disposeSubscriptions();
                _.each(paramContext.params(),function (p) {
                    var subscription = p.userSelection.subscribe(function updateHierarchyParamUrlToReflectState() {
                        var currentUrl = location.href.split('#');
                        var queryString = getHashedQueryString(currentUrl[1] || "");
                        var newUri = baseUrl + '#/' + _.chain(paramContext.params()).invoke('userSelection').filter(_.identity).pluck('Key').reject(function (v) { return v === null }).value().join('/') + queryString;
                        if (location.href != newUri)
                            location.href = newUri;
                    });
                    subscriptions.push(subscription);
                })
            };

            subscribeToUserSelection();

            function disposeSubscriptions() {
                _.each(subscriptions,function (s) { s.dispose() });
                subscriptions = [];
            };

            function getHashedQueryString(hashUrl) {
                var hashedqueryString = hashUrl.split('?');
                if (hashedqueryString.length > 1)
                    return "?" + hashedqueryString[1];
                return "";
            }
        }
    }
})