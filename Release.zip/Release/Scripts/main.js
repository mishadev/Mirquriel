﻿// == DO NOT MODIFY THIS FILE DIRECTLY! ==
// This file is is auto-generated and any changes will be overwritten.
// Instead modify .\Scripts\requirejs-optimization\main.js.template or Expand-RequireConfigTemplate.ps1 (depending on your needs) and regenerate this file.
// Note that main.js should be committed so that the project runs out of the box with visual studio

// GM: Inside the slide iframe we use requirejs to load up everything (it will be in cache so its ok). 
// This means that we have to give the iframe its own instance of requirejs and that instance should be configured the same way that the main site is. 
// So the slide iframe needs access to the initial configuration object that was used by requirejs.config(...). 
// As far as I can tell, there is no way to get this back out of require, so we register it explicitly as a module so that we can fetch it later.
!function() {
		var config = Object.freeze({
			 baseUrl: window.ow.appPath + 'Scripts/'
			,urlArgs: 'rev='+window.ow.revision     //TODO - GM - I'm not a fan of doing it this way: http://stackoverflow.com/questions/15940581/best-way-of-dealing-with-cached-js-files-when-iterating-rapidly-and-using-requir?noredirect=1#comment22712226_15940581
			,shim: {
     _underscore: { exports: '_' }
    ,d3: { exports: 'd3' }
    ,nvd3: { exports: 'nv', deps: ['d3'] }
    ,modernizr: { exports: 'Modernizr' }
    ,jqueryUI: { exports: '$', deps: ['jquery']}    
    ,'touch-punch': {deps: ['jqueryUI'], exports: '$'}
    ,'node-querystring': {exports: 'exprts'}
    ,'jasmine-html':  {deps: ['_jasmine']}
	,'jasmine/reporters/jasmine-jsreporter':  {deps: ['boot-jasmine']}
    ,'boot-jasmine':  {deps: ['_jasmine', 'jasmine-html']}
    ,'handlebars': { exports: 'Handlebars' }
    ,'settingsDropDownBindings': {deps:['jquery', 'knockout']}
    ,bootstrap: {deps: ['jquery']}
    ,'bootstrap-multiselect': { deps: ['jquery', 'bootstrap'] }
    ,'bootstrap-tooltip': { deps: ['jquery', 'jqueryUI', 'bootstrap'] }
    ,'bootstrap-popover': { deps: ['jquery', 'bootstrap-tooltip'] }
    ,'bootstrap-clickover': { deps: ['jquery', 'bootstrap-popover'] }
    ,'knockout': { deps: ['jquery'] }
    ,'sammy': { deps: ['jquery'] }
    ,'select2': { deps: ['jquery'] }
    ,'jquery.fullscreen': { deps:['jquery'] }
    ,'hammerjs': { deps: ['jquery'] }
    ,'jquery.fileupload': { deps: ['jqueryUI'] }
}
			,paths: {
    "_persistState":  "ow.widgets.persistState",
    "bootstrap-clickover":  "../Oaf/SlimHeader/Media/Scripts/bootstrapx-clickover",
    "jquery.fileupload":  "jQuery.FileUpload/jQuery.FileUpload",
    "_extendedUnderscore":  "underscoreExtensions",
    "jqueryUI":  "jquery-ui-1.10.3",
    "touch-punch":  "jquery-ui-touch-punch/jquery.ui.touch-punch",
    "sammy":  "sammy-0.7.4",
    "bootstrap-multiselect-fixed-position":  "bootstrap/bootstrap-multiselect-fixed-position",
    "chosen":  "chosen.jquery",
    "ow.widgets.persistState":  "ow.widgets.persistStateExtension",
    "underscore":  "knockoutifyUnderscore",
    "knockout.mapping":  "knockout.mapping",
    "_jasmine":  "jasmine/jasmine",
    "codeMirror":  "codeMirror/codemirror",
    "jquery":  "jquery-2.0.3",
    "oafSlimHeaderBindToEvents":  "../Oaf/SlimHeader/Media/Scripts/oafSlimHeaderBindToEvents",
    "bootstrap-multiselect":  "bootstrap/bootstrap-multiselect",
    "modernizr":  "modernizr-2.6.2-custom",
    "hammerjs":  "jquery.hammer-full",
    "settingsDropDownBindings":  "../Oaf/SlimHeader/Media/Scripts/settingsDropDownBindings",
    "jasmine-html":  "jasmine/jasmine-html",
    "jqueryAnimateEnhanced":  "jquery.animate-enhanced.min.amd",
    "nvd3":  "nv.d3",
    "knockout":  "knockout-3.2.0.debug",
    "_underscore":  "underscore",
    "boot-jasmine":  "jasmine/boot",
    "d3":  "d3.v3",
    "bootstrap-popover":  "../Oaf/SlimHeader/Media/Scripts/bootstrap-popover",
    "bootstrap-tooltip":  "../Oaf/SlimHeader/Media/Scripts/bootstrap-tooltip",
    "bootstrap":  "bootstrap/bootstrap-3.1.1.min"
}
		});
		requirejs.config(config);
		define('requirejs-config', config);
}()
define('jquery.ui.sortable', ['jqueryUI'], function(ui) { return ui.sortable });
define('jquery.ui.widget', ['jqueryUI'], function(ui) { return ui.widget });

require([
    "jquery",
    "knockout",
    "d3",
    "jqueryUI",
    "jqueryAnimateEnhanced",
    "knockout.mapping",
    "knockoutExtensions",
    "knockout.slideView",
    "d3Extensions",
    "nvd3Extensions",
    "ogre.jquery.css-shims",
    "ogre.widgets",
    "ogre.dialogs",
    "global.debug",
    "changelogBootstrapping",
    "clientsideMigrations",
    "touch-punch",
    "modernizr"
]);
