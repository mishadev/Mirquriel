define(['knockout', 'knockout.mapping', 'apiUrls'],function(ko, mapping, api){
return function usedParameterConfigurationModel(jsModel, slideSetId) {
	var saveParameterConfiguration = _.debounce(saveParameterConfigurationNow,500);
	var _up = mapping.fromJS(jsModel); //_usedParameter
	_up.isMultiSelect = ko.computed(function() { return _up.ParamType() == 'MULTISELECT'});
	_up.canBeOptional = ko.computed(function() { return _up.ParamType() == 'TEXT'});
	_up.canBeStacked = ko.computed(_up.isMultiSelect);
	_up.canSelectAllByDefault = ko.computed(_up.isMultiSelect);
	_up.hasDefaultSelectionConfigured = ko.computed(hasDefaultSelectionConfigured);
	_up.inEditMode = ko.observable(false);
	_up.switchToEditMode = function () { _up.inEditMode(true);	}
	_up.displayName = ko.computed(
		{
			read: function () {
				return _up.OverriddenDisplayName() ? _up.OverriddenDisplayName() : _up.DisplayName();
			},
			write: function (newValue) {
				// empty string = 'delete this override'; for now there isn't a specific 'delete this override' button
				if (newValue === _up.DisplayName() || newValue === '')
					newValue = null;

				_up.OverriddenDisplayName(newValue);
			}
		});
	
	createSubscriptionsOnParameterProperties();
	
	return _up;
	///////////

	function createSubscriptionsOnParameterProperties() {
		_.each(['DisplayInTheTitle', 'HideIfMatchingCommonParamExists', 'IsOptionalParameter', 'IsStackingParameter', 'SelectAllByDefault', 'OverriddenDisplayName'], function (prop, idx, properties) {
			_up[prop].subscribe(function () {
				saveParameterConfiguration(_.pick(_up, properties, 'Id'));
			});
		})
	}

	function saveParameterConfigurationNow() {
		var model = {
			slideSetId: slideSetId,
			parameterId: _up.Id(),
			data: mapping.toJS(_up)
		};
		api.modifyUsedParameter(model).then(function (data) {			
			ko.updateValuesFromJS(_up, data);
			_up.inEditMode(false);
		});
	};

	function hasDefaultSelectionConfigured() {
		return (_up.isMultiSelect() &&  _up.SelectAllByDefault()) || (_up.DefaultSelection() != null && _up.DefaultSelection() != undefined); //x == null means null or undefined
	}
}
})