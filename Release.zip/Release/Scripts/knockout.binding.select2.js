define([
		'knockout',
		'jquery',
		'underscore',
		'select2'
	],
	function (ko, $, _) {
		ko.bindingHandlers.searchselect = {
			init: function(el, valueAccessor, allBindingsAccessor, viewModel) {
				var config = ko.unwrap(valueAccessor());
				var select2Config = makeSelect2Config(config);

				$(el).select2(select2Config);

				ko.utils.domNodeDisposal.addDisposeCallback(el, function() {
					$(el).select2('destroy');
				});
			},

			update: function (el, valueAccessor, allBindingsAccessor, viewModel) {
				var config = ko.unwrap(valueAccessor());
				var allBindings = allBindingsAccessor();

				if ("value" in allBindings)
					updateSelect2Selection(ko.unwrap(allBindings.value), el, config);
				if ("disable" in allBindings)
					$(el).select2('enable', !allBindings.disable());
			}
		};

		function updateSelect2Selection(targetValue, el, config) {
			var currentValue = $(el).select2("data");

			if (config.select2.multiple) {
				//allBindings.value guaranteed to exist in config.options so we should not query new data here
				targetValue = targetValue || '';
				var keys = _.compact(targetValue.split(config.select2.separator));

				if (isEqual(keys, currentValue))
					return;

				//common case
				var selected = _.filter(config.options, function (option) { return _.contains(keys, option.key) });
				$(el).select2("data", selected);
			} else {
				if (isEqual(targetValue, currentValue))
					return;

				var option = _.findBy(config.options, targetValue, 'key');
				$(el).select2("data", option);
			}
		}

		function isEqual(target, current) {
			if (_.isArray(current)) {
				current = _.map(current, mapId).sort();
				target = target.sort();
			}
			else if (_.isObject(current))
				current = current.key;

			//_.isEqual(null, undefined) -> false, so we check (current == target) first
			return current == target || _.isEqual(target, current);
		}

		function makeSelect2Config(config) {
			if (!_.has(config, 'select2')) return;

			return _.defaults(config.select2, {
				id: mapId,
				text: mapText,
				query: makeQueryDelegate(config)
			});
		}

		function mapId(option) {
			if(_.isObject(option) && _.has(option, 'key'))
				return option.key;
		}

		function mapText(option) {
			if(_.isObject(option) && _.has(option, 'desc'))
				return option.desc;
		}

		function makeQueryDelegate(config) {
			if (!ko.isSubscribable(config.options) || !config.optionsQuery) return;

			return _.debounce(function (request) {
				var valueSubscription = config.options.subscribe(function (options) {
					valueSubscription.dispose();

					var results = _.filter(options, function (op) { return ~op.desc.toUpperCase().indexOf(request.term.toUpperCase()) });
					var select2QueryResult = { results: results, more: options.length == config.rowsPerPage };
					request.callback(select2QueryResult);
				});

				config.optionsQuery({
					searchTerm: request.term,
					rowsPerPage: config.rowsPerPage || 100,
					pageNumber: request.page
				});
			}, config.queryQuietMillis || 0);
		}
	});