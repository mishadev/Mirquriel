define(
['jquery', 'underscore', 'jqueryUI', 'ow.widgets.persistState'],

// Using the built-in jquery ui resizable is fine but if you want to allow resizing only in a certain 
// dimension (eg width/height) AND have support for the persistState widget then use these
function ($, _) {
	'use strict'
	
	//Horizontal right resizable only. Use this over just setting the options to enable persistence
	createResizableSubWidget('ogre.eresizable', 'e', ['width']);
	//vertical down resizable only
	createResizableSubWidget('ogre.sresizable', 's', ['height']);

	function createResizableSubWidget(name, handles, dimensions) {
		var  availableDimensions = ['width', 'height']
			,otherDimensions = _.difference(availableDimensions, dimensions)
			,selector = ':'+name.replace('.', '-');
			;
	    $.widget(name, $.ui.resizable, {
	    	 options: { 
	    	 	handles: handles
		    	,resize: function() {
		    		_.each(otherDimensions, function(dimension){
		    			this.css(dimension, 'auto');
		    		}, $(this) );
		    	}
		    }
	    });
		//create persistState hook that only saves the desired dimension
	    $.ow.persistState.elementPersistence[selector] = {
	        saveState: function($el) {
	            return _.reduce(dimensions, addProperty, {});
	            function addProperty(obj, prop) {
	                var value = _.result($el, prop);
	                // attempt to fix weird bug where all widths and heights incorrectly get set to zero sometimes
	                // better to fail to persist when the user has set something to zero,
                    // than to falsely persist an incorrect value of zero
	                if (value) {
	                    obj[prop] = value;
	                }
					return obj;
				}
	        },
	        restoreState: function($el, state) {
	            $el.css( state );
	        }
	    }
	}
});