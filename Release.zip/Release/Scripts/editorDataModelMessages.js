﻿define(
['jquery', 'knockout', 'apiUrls'],
function ($, ko, api) {
	return function () {
		// Simple view-model for the messages section of the "data model actions" page.
		// Gets messages about state of file-system repository for notifications to user

		var messages = ko.observable([]);

		api.getDataSyncStatus().then(messages);

		return {
			messages: messages
		};
	}
});