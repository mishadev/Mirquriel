﻿define([
	'jquery', 'underscore', 'knockout', 'constants'
],
function (
	$, _, ko, constants
) {
	'use strict'
	// Slide resizer. Takes a config object with initial options
	// and give simple api to change size of slide and fit it to element.
	// Use like this: slideResizer({
	//   sizeOptions: _.map(_.range(0, 10), function (x) { return (x + 1) / 10; }),
	//   size: .8
	// });

	return function slideResizer(config) {
		var cfg = _.defaults(config || {}, {
				sizeOptions : _.map(_.range(0, 10), function (x) { return (x + 1) / 10; })
				,size : .8
			})
			, customSizeOption = ko.observable(null)
			, sizeOptions = ko.computed(function() { return  _.union(cfg.sizeOptions, customSizeOption() ? [customSizeOption()] : []).sort(); })
			, size = ko.observable(cfg.size);


		var _resizer = {
			changeSizeToFitElement: changeSizeToFitElement,
			changeOptionToFitElement: changeOptionToFitElement,
			nextSizeOption: ko.computed(_.partial(getSizeOption, 1)),
			prevSizeOption: ko.computed(_.partial(getSizeOption, -1)),
			slideSizeOptions: sizeOptions,
			slideSize: ko.computed({
				read: function() { return size(); },
				write: changeSize
			})
		};
		return _resizer;

		function getSizeOption(mutation) {
			var currentOptionIndex = _.indexOf(sizeOptions(), size());
			if (!~currentOptionIndex)
				return;

			return sizeOptions()[currentOptionIndex + mutation];
		}

		function changeSize(newSize) {
			var isCustomSize = newSize && !_.contains(cfg.sizeOptions, newSize);
			if (isCustomSize)
				customSizeOption(newSize);
			size(newSize);
			if (!isCustomSize)
				customSizeOption(null);
			return size();
		}

		function changeOptionToFitElement(element, paddingPercent) {
			var targetSize = getSizeToFitElement(element, paddingPercent);
			var optionSize = getNearestLessOption(targetSize);

			return _resizer.slideSize(optionSize);
		}

		function changeSizeToFitElement(element, paddingPercent) {
			return _resizer.slideSize(getSizeToFitElement(element, paddingPercent));
		}

		function getSizeToFitElement(element, paddingPercent) {
			if (!_.isElement(element) && !_.isString(element))
				return;
			var $element = $(element),
				height = $element.height(),
				width = $element.width(),
				xScale = width / constants.SLIDE_VIEWBOX_WIDTH,
				yScale = height / constants.SLIDE_VIEWBOX_HEIGHT;

			var padding = +paddingPercent / 100;
			padding = !isNaN(padding) ? padding : 0;
			var newScale = Math.min(yScale, xScale) - padding;
			return Math.max(0.05, newScale); // prevent a Crome crash if the scale too small
		}

		function getNearestLessOption(targetSize) {
			var optionSize = _.chain(sizeOptions()).clone().reverse().find(function (option) { return targetSize >= option; }).value();
			if (_.isUndefined(optionSize))
				optionSize = _.first(sizeOptions);

			return optionSize;
		}
	};
});