define(
['knockout', '_extendedUnderscore'],
function knockoutifyUnderscore(ko, _) {
// Shim underscore functions to transparently unwrap knockout observables. Otherwise things get confusing when 
// you think you are passing an object or an array into _.map but really are passing in a ko function

var unwrap = ko.utils.unwrapObservable;

//These can be shimed in a standard way
var koFriendly = ['map', 'filter', 'any', 'all', 'find', 'each', 'findBy', 'first', 'last', 'head', 'tail', 'union', 'compact', 'flatten', 'unionAll', 'difference', 'without', 'pairs', 'findIndex', 'contains', 'invoke'];
var oldMap = _.map;
for (var _i = 0; _i < koFriendly.length; _i++) {
	(function(fnName) {
		var originalFn = _[fnName];
		_[fnName] = function() {
			var args;
			args = oldMap(arguments, unwrap);
			return originalFn.apply(_, args);
		};
	})(koFriendly[_i]);
}

//These underscore commands need special attention
_.mixin({
	findBy: function (collection, val, prop) {
		val = unwrap(val)
		return _.find(unwrap(collection), function findBy(x) { return x&&(unwrap(x[prop]) === val) });
	},
	where: function(collection, query) {
		query = _.mapObject(query, function(val, key){
			return [key, unwrap(val)]
		});
		return _.filter(collection, function(item){
			return _.all(query, function(queryVal, key) {
				return queryVal === unwrap(item[key]);						
			})
		});
	}
});

return _;
});