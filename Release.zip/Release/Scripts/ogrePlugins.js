﻿/*global define*/
/*jslint unparam: true, vars: true, browser: true, indent: 4, maxerr: 10, maxlen: 100 */
define(
[
     '../OgrePlugins/slideMaster'
	,'../OgrePlugins/editableText'
	,'../OgrePlugins/toolbox'
	,'../OgrePlugins/lineChart'
    ,'../OgrePlugins/pivot'
    ,'../OgrePlugins/simpleTableGrid'
    ,'../OgrePlugins/simpleBarChart'
    ,'../OgrePlugins/preProcessData'
    ,'../OgrePlugins/formatters'
    ,'../OgrePlugins/graphs'
    ,'../OgrePlugins/helpText'
    ,'../OgrePlugins/tableOfContents'
    ,'../OgrePlugins/owColors'
    ,'../OgrePlugins/clientColors'
    ,'../OgrePlugins/slideTemplates'
    ,'../OgrePlugins/graphHelper'
],
function (slideMaster, editableText, toolbox, lineChart, pivot, simpleTableGrid,
    simpleBarChart, preProcessData, formatters, graphs, helpText, tableOfContents, owColors,
    clientColors, slideTemplates, graphHelper) {
    'use strict';
    return {
        slideMaster: slideMaster
        ,editableText: editableText
        ,toolbox: toolbox
        ,lineChart: lineChart
        ,pivot: pivot
        ,simpleTableGrid: simpleTableGrid
        ,simpleBarChart: simpleBarChart
        ,preProcessData: preProcessData
        ,formatters: formatters
        ,graphs: graphs
        ,helpText: helpText
        ,tableOfContents: tableOfContents
        ,owColors: owColors
        ,clientColors: clientColors
        ,slideTemplates: slideTemplates
        ,graphHelper: graphHelper
    };
}
);