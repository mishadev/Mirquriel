define(
    ['jquery', 'knockout', 'underscore', 'knockout.mapping', 'clientStorage', 'knockoutExtensions'],
    function ($, ko, _, mapping, clientStorage) {
    	"use strict";

		// AG: not sure what this is.

        var LINKS = "slideSetsLinks";
        /**
        * Creates an extended ko.observableArray that can handle loading slideSets from the server.
        * The return value of this can be bound to just like any observableArray, and is initially an empty array.
        */
        return function createSlideSets(config) {
            var slideSetLinks = ko.observableArray([]);

            if (!config)
                config = {};

            //TODO - GM - there is really no reason for _slideSets to not be a singleton
            var _slideSets = sortedSlideSets([]);        
            //TODO - GM - we should not be extending SlideSets, we should use more traditional composition
            _slideSets.activeRequests = ko.observable(0);   // tracks number of in progress AJAX requests.
            _slideSets.recentChanges = _.mapObject(['added','removed','modified'], function(k){ 
                                            return [k, ko.observableArray([])] });

            _slideSets.linkPattern = config.linkPattern || linkPattern;

            var cachedLinks = clientStorage.getOnClient(LINKS);
            cachedLinks && updateSlideSetLinks()( cachedLinks );
            
            require(['initializationData/slideSetLinks'], trackRequestProgress(updateSlideSetLinks(_slideSets.recentChanges)) ); //This should load immediately

            return _slideSets;

            /////////////////////////////////////////

            // collects the SlideSets identified by the links in the newSlideSetLinks
            function updateSlideSetLinks(changeTracking) { return function updateSlideSetLinks(newSlideSetLinks) {
                // [ { cached: {}, incoming: {} }, ...]
                var matched = _.map(newSlideSetLinks, function(incoming) { return { incoming: incoming, cached: null } });
                _.each(slideSetLinks, function(cached) {
                    var matchNode = _.find(matched, function(m){ return m.incoming && (cached.href === m.incoming.href) }); //matched gets modified in this for loop so !incoming is possible
                    if(matchNode)   matchNode.cached = cached;
                    else            matched.push({ incoming: null, cached: cached });
                });

                var toRemove =  _.filter(matched, function(m) { return !m.incoming });
                var toAdd =     _.filter(matched, function(m) { return !m.cached });
                var toModify =  _.filter(matched, function(m) { return m.incoming && m.cached && m.incoming.ETag != m.cached.ETag });

                _.each(toRemove, function(m){
                    changeTracking&&changeTracking.removed.push(m.cached);
                    slideSetLinks.remove(m.cached);
                    removeSlideSetFromLink(m.cached);
                });
                _.each(toAdd, function(m){
                    changeTracking&&changeTracking.added.push(m.incoming);
                    slideSetLinks.push(m.incoming);
                    addOrModifySlideSetFromLink(m.incoming);
                });
                _.each(toModify, function(m){
                    changeTracking&&changeTracking.modified.push(m.incoming);
                    slideSetLinks.replace(m.cached, m.incoming);
                    addOrModifySlideSetFromLink(m.incoming);
                });

                clientStorage.storeOnClient(LINKS, slideSetLinks);
            } }

            function removeSlideSetFromLink(link) {
                _slideSets.remove(findByLink(link, { bypassVersionCheck: true }));
                clientStorage.removeOnClient(link.href);
            }
            function addOrModifySlideSetFromLink(link) {
                if(ifPossibleEnsureSlideSetInArray(link))
                    return;
                $.getJSON(link.href).done(trackRequestProgress(function addSlideSet(incomingSlideSet) {
                    orderSlidesInSlideSetUsingOrderingField(incomingSlideSet);
                    addClientSideOnlyFunctions(incomingSlideSet); 

                    var toUpdate = findByLink(link, { bypassVersionCheck: true });
                    if(toUpdate)   _slideSets.replace(toUpdate, incomingSlideSet);
                    else           _slideSets.push( incomingSlideSet );

                    storeSlideSetOnClient(link.href, incomingSlideSet);
                } ));
            }
            //Ensure the slideset for the link (in its most up to date form) is in the _slideSets array. 
            //If this was not possible return false, othewrise return true
            function ifPossibleEnsureSlideSetInArray(link) {
                if( findByLink(link, {bypassCache: true}) ) return true;
                var ss = getCachedSlideSet(link);
                if(ss)
                    return _slideSets.push(ss)||true;
                return false;
            }

            function orderSlidesInSlideSetUsingOrderingField(slideSet) {
                slideSet.Slides = _(slideSet.Slides).sortBy(function (slide) { return slide.Ordering; });
            }

            //For SlideSet objects newly downloaded from the web api, adds any properties to the SlideSet that we want to use locally, here on the client side
            //TODO - GM - the ko.mapping plugin provides a facility for this, maybe we should use it
            function addClientSideOnlyFunctions(slideSet) {
                _.each(slideSet.Slides, function (slide) {
                    slide.isRedrawing   = ko.observable(false);     // gets incremented when a redraw is in progress, so that knockout can show a 'loading' indicator
                    slide.redrawErrors = ko.observable(null);      // for surfaceing redraw errors to the user                       
                });

                // computed observable that returns the number of slides that isRedrawing
                slideSet.isRedrawingCount = ko.computed(function isRedrawingCount() {
                    return _.filter(slideSet.Slides, function(s){ return s.isRedrawing() }).length
                });
                return slideSet;
            }

            //increment activeRequests and return a function that will decrement them when invoked
            function trackRequestProgress(callback) {
                _slideSets.activeRequests(_slideSets.activeRequests() + 1);
                return function() {
                    _slideSets.activeRequests(_slideSets.activeRequests() - 1);
                    callback.apply(this, arguments);
                }
            }

            function withLink(link, bypassVersionCheck) {
                return function(ss) {
                    return ~link.href.indexOf(_slideSets.linkPattern() + ss.SlideSetId) && (bypassVersionCheck || ss.ETag === link.ETag);
                };
            }

            function findByLink(link, op) {
                op = _.defaults(op||{}, {
                     bypassCache: false
                    ,bypassVersionCheck: false
                });
                return _.find(_slideSets, withLink(link, op.bypassVersionCheck)) || ( !op.bypassCache && getCachedSlideSet(link) );

            }
            function getCachedSlideSet(link) {
                var cachedSlideSet = clientStorage.getOnClient(link.href);
                if (!cachedSlideSet) return null;
                if(cachedSlideSet.ETag !== link.ETag) return null;  //the cached slideset is out of date
                return addClientSideOnlyFunctions( cachedSlideSet );
            }

            // a ko.observableArray that will maintain its sort order based on the SlideSetId property
            // this is not a complete implementation and will only update itself if the array length increased
            // and not if a value(s) was spliced. This is good enough for our purposes for now but.
            function sortedSlideSets(initial) {
                initial  || (initial = []);
                var  ss = ko.observableArray(initial)
                    ,prevLength = ss.length;
                ss.subscribe(function(newVals){
                    if(newVals.length <= prevLength)
                        return;                   
                    prevLength = newVals.length;
                    ss.sort(function(a, b){ return a.SlideSetId<b.SlideSetId ? -1 : a.SlideSetId > b.SlideSetId ? 1 : 0 });
                });
                return ss;
            }

            // wrapper around storing slideSets in local storage, so we can choose exactly what and how to cache
            // eg experimenting with not caching the Thumbnail to save space.
            function storeSlideSetOnClient(key, slideSet) {
                var slideSetCopy = $.extend(true, {}, slideSet); // make a copy so we can mess about with it before storing it

                // server should not be sending us anything in the Thumbnail field, but just to be sure, we'll set it to '' here anyway
                _.each(slideSetCopy.Slides, function (slide) {
                    slide.Thumbnail = '';
                });

                clientStorage.storeOnClient(key, slideSetCopy);
            }

            function linkPattern() {
                return '/api/SlideSet/';
            };
    };
    }
);