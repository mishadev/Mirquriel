define(
['knockout', 'jquery', 'underscore', 'jshint', 'jqueryUI', 'ow.widgets.persistState', 'ogre.resizables'],
function(ko, $, _) {

    var  unwrap         = ko.utils.unwrapObservable
        ,pairWith       = function(val) { return function(x) { return [x, val] } }
        ;
    /*
      Base widget that wraps the CodeMirror library, in addition to enabling invocation as a widget
      it sets a default set of useful options.
      
      The following options are mandatory
        boundTo:    the knockout observable to bind to
        mode:       what CodeMirror mode to use

      This widget expects an underlying html structure similar to
        <div id="data-code-editor">
          <h3>Data code</h3>
          <textarea></textarea>
          <div class="code-editor-help">
            <h3>Help</h3>
            <p>Some helper text </p>
          </div>
        </div>
      Where #data-code-editor is applied a version of the codeEditor widget.

      * The textarea will be turned to a CodeMirror editor.
      * The element itself will by default be wrapped in a collapsibleToH3 widget so that the editor itself can be
        collapsed down. The collapsible state will be persisted via persistState
      * If a .code-editor-help area exists within this element it will be made collapsible
        via collapsibleToH3 and persisted

      A number of other useful changes are made.
      * CodeMirror's save function is rewired to also set the bound ko observable and triggers automatically
        on a debounced change event
      * Update the editor on changes to the bound ko observable changes (this does not work out of the box
        since CodeMirror does not poll the original textarea).

      In addition to the standard widget properties, Exposes the following useful methods/properties:
      * save - save current state using editor's rewired save
      * $editor - the original textarea CodeMirror is created on
      * editor - the CodeMirror instance itself

      Raises the following additional events:
      * chante - triggered on any changes (debounced) or invocations of save
    */
    $.widget('ogre.codeEditor', {
        options: {
             gutters:           []
            ,collapsible:       function(el){el.collapsibleToH3().persistState()}
            ,indentUnit:        4
            ,lineNumbers:       true
            ,foldGutter:        true
            ,matchBrackets:     true
            ,indentWithTabs:    false
            ,resizableWidget:   $.fn.sresizable
        }

        ,_create: function() {
            _.ensureHasKeys(this.options, 'mode', 'boundTo');

            this.boundTo = this.options.boundTo;
            this.$editor = $('textarea', this.element).first();

            var op = $.extend({}, {
                gutters: _.union(this.options.gutters, ['CodeMirror-linenumbers', 'CodeMirror-foldgutter'])
            }, _.omit(this.options, 'gutters') );
            this.editor = CodeMirror.fromTextArea(this.$editor[0], op);
            this._configureEditor();

            this._shimSaveTriggersChange();
            this._shimUpdateOnBoundToChanges();

            triggerChange = _.bind(function(){this._trigger('change') }, this);
            this.editor.on('change', _.debounce(triggerChange, 1200));

            if(this.options.collapsible)
                this.options.collapsible(this.element);

            $('.code-editor-help', this.element).collapsibleToH3().persistState();

            this.options.resizableWidget && this.setupResizable();
        }

        ,setupResizable: function() {
            this.options.resizableWidget.call(this.element.find('.CodeMirror'), {
                stop: _.bind(function(e, ui){
                  $(this.editor.getScrollerElement()).height(ui.size.height);
                  this.editor.refresh()
                }, this)
            }).persistState();
        }
        ,save: function() {
            this.editor.save();
        }

        ,_configureEditor: function() {
            this.editor.addKeyMap({ 
                'Shift-Ctrl-Space': _.bind(this.selectCurrentToken, this)
                ,Tab: _.bind(this._insertTab, this)
            });

        }
        ,_insertTab: function () {
            var spaces = new Array(this.editor.getOption("tabSize") + 1).join(" ");
            this.editor.doc.replaceSelection(spaces, "end", "+input");
        }
        ,selectCurrentToken: function() {
            var  cursor   = this.editor.getCursor()
                ,token    = this.editor.getTokenAt( cursor )
                ;
            this.editor.setSelection({line: cursor.line, ch: token.start}, {line: cursor.line, ch: token.end});
        }
        ,_shimSaveTriggersChange: function() {
            var widget = this;
            widget.editor.save = _.wrap(widget.editor.save, function(original){
                original.apply(this, arguments);
                widget.boundTo( this.getValue() );
            });
            widget.editor.on('change', _.bind(widget.editor.save, widget.editor));
        }

        ,_shimUpdateOnBoundToChanges: function() {
            var widget = this;
            function tryUpdateEditor(val){
                val = val || "";
                val = val.replace('\t', '    ');
                if(val != widget.editor.getValue())
                    widget.editor.setValue( val );
            }
            widget.boundTo.subscribe(tryUpdateEditor);
            tryUpdateEditor( widget.boundTo() );
        }
    });

    $.widget('ogre.dataSqlCodeEditor', $.ogre.codeEditor, {
        options: {
            mode:       'sql',
            extraKeys:  { 'Ctrl-Space': 'autocomplete' }
        }
    });

    $.widget('ogre.generatedSqlCodeEditor', $.ogre.codeEditor, {
        options: {
            mode: 'sql',
            extraKeys: { 'Ctrl-Space': 'autocomplete' }
        }
    });

    $.widget('ogre.styleCssCodeEditor', $.ogre.codeEditor, {
        options: {
            mode:       'css',
            extraKeys:  { 'Ctrl-Space': 'autocomplete' }
        }
    });

    /*
      Base widget for editors that do javascript validation.
      Adds an 'errors' gutter to the CodeMirror Ui and the following methods

      * getValidationErrors - perform jsHint validation and return the following object:
                             {
                                errorReport: An html report of all errors
                                erros: [{line: lineNum, reason: "error message"}]
                             }
      * validate - Mark lines containing current validation errors. Return true if validation passed

      Raises the following additonal events:
      * errorreport: A new error report is available. Recieves an argument object {html: "<p>The error report</p>"}
    */
    $.widget('ogre.validatableJsCodeEditor', $.ogre.codeEditor, {
        options: {
             mode:          'javascript'
            ,gutters:       ['error']
            
            ,allowBlank:    false   //should an empty editor pass validation

            ,jsHintPredefs: ['o','ogre','p','params','b','builtins','d','data','t','text','generatedSql','s','slide','d3','_','$','$s','$slide','nv', '__log','exportData']
            ,jsHintOptions: {
            	globalstrict: false    //users won't know about 'use strict'
                ,plusplus:  false	//don't warn users about ++; developers coming from other languages expect it to work    
                ,devel:     true    //console.log is helpful while live editing code in the editor
                ,debug:     true    //allow debugging statement
            	,laxbreak: true		//allow funky line-breaks
				,laxcomma: true		//allow comma-first or comma-last style
				, eqeqeq: false     //allow == for type coercion
            }
        }

        ,_create: function() {
            $.ogre.codeEditor.prototype._create.apply(this, arguments);

            this.jsHintOptions = $.extend( 
                 {}, this.options.jsHintOptions
                ,{predef: _.mapObject( this.options.jsHintPredefs, pairWith(false) )} 
            );

            this.validate();

        }

        ,validate: function () {

            //clear validation errors ui
            this.editor.clearGutter('error');
            this._eachLine( _.bind(function(line) {
                this.editor.removeLineClass(line, 'wrap', 'errorLine');
            }, this) );

            var errs = this.getValidationErrors();
            if( !_.any(errs.errors) ) {
                this._errorReport(null);
                return true;                
            }

            _.each(errs.errors, function(e){
                var  line = e.line - 1
                    ,$error     = $('<span>',{title: e.reason, 'class': 'error-marker'}).html("●")
                    ;
                this.editor.setGutterMarker(line, 'error', $error[0]);
                this.editor.addLineClass(line, 'wrap', 'errorLine');                    
            }, this);

            this._errorReport(errs.report);
            return false;
        }

        ,_eachLine: function(fn) {
            _.each(_.range(this.editor.lineCount()), fn);
        }
        ,getValidationErrors: function() {
            var  code           = this.editor.getValue()
                , isValid = JSHINT(code, this.jsHintOptions);

            if (!isValid) {
            	var errorReport = [];
            	_.each(JSHINT.errors, function (e) {
            		errorReport.push("Line: " + e.line + " Character " + e.character + "<br/>" + e.reason);
            	});

            	return {
            		report: errorReport.join("<br/>")
                    , errors: _.compact(JSHINT.errors)
            	};
            }
            if(!code && !this.options.allowBlank) {
                var r = "Blank text is not allowed";
                return {
                     report: ('<b>'+r+'</b>')
                    ,errors: [{line: 1, reason: r}]
                };                    
            }

            return { };
        }

        ,_errorReport: function(val) {
            this._trigger('errorreport', null, {html: val} );
        }


    });

    /*
      jSON code editor. Builds on top of $.ogore.validatableJsCodeEditor to run.
      Will validate on all changes
      Will additionally try to JSON.parse the text and generate a validation error on exception.
    */
    $.widget('ogre.jsonCodeEditor', $.ogre.validatableJsCodeEditor, {
        options: {
             mode:          'javascript'
            ,json:          true
            ,allowBlank:    false
        }

        ,_create: function() {
            $.ogre.validatableJsCodeEditor.prototype._create.apply(this, arguments);

            this.$editor.on('jsoncodeeditorchange', _.bind(this.validate, this))
        }
       ,getValidationErrors: function() {
            var errs = $.ogre.validatableJsCodeEditor.prototype.getValidationErrors.apply(this, arguments);
            if(_.any(errs.errors))
                return errs;
            try {
                JSON.parse(this.editor.getValue());
            } catch(e) {
                _log("JSON parsing error", e);
                var r = "Cannot parse JSON: " + e.message;
                return {
                     report: ('<b>'+r+'</b>')
                    ,errors: [{line: 1, reason: r}]
                };
            }
            return {};
        } 
    });

    /*
      Javascript code editor. Builds on top of $.ogre.validatableJsCodeEditor to run.
      Will validate on all changes
      Adds code completion 
    */
    $.widget('ogre.layoutJsCodeEditor', $.ogre.validatableJsCodeEditor, {
        options: {
             mode:          'javascript'
            ,gutters:       ['error']
            ,allowBlank:    true
        }

        ,_create: function() {
            $.ogre.validatableJsCodeEditor.prototype._create.apply(this, arguments);

            this.$editor.on('layoutjscodeeditorchange', _.bind(this.validate, this))
            this.editor.addKeyMap({ 
                'Ctrl-Space': "autocomplete"
                , 'Alt-N': _.runWhen(cursorOnNumber, draggableNumber)
            });
        }
    });

    // Create draggable numbers ala Bret Victor's Tangle.js, http://worrydream.com/LearnableProgramming/
    // This is all still very alpha and experimental. It works but we don't have much impetus to develop
    // it much farther at the moment.
    $.widget('ogre.draggableNumber', {
      _create: function() {
        this.num = this.options.value;

        this.element.addClass('ogre-draggable-number');
        //min/max is too simple http://programmers.stackexchange.com/questions/186983/algorithm-for-picking-reasonable-min-max-vals-given-a-single-value
        this.$slider = $('<input>',{'type': 'range', min: (this.num/10), max: (this.num *5) }).appendTo(this.element)
                        .val(this.num)
                        .css({position: 'relative', top: '-2em', left: '-5em', 'z-index': 1000})
                        .on('change', _.bind(this._change, this));
      }
      ,_change: function() {
        this._trigger('change', null, {value: this.$slider.val() });
      }
    });

    function tokenPos(cm) {
      var pos = cm.getCursor(), token = pos && cm.getTokenAt(pos);
      return pos && token && { pos: pos, token: token };
    }
    function cursorOnNumber(cm) {
      var x = tokenPos(cm);
      return x && x.token.type === 'number';
    }
    function draggableNumber(cm) {
      var  initial      = tokenPos(cm)
          ,initialNum   = parseFloat(initial.token.string, 10)
          ,$slider      = $('<div>').draggableNumber({
                             value: initialNum
                            ,change: function(e, arg) {
                              var x = tokenPos(cm);
                              cm.setSelection({line: x.pos.line, ch: x.token.start}, {line: x.pos.line, ch: x.token.end-1});
                              cm.replaceSelection(arg.value);
                            }
                          })
          ;
      $(':ogre-draggableNumber').remove();
      cm.addWidget(initial.pos, $slider[0], true)
    }
})