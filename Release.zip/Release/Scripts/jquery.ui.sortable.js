define([], function(){
	//This module is defined explicitly and excluded from r.js optimization this file is a placeholder to deal
	//with this issue: https://groups.google.com/forum/#!topic/requirejs/EA3AuCn9y-U
})