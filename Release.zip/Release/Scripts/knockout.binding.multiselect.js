define([
	'knockout',
	'jquery',
	'underscore',
	'bootstrap-multiselect-fixed-position'
],
function (ko, $, _) {
	var unwrap = ko.unwrap;

	// Binding for bootstrap-multiselect plugin for <select multiple="multiple"></select>
	// using knockout observables and jquery callback for two way bindings
	// Usage:
	//	<select multiple="multiple" data-bind="
	//	disable: missingPrereqs
	//	,options: evaluatedValues
	//	,optionsText: 'desc'
	//	,optionsValue: 'key'
	//	,selectedOptions: selectedOptions
	//	multiselect: { includeSelectAllOption: true, enableFiltering: true //note multiselect should be last to avoid concurrency issues
	//	nSelectedTextTemplate: "Template for custom button text evaluator for 'N Selected' text. Example: {{selectedCount}} super puper items selected"} 
	//	"></select>
	ko.bindingHandlers.multiselect = {
		init: function (element, valueAccessor, allBindingsAccessor, viewModel, bindingContext) {
			var config = unwrap(valueAccessor());
			//Adds buttonText avaluator if config has nSelectedTextTemplate property defined
			config.buttonText = getButtonTextEvaluator(config);

			ensureMultiselectInited(element, config);
		},

		update: function (element, valueAccessor, allBindingsAccessor, viewModel, bindingContext) {
			var selectedOptions = allBindingsAccessor().selectedOptions,
				options = allBindingsAccessor().options,
				multiselect = $(element).data('multiselect'),
				optionsValue = allBindingsAccessor().optionsValue || 'key',
				disable = allBindingsAccessor().disable;

			if (ko.unwrap(disable)) {
				deselectAll(multiselect);
				multiselect.refresh();
				return multiselect.disable();
			}
			multiselect.enable();

			var jsOptions = _.pluck(options(), optionsValue),
				domOptions = _.without(_.pluck(multiselect.$ul.find('li input'), 'value'), multiselect.options.selectAllValue);

			// if the new options are different from what's in the DOM, rebuild the widget
			var jsOptionsNotInTheDom = _.difference(jsOptions, domOptions).length;
			var domOptionsNotInTheJs = _.difference(domOptions, jsOptions).length;
			if (jsOptionsNotInTheDom || domOptionsNotInTheJs)
				multiselect.rebuild();

			deselectAll(multiselect);
			if (selectedOptions().length)
				multiselect.select(selectedOptions());
			multiselect.refresh();
		}
	};

	function deselectAll(multiselect) {
		var selected = multiselect.$select.find(':selected');
		if (selected.length)
			multiselect.deselect(_.pluck(selected, 'value'));
	}

	//When nSelectedTextTemplate specified will return function for button text evaluation
	//There are 3 cases selectedOptions.length == 0, > numberDisplayed, other.
	function getButtonTextEvaluator(config) {
		if (!config.nSelectedTextTemplate)
			return;
		return function evaluateButtonText(selectedOptions) {
			var buttonText = "";
			if (selectedOptions.length == 0)
				buttonText = config.nonSelectedText;
			else
				if (selectedOptions.length > this.numberDisplayed)
					buttonText = _.template(config.nSelectedTextTemplate)({ selectedCount: selectedOptions.length });
				else
				    buttonText = _.pluck(selectedOptions, 'textContent').join(', ');

			return "<div>" + buttonText + ' </div><b class="caret"></b>';
		}
	}

	function ensureMultiselectInited(element, config) {
		if (_.isUndefined($(element).data('multiselect')))
			$(element).multiselect(config);
	}
});