define(
['knockout', 'jquery', 'ogrePlugins', 'apiUrls', 'd3', 'underscore', 'nvd3', 'constants', 'slideRenderingUtils', 'knockout.mapping', 'requirejs-config', 'handlebars', 'text!/Content/slideView.template.html', 'browserSupportVariables'],
function (ko, $, ogrePlugins, api, d3, _, nvd3, constants, renderingUtils, mapping, requireJsConfig, handlebars, slideViewTemplate) {
	'use strict';

	/*  Render slides to a DOM element on the page. 
     *  Takes a slide definition that is composed of
     *  * Data code - usually PL/SQL containing a parameterized query that will be run 
     *    to retrieve data displayed in the slide
     *  * Layout code - javascript to draw a slide from the incoming data
     *  * Style code - css stylesheet for the slide document
     *
     *  Once parameters for the data query are selected it will be run and the provided
     *  code will be used to draw the slide in a target iframe.
     *  Queries for data are cached globally by slide,parameters for some time (see code for period)
     *  
     *  Usage:
     *  redraw(params) - set parameters to be used for the data query, fire the query to
     *    retrieve data. Draw the slide with the results. Returns a jquery Deferred object
     *    that will resolve when drawing is finished or fail on any error. If parameters 
     *    are not provided the results of the last data query will be used. This is the only 
     *    function you will need 90% of the time. This function is automatically debounced.
     *  redrawNow(params) - A non-debounced version of redraw. Use sparingly if at all, its easy to thrash the DOM and
     *    kill performance with this
     *  setState(data, [params]) - manually set data rather than fetch it from the server. Useful for 
     *    stubbing data while editing slides. Follow by a call to redraw() with no parameters.
     *  events.dataUpdate - $.Callbacks event queue that triggers any time the data backing the slide has been updated
     *  events.dataRetrieved - $.Callbacks event queue that triggers any time the renderer has retrieved new data. This is the unfiltered data and could contain errors, multiple parameters, and partial successes
     *  getHtml - get currently rendered html as a string. Useful for taking snapshots.
     */

	handlebars.registerHelper('json', function (x) { return JSON.stringify(x) });

	var unwrap = ko.utils.unwrapObservable
        , sourceCounter = 0 //used for placing a sourceUrl marker
	;
	return function slideRenderer(config) {
		var slideDefinition = config.slide 
			, slideSetDefinition = config.slideSet
            , editorMode = !!config.editorMode   // Some plugins may use this, eg the drilldown plugin
            , params = null
            , selector = config.selector
            , builtins = builtinVariables(config)

            , gettingData = null                  //jq deferred for getting chart data

            , iframe = initIframe(getIframe)
			, goToSlideWithIdCallback = config.goToSlideWithIdCallback
		;



		var querySlideData = (editorMode) ? querySlideDataNow : _.memoizeForDuration(querySlideDataNow, 3 * 60 * 1000, koToJsonArguments); //cache queries for 3 minutes, BUT not in editor mode as other things may be changing (eg SqlCode or SPROC on the server)

		_.extend(slideDefinition, {
			isRedrawing: ko.observable(0)
            , redrawErrors: ko.observable("")
		});

		var _renderer = {
              redrawNow: redrawNow
		    , redraw: _.debounce(redrawNow, 1000, true)
            , events: { dataUpdate: $.Callbacks(), dataRetrieved: $.Callbacks() }
            , setState: setStateManually
            , getHtml: getHtml
		};

		var previousRedraw;


		if (config.params)
			_renderer.redraw(config.params);

		return _renderer;

		///////////////////////////////////////////////////////////////////
		function redrawNow(x) {
            // Note:  
			// While testing, we discovered requirejs timeout issues.  It turned out to be sort of a timing condition.
            //
		    // If a redraw started getting data and another redraw request was issued before the first redraw is finished, 
		    // requirejs timeouts occur when the second request starts to overwrite the iframe of the first previous request.
            // So, we added checks to wait for the previous redraw instance to complete before initiating the next one.

		    // BTW, this was observed in chrome but not in Firefox nor IE.  It's not clear that the issue does not exist in other browsers,
		    // It's not conclusive that the behavior is defined in this case as it possible with larger slide data requests failures would 
		    // occur in all browsers.

		    if (previousRedraw && previousRedraw.state() === 'pending') {
		        return previousRedraw.then(function () {
		            return redrawNow(x);
		        });
            }
		    slideDefinition.isRedrawing(slideDefinition.isRedrawing() + 1);
		    slideDefinition.redrawErrors("");
		    if (x && x.params)
		        gettingData = updateSqlData(x.params);

		    var drawingPreqs = $.when(gettingData, iframeBodyIsReady(iframe));

		    previousRedraw = drawingPreqs.then(function redraw(slideData) {
		        return userDefinedRedraw(slideData);
		    }).promise()
            .fail(function (err) {
            	console.error(_.compact(_.pluck(arguments, 'message')), arguments);
            	err.stack && console.log(err.stack);
            	if (slideDefinition.redrawErrors) slideDefinition.redrawErrors(err);
            })
            .always(function () {
            	slideDefinition.isRedrawing(slideDefinition.isRedrawing() - 1);
            });
		    return previousRedraw;
		}

		///////////////////////////////////////////////////////////////////
		function getHtml() {
			return iframe().node().innerHTML;
		}
		function resetHtml() {
			$(iframe().node()).empty()
		}

		///////////////////////////////////////////////////////////////////
		function updateSqlData(newParams) {
			if (newParams)
				params = newParams;
			return querySlideData(unwrap(slideSetDefinition.SlideSetId), unwrap(slideDefinition.SlideId), params, editorMode) // query is for whatever SqlCode is on the server so we don't need to send anything but the slideId
                    .done(_.bind(_renderer.events.dataRetrieved.fire, _renderer.events.dataRetrieved))
                    .then(selectFirstDatum)
                    .then(checkError)
                    .done(function (newData) {
                    	_renderer.events.dataUpdate.fire(newData, false);
                    });
		}
		function selectFirstDatum(data) {
			return $.Deferred(function (d) {
				var datum = _.isArray(data) ? _.first(data) : data;
				if (!datum)
					d.reject("Unknown data error: " + JSON.stringify(data));
				d.resolve(datum);
			})
		}
		function checkError(item) {
			return $.Deferred(function (d) {
				var err = item.error;
				if (err)
					return d.reject((err.type ? err.type + ": " : "") + err.message);
				d.resolve(item);
			})
		}

		function setStateManually(x) {
			if (x.parameters)
				params = x.parameters;
			if (x.data) {
				gettingData = $.when(x).then(selectFirstDatum).then(checkError);
				_renderer.events.dataUpdate.fire(x.data, true);
			}
		}

		//////////////////////////////////////////////////////////////////////////////////

		function userDefinedRedraw(slideData) {
		    var slideParams = slideData.parameters
                , data = _.deepClone(slideData.data) //since this is being passed in, ensure the original data is not modified
		    ;

		    var text = (data.text ? transposeDictionary(data.text) : {}); //TODO - GM - should be Object.freeze'd but some slides modify this variable. 
																		  // AG: there's a good reason for this: by projecting the dictionary to only include the selected language,
																		  // the references in layout-code to the dictionary become simpler: text.hello rather than text[language].hello

		    slideDefinition.exportData = _.without(data, 'text');
		    var frame = getIframe()[0]
                , doc = renderingUtils.documentOf(frame)
                , redrawing = $.Deferred()
		    ;
		    var html = handlebars.compile(slideViewTemplate)({
		        slideDefinition: mapping.toJS(slideDefinition)
                , index: _.uniqueId()
                , requireJsConfig: requireJsConfig
                , constants: constants
                , params: params
                , builtins: builtins
                , editorMode: editorMode
                , includedStyles: [
                    '/Styles/slideMixin.css',
                    '/Styles/Client/clientSlideStyles.css',
                    '/Content/nv.d3.css'
                ]
		    });
		    try {
		        doc.open();
		        frame.contentWindow.__slideRendering = {
		            redrawing: redrawing
                    , text: text
                    , data: data
		        };

		        doc.write(html);
		        doc.close();
		    } catch (e) {
		        redrawing.reject({
		            message: e.message
                    , error: e
		        });
		    }
		    return frame.contentWindow.__slideRendering.redrawing;
		}


		function getLayoutCodeString() {                        //any massaging that needs to be done to layout code
			return unwrap(slideDefinition.LayoutCode)
                    + '\n//@ sourceURL=layoutCode' + (sourceCounter++) + '.js'   //token to name script so it can be debugged in chrome devtools
			;
		}

		function transposeDictionary(rawDictionaryData) {
			// converts [{TextKey: 'casual_greeting', LanguageKey: 'en', LocalizedTextValue: 'hello'}, {TextKey: 'casual_greeting', LanguageKey: 'fr', LocalizedTextValue: 'bonjour'}]
			// to       {casualGreeting: { en: 'hello', fr: 'bonjour'}}
			var dictionary = _.groupBy(rawDictionaryData, function (entry) { return entry.TextKey; });
			_.each(dictionary, function (arr, key) {
				dictionary[key] = {};
				_.each(arr, function (x) {
					dictionary[key][x.LanguageKey] = x.LocalizedTextValue;
				});
			});
			return dictionary;
		}

		///////////////////////////////////////////////////////////////////

		function iframeBodyIsReady() {
			//Firefox will not give the iframe a body immediately. Poll until it is loaded
			return _.poll({
				until: function () { return !!renderingUtils.documentOf(getIframe()).body }
			}).done(function () {
				var doc = renderingUtils.documentOf(getIframe());
				doc.open();     //without this firefox will draw your results and then disappear them
				doc.close();
			});
		}

		function getIframe() {
			return $(_.isFunction(selector) ? selector(builtins) : selector);
		}
	};

	///////////////////////////////////////////////////////////////////
	// Initialize the iframe to seamless mode and set up any properties
	function initIframe(getIframe) {
		var $iframe = getIframe();
		if (!$iframe.is('iframe'))
			throw "Slide renderer target must be an iframe";
		renderingUtils.configureSeamlessIframe($iframe);
		return function getD3Body() {
			var body = renderingUtils.documentOf(getIframe()).body
			//Because knockout redraws elements inside a 'with' block we can't just initialize
			//it and be done with it as the body might be recreated so do a check each time
			renderingUtils.configureContentBody(body);
			return d3.select(body);
		};
	}

	///////////////////////////////////////////////////////////////////

	function builtinVariables(config) {
	    return Object.freeze({
			pageNumber: unwrap(config.pagenum) || 1
		   , userName: "Stephen Dedalus"

		   , slideAssetsPath: ow.appPath + "SlideAssets/"

			// Printable area of paper size, 1/100 of inch, from PPT OW templates (10.5x7.5 inches)
			, pageWidth: constants.SLIDE_VIEWBOX_WIDTH
			, pageHeight: constants.SLIDE_VIEWBOX_HEIGHT

		});
	}

	///////////////////////////////////////////////////////////////////

	function querySlideDataNow(slideSetId, slideId, params, editorMode) {
		//TODO - GM - technically, its possible for this to fire out of order and to recieve an out of date query but 
		//with the actual call to this being debounced it seems very unlikely and not terribly harmful
		return api.getSlideData({ slideSetId: slideSetId, slideId: slideId, includeLocalization: editorMode }, params);
	}

	///////////////////////////////////////////////////////////////////

	//Wrap a function in a try..catch. Return a deferred with corresponding state
	function tryDeferred(fn) {
		return $.Deferred(function tryDeferred(d) {
			try {
				d.resolve(fn(d));
			}
			catch (err) {
				if (err instanceof SyntaxError) {
					debugger;
					return d.reject("Syntax Error possibly caused by: \n" + arguments[0], err, arguments, this);
				}
				d.reject(err);
			}
		});
	}

	function koToJsonArguments() {
		return ko.toJSON(_.toArray(arguments));
	}

	function fn(val) { return function () { return val; } }
});
