﻿define(['jquery', 'knockout', 'underscore', 'apiUrls', 'domready', 'jqueryUI'], function ($, ko, _, apiUrls) {
	'use strict'
	
	var _roleManagement = {
		addUser: function () {
			apiUrls.addUser(_roleManagement.username())
				.then(function (data) {
					_roleManagement.username(null);
					refreshIframes($(".add-user-iframe"));
				});
		},
		username: ko.observable(null)
	}

	ko.applyBindings(_roleManagement, document.getElementById('main'));

	$("#tabs").tabs({
		activate: function (event, ui) {
			// when a new tab is displayed, we must refresh the iframe in it for SlickGrid to calculate its dimensions
			$(ui.oldPanel).find('iframe').hide();
			refreshAndShowIframes($(ui.newPanel).find('iframe'));
		}
	});

	var activeTabIframe = $("#tabs div.ui-tabs-panel[aria-hidden='false']").find('iframe'); 
	activeTabIframe.hide();
	refreshAndShowIframes(activeTabIframe);

	return _roleManagement;

	function refreshAndShowIframes(iframes) {
		refreshIframes(iframes);
		iframes.load(function() { iframes.show(); });
	}

	function refreshIframes(iframes) {
		_.each(iframes, function (iframe) {
			var iframeSrc = $(iframe).attr('src');
			// this looks weird, but works cross-browser, see http://stackoverflow.com/a/86771/941238
			$(iframe).attr('src', iframeSrc);
		});		
	}
});