﻿(function() {
  define(['jasmine', 'Squire', 'underscore', 'knockout', 'jquery', 'knockout.mapping'], function(jasmine, Squire, _, ko, $, mapping) {
    var checkPrerequisitesFor, correctSqlResult, getParameterMock, parameterId, returnFailedResultOngetParametersOptions, setErrorOnGetParametersOptions, sqlParameters, stubs;
    stubs = {
      parameters: ko.observableArray([
        {
          Id: 1,
          Name: ko.observable('p1'),
          ParamType: ko.observable('SELECT'),
          EvaluationType: ko.observable('SQL'),
          EvaluationSource: ko.observable('SELECT 1'),
          IsOptionalParameter: true,
          userSelection: ko.observable(null)
        }, {
          Id: 2,
          Name: ko.observable('p2'),
          ParamType: ko.observable('SELECT'),
          EvaluationType: ko.observable('JSON'),
          EvaluationSource: ko.observable('[{ "key": "1", "desc":"1"}, { "key": "2", "desc":"2"}]'),
          userSelection: ko.observable({
            key: '1',
            desc: '1'
          })
        }, {
          Id: 3,
          Name: ko.observable('p3'),
          ParamType: ko.observable('SELECT'),
          EvaluationType: ko.observable('SQL'),
          EvaluationSource: ko.observable('SELECT @p1, @p2'),
          IsOptionalParameter: true,
          userSelection: ko.observable(null)
        }, {
          Id: 4,
          Name: ko.observable('p4'),
          ParamType: ko.observable('SELECT'),
          EvaluationType: ko.observable('SQL'),
          EvaluationSource: ko.observable('SELECT @p1, @p3'),
          userSelection: ko.observable(null)
        }, {
          Id: 5,
          Name: ko.observable('p5'),
          ParamType: ko.observable('TEXT'),
          EvaluationType: ko.observable('NONE'),
          EvaluationSource: ko.observable(null),
          userSelection: ko.observable('A')
        }
      ]),
      additionalParameters: ko.observableArray([
        {
          Name: ko.observable('a1'),
          ParamType: ko.observable('SELECT'),
          EvaluationType: ko.observable('SQL'),
          EvaluationSource: ko.observable('SELECT 1'),
          IsOptionalParameter: false,
          userSelection: ko.observable(null),
          hasSelection: function() {
            return false;
          }
        }, {
          Name: ko.observable('a2'),
          ParamType: ko.observable('SELECT'),
          EvaluationType: ko.observable('SQL'),
          EvaluationSource: ko.observable('SELECT 1'),
          IsOptionalParameter: false,
          userSelection: ko.observable({
            key: '1',
            desc: '1'
          }),
          hasSelection: function() {
            return true;
          }
        }
      ]),
      allSelections: {
        p1: null,
        p2: '1',
        p3: null,
        p4: null,
        p5: 'A',
        a1: null,
        a2: '1'
      }
    };
    _.each(stubs.parameters, function(p) {
      p.missingPrereqs = ko.observable(false);
      p.evaluationErrorMessage = ko.observable(void 0);
      p.loading = ko.observable(false);
      p.clearUserSelection = function() {};
      p.clearEvaluatedValues = function() {};
      p.setEvaluatedValues = function() {};
      p.setUserSelectionOrFallbackToDefaultValue = function() {};
      p.hasSelection = function() {
        return p.IsOptionalParameter || !!p.userSelection();
      };
      p.evaluated = ko.observable(false);
      return p.createSpecificSelections = _.identity;
    });
    sqlParameters = _.filter(stubs.parameters, function(p) {
      return p.EvaluationType() === 'SQL';
    });
    parameterId = 'magicNumber';
    correctSqlResult = 'Correct Result';
    setErrorOnGetParametersOptions = false;
    returnFailedResultOngetParametersOptions = false;
    getParameterMock = function(paramType, evaluationType, evaluationSource) {
      return {
        Id: parameterId,
        ParamType: ko.observable(paramType),
        EvaluationType: ko.observable(evaluationType),
        EvaluationSource: ko.observable(evaluationSource),
        systemParameters: ['username'],
        createSpecificSelections: _.identity
      };
    };
    checkPrerequisitesFor = function(parameter, expected, additionalMessage, apiSpy) {
      return it("for " + parameter.ParamType() + " parameter with " + parameter.EvaluationType() + " evaluation type " + (additionalMessage || ""), function() {
        return (expect(this.parametersEvaluator.getNamesOfPrerequisiteParameters(parameter))).toEqual(expected);
      });
    };
    return describe("Is Parameters Evaluator", function() {
      beforeEach(function(next) {
        this.mocks = {
          api: {
            getParameterOptions: function() {
              var deferred, result;
              deferred = $.Deferred();
              if (returnFailedResultOngetParametersOptions) {
                _.defer(function() {
                  return deferred.reject({
                    message: "Error message"
                  });
                });
              } else {
                result = setErrorOnGetParametersOptions ? {
                  Error: {
                    Message: "Error Message"
                  }
                } : {
                  Result: correctSqlResult
                };
                _.defer(function() {
                  return deferred.resolve(result);
                });
              }
              return deferred;
            }
          },
          selectionsEvaluator: {
            getAllSelections: function() {
              return stubs.allSelections;
            }
          }
        };
        _.visitObject(this.mocks, (function(_this) {
          return function(val, name, parent) {
            if (_.isFunction(val)) {
              return (spyOn(parent, name)).and.callThrough();
            }
          };
        })(this));
        this.injector = new Squire().mock(this.mocks);
        return this.injector.require(['parameters/parametersEvaluator'], (function(_this) {
          return function(evaluator) {
            _this.parametersEvaluator = evaluator(stubs.parameters, stubs.additionalParameters, _this.mocks.api, _this.mocks.selectionsEvaluator);
            return next();
          };
        })(this));
      });
      describe("correctly calculates prerequisites", function() {
        checkPrerequisitesFor(getParameterMock('TEXT', 'NONE', null), []);
        checkPrerequisitesFor(getParameterMock('TEXT', 'SQL', null), []);
        checkPrerequisitesFor(getParameterMock('TEXT', 'JSON', null), []);
        checkPrerequisitesFor(getParameterMock('SELECT', 'NONE', null), []);
        checkPrerequisitesFor(getParameterMock('SELECT', 'JSON', null), []);
        checkPrerequisitesFor(getParameterMock('SELECT', 'SQL', '@p1, @p2, @p3'), ['p1', 'p2', 'p3'], 'get multiple prerequisites');
        checkPrerequisitesFor(getParameterMock('SELECT', 'SQL', '@p1'), ['p1'], 'get single prerequisite');
        checkPrerequisitesFor(getParameterMock('SELECT', 'SQL', '@p1, @p1'), ['p1'], 'does not contains duplicates');
        checkPrerequisitesFor(getParameterMock('SELECT', 'SQL', '@p1, @userName'), ['p1'], 'ignores userName');
        checkPrerequisitesFor(getParameterMock('CHECKBOX', 'NONE', null), []);
        checkPrerequisitesFor(getParameterMock('CHECKBOX', 'JSON', null), []);
        checkPrerequisitesFor(getParameterMock('CHECKBOX', 'SQL', '@p1, @p2, @p3'), ['p1', 'p2', 'p3'], 'get multiple prerequisites');
        checkPrerequisitesFor(getParameterMock('CHECKBOX', 'SQL', '@p1'), ['p1'], 'get single prerequisite');
        checkPrerequisitesFor(getParameterMock('CHECKBOX', 'SQL', '@p1, @p1'), ['p1'], 'does not contains duplicates');
        checkPrerequisitesFor(getParameterMock('CHECKBOX', 'SQL', '@p1, @userName'), ['p1'], 'ignores userName');
        checkPrerequisitesFor(getParameterMock('MULTISELECT', 'NONE', null), []);
        checkPrerequisitesFor(getParameterMock('MULTISELECT', 'JSON', null), []);
        checkPrerequisitesFor(getParameterMock('MULTISELECT', 'SQL', '@p1, @p2, @p3'), ['p1', 'p2', 'p3'], 'get multiple prerequisites');
        checkPrerequisitesFor(getParameterMock('MULTISELECT', 'SQL', '@p1'), ['p1'], 'get single prerequisite');
        checkPrerequisitesFor(getParameterMock('MULTISELECT', 'SQL', '@p1, @p1'), ['p1'], 'does not contains duplicates');
        return checkPrerequisitesFor(getParameterMock('MULTISELECT', 'SQL', '@p1, @userName'), ['p1'], 'ignores userName');
      });
      describe("when check is prerequisites ready", function() {
        it("correctly check ready prerequisites", function() {
          return expect(this.parametersEvaluator.isPrerequisitesReady(getParameterMock('SELECT', 'SQL', '@p2, @p5'))).toBeTruthy();
        });
        it("correctly check ready prerequisites with additional parameters", function() {
          return expect(this.parametersEvaluator.isPrerequisitesReady(getParameterMock('SELECT', 'SQL', '@p2, @p5, @a2'))).toBeTruthy();
        });
        it("correctly check not ready prerequisites", function() {
          return expect(this.parametersEvaluator.isPrerequisitesReady(getParameterMock('SELECT', 'SQL', '@p4, @p3'))).toBeFalsy();
        });
        it("correctly check not ready additional prerequisites", function() {
          return expect(this.parametersEvaluator.isPrerequisitesReady(getParameterMock('SELECT', 'SQL', '@a1'))).toBeFalsy();
        });
        it("ignores optional parameters", function() {
          return expect(this.parametersEvaluator.isPrerequisitesReady(getParameterMock('SELECT', 'SQL', '@p1, @p2'))).toBeTruthy();
        });
        return it("does not ignores not optional parameters", function() {
          return expect(this.parametersEvaluator.isPrerequisitesReady(getParameterMock('SELECT', 'SQL', '@p1, @p3, @p4'))).toBeFalsy();
        });
      });
      describe('evaluation of', function() {
        describe('JSON', function() {
          describe('for CORRECT evaluation source has', function() {
            beforeEach(function(next) {
              var valueDeferred;
              valueDeferred = this.parametersEvaluator.evaluate(getParameterMock('SELECT', 'JSON', '[{ "key": "1", "desc":"1"}, { "key": "2", "desc":"2"}]'));
              this.value = void 0;
              return valueDeferred.done((function(_this) {
                return function(v) {
                  _this.value = v;
                  return next();
                };
              })(this));
            });
            it("no error", function() {
              return expect(this.value.isError).toBeFalsy();
            });
            it("no error message", function() {
              return expect(this.value.errorMessage).toBeUndefined();
            });
            return it("expected result", function() {
              return expect(this.value.result).toEqual([
                {
                  key: '1',
                  desc: '1'
                }, {
                  key: '2',
                  desc: '2'
                }
              ]);
            });
          });
          return describe('for INCORRECT evaluation source has', function() {
            beforeEach(function(next) {
              var valueDeferred;
              valueDeferred = this.parametersEvaluator.evaluate(getParameterMock('SELECT', 'JSON', '[ "key": "1", "desc":"1"}, { "key": "2", "desc":"2"}]'));
              this.value = void 0;
              return valueDeferred.done((function(_this) {
                return function(v) {
                  _this.value = v;
                  return next();
                };
              })(this));
            });
            it("error", function() {
              return expect(this.value.isError).toBeTruthy();
            });
            it("error message", function() {
              return expect(!!this.value.errorMessage).toBeTruthy();
            });
            return it("no expected result", function() {
              return expect(this.value.result).toBeUndefined();
            });
          });
        });
        return describe('SQL', function() {
          describe('for CORRECT result has', function() {
            beforeEach(function(next) {
              var valueDeferred;
              setErrorOnGetParametersOptions = false;
              returnFailedResultOngetParametersOptions = false;
              this.mocks.api.getParameterOptions.calls.reset();
              this.mockedParameter = getParameterMock('SELECT', 'SQL');
              valueDeferred = this.parametersEvaluator.evaluate(this.mockedParameter);
              this.value = void 0;
              return valueDeferred.done((function(_this) {
                return function(v) {
                  _this.value = v;
                  return next();
                };
              })(this));
            });
            it("no error", function() {
              return expect(this.value.isError).toBeFalsy();
            });
            it("no error message", function() {
              return expect(this.value.errorMessage).toBeUndefined();
            });
            it("calls getParameterOptions once", function() {
              return expect(this.mocks.api.getParameterOptions.calls.count()).toBe(1);
            });
            it("calls getParameterOptions with parameterId", function() {
              return expect(this.mocks.api.getParameterOptions).toHaveBeenCalledWith(this.mockedParameter, stubs.allSelections);
            });
            return it("expected result", function() {
              return expect(this.value.result).toBe(correctSqlResult);
            });
          });
          return describe('for server side ERROR result has', function() {
            beforeEach(function(next) {
              var valueDeferred;
              setErrorOnGetParametersOptions = true;
              returnFailedResultOngetParametersOptions = false;
              this.mocks.api.getParameterOptions.calls.reset();
              this.mockedParameter = getParameterMock('SELECT', 'SQL');
              valueDeferred = this.parametersEvaluator.evaluate(this.mockedParameter);
              this.value = void 0;
              return valueDeferred.done((function(_this) {
                return function(v) {
                  _this.value = v;
                  return next();
                };
              })(this));
            });
            it("error", function() {
              return expect(this.value.isError).toBeTruthy();
            });
            it("error message", function() {
              return expect(this.value.errorMessage).toBeTruthy();
            });
            it("calls getParameterOptions once", function() {
              return expect(this.mocks.api.getParameterOptions.calls.count()).toBe(1);
            });
            it("calls getParameterOptions with parameterId", function() {
              return expect(this.mocks.api.getParameterOptions).toHaveBeenCalledWith(this.mockedParameter, stubs.allSelections);
            });
            return it("expected result", function() {
              return expect(this.value.result).toBeUndefined();
            });
          });
        });
      });
      return describe("evaluating all parameters ", function() {
        beforeEach(function() {
          setErrorOnGetParametersOptions = false;
          return returnFailedResultOngetParametersOptions = false;
        });
        describe("with all prerequisites ready", function() {
          beforeEach(function(next) {
            var valueDeferred;
            stubs.parameters()[0].userSelection('1');
            stubs.parameters()[0].hasSelection = function() {
              return true;
            };
            stubs.parameters()[2].userSelection('1');
            stubs.parameters()[2].hasSelection = function() {
              return true;
            };
            stubs.parameters()[3].userSelection('1');
            stubs.parameters()[3].hasSelection = function() {
              return true;
            };
            this.mocks.api.getParameterOptions.calls.reset();
            this.parametersEvaluator.refreshEvaluationOrder();
            valueDeferred = this.parametersEvaluator.evaluateParameters();
            return valueDeferred.done(function() {
              return next();
            });
          });
          afterEach(function() {
            stubs.parameters()[0].userSelection(null);
            stubs.parameters()[0].hasSelection = function() {
              return false;
            };
            stubs.parameters()[2].userSelection(null);
            stubs.parameters()[2].hasSelection = function() {
              return false;
            };
            stubs.parameters()[3].userSelection(null);
            return stubs.parameters()[3].hasSelection = function() {
              return false;
            };
          });
          return describe("for all SQL parameters", function() {
            it("calls api.getParametersOptions", function() {
              return expect(this.mocks.api.getParameterOptions.calls.count()).toBe(sqlParameters.length);
            });
            it("all parameters passed to api.getParametersOptions calls", function() {
              return expect(_.all(this.mocks.api.getParameterOptions.calls.all(), function(call) {
                return _.find(sqlParameters, function(p) {
                  return p.Id === call.args[0].Id;
                });
              })).toBeTruthy();
            });
            return it("pass to api.getParametersOptions allSelection", function() {
              return expect(_.all(this.mocks.api.getParameterOptions.calls.all(), function(call) {
                return stubs.allSelections === call.args[1];
              })).toBeTruthy();
            });
          });
        });
        describe("when some prerequisites are not ready", function() {
          beforeEach(function(next) {
            var valueDeferred;
            stubs.parameters()[0].userSelection('1');
            stubs.parameters()[0].hasSelection = function() {
              return true;
            };
            this.mocks.api.getParameterOptions.calls.reset();
            this.parametersEvaluator.refreshEvaluationOrder();
            valueDeferred = this.parametersEvaluator.evaluateParameters();
            return valueDeferred.done(function() {
              return next();
            });
          });
          afterEach(function() {
            stubs.parameters()[0].userSelection(null);
            return stubs.parameters()[0].hasSelection = function() {
              return false;
            };
          });
          return it("does not calls api.getParametersOptions for not ready prerequisites parameter", function() {
            return expect(_.find(this.mocks.api.getParameterOptions.calls.all(), function(call) {
              return call.args[0].Id === 4;
            })).toBeFalsy;
          });
        });
        return describe("when some prerequisites are not ready with all default values specified", function() {
          beforeEach(function(next) {
            var valueDeferred;
            _.each(stubs.parameters, function(p) {
              p.sub = p.evaluated.subscribe(function(value) {
                if (value) {
                  p.oldUserSelection = p.userSelection();
                  p.oldHasSelection = p.hasSelection;
                  p.userSelection(value);
                  return p.hasSelection = function() {
                    return true;
                  };
                }
              });
              return p.evaluated(false);
            });
            this.mocks.api.getParameterOptions.calls.reset();
            this.parametersEvaluator.refreshEvaluationOrder();
            valueDeferred = this.parametersEvaluator.evaluateParameters();
            return valueDeferred.done(next);
          });
          afterEach(function() {
            return _.each(stubs.parameters, function(p) {
              p.sub.dispose();
              p.userSelection(p.oldUserSelection);
              p.hasSelection = p.oldHasSelection;
              return p.setUserSelectionOrFallbackToDefaultValue = function() {};
            });
          });
          it("set all userSelections", function() {
            return expect(_.all(stubs.parameters, function(p) {
              return p.userSelection();
            })).toBeTruthy();
          });
          return describe("calls api.getParametersOptions", function() {
            it("for all SQL parameters", function() {
              return expect(this.mocks.api.getParameterOptions.calls.count()).toBe(sqlParameters.length);
            });
            describe("for second call", function() {
              beforeEach(function(next) {
                var valueDeferred;
                this.apiCallsCount = this.mocks.api.getParameterOptions.calls.count();
                valueDeferred = this.parametersEvaluator.evaluateParameters();
                return valueDeferred.done(next);
              });
              return it("does not calls api.getParametersOptions anymore", function() {
                return expect(this.mocks.api.getParameterOptions.calls.count()).toBe(this.apiCallsCount);
              });
            });
            describe("for second call with cleanup evaluated flag on dependants one item", function() {
              beforeEach(function(next) {
                var valueDeferred;
                this.apiCallsCount = this.mocks.api.getParameterOptions.calls.count();
                this.parametersEvaluator.cleanupEvaluatedFlagOnDependants(stubs.parameters()[2]);
                valueDeferred = this.parametersEvaluator.evaluateParameters();
                return valueDeferred.done(next);
              });
              return describe("calls api.getParametersOptions", function() {
                it("for one item", function() {
                  return expect(this.mocks.api.getParameterOptions.calls.count()).toBe(this.apiCallsCount + 1);
                });
                return it("with correct parameter id", function() {
                  return expect(this.mocks.api.getParameterOptions.calls.mostRecent().args[0].Id).toBe(4);
                });
              });
            });
            return describe("for second call with cleanup evaluated flag on dependants tree", function() {
              beforeEach(function(next) {
                var valueDeferred;
                this.apiCallsCount = this.mocks.api.getParameterOptions.calls.count();
                this.parametersEvaluator.cleanupEvaluatedFlagOnDependants(stubs.parameters()[0]);
                valueDeferred = this.parametersEvaluator.evaluateParameters();
                return valueDeferred.done(next);
              });
              return describe("calls api.getParametersOptions", function() {
                it("for one item", function() {
                  return expect(this.mocks.api.getParameterOptions.calls.count()).toBe(this.apiCallsCount + 2);
                });
                return it("with correct parameter ids", function() {
                  var last2Calls;
                  last2Calls = _.last(this.mocks.api.getParameterOptions.calls.all(), 2);
                  expect(last2Calls[0].args[0].Id).toBe(3);
                  return expect(last2Calls[1].args[0].Id).toBe(4);
                });
              });
            });
          });
        });
      });
    });
  });

}).call(this);
