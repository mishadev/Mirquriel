﻿(function() {
  define(['jasmine', 'underscore', 'knockout', 'jquery', 'parameters/parametersContext', 'parameters/parametersFactory'], function(jasmine, _, ko, $, parametersContext, parametersFactory) {
    var additionalParameters, factory, fakeGetParameterOptions, parameters;
    parameters = [
      {
        Id: 1,
        Name: 'TextParameter',
        DisplayName: 'Text Parameter',
        ParamType: 'TEXT',
        DefaultSelection: 'TextParameter',
        EvaluationType: 'JSON',
        EvaluationSource: ko.toJSON([
          {
            key: 1,
            desc: "some text 1"
          }, {
            key: 2,
            desc: "some text 2"
          }
        ])
      }, {
        Id: 2,
        Name: 'CheckboxParameter',
        DisplayName: 'Checkbox Parameter',
        ParamType: 'CHECKBOX',
        EvaluationType: 'JSON',
        EvaluationSource: ko.toJSON([
          {
            key: 1,
            desc: "some text 1"
          }, {
            key: 2,
            desc: "some text 2"
          }
        ]),
        IsOptionalParameter: true
      }, {
        Id: 3,
        Name: 'SelectParameter',
        DisplayName: 'Select Parameter',
        ParamType: 'SELECT',
        DefaultSelection: ko.toJSON({
          key: 1,
          desc: "some text 1"
        }),
        EvaluationType: 'JSON',
        EvaluationSource: ko.toJSON([
          {
            key: 1,
            desc: "some text 1"
          }, {
            key: 2,
            desc: "some text 2"
          }
        ])
      }, {
        Id: 4,
        Name: 'MultiselectParameter',
        DisplayName: 'Multiselect Parameter',
        DefaultSelection: ko.toJSON({
          key: 1,
          desc: "some text 1"
        }),
        EvaluationType: 'JSON',
        ParamType: 'MULTISELECT',
        EvaluationSource: ko.toJSON([
          {
            key: 1,
            desc: "some text 1"
          }, {
            key: 2,
            desc: "some text 2"
          }
        ])
      }, {
        Id: 5,
        Name: 'SearchselectParameter',
        DisplayName: 'Searchselect Parameter',
        EvaluationType: 'SQL',
        EvaluationSource: 'SELECT 1',
        ParamType: 'SEARCHSELECT',
        IsOptionalParameter: true
      }
    ];
    additionalParameters = [
      {
        Id: 1,
        Name: 'AdditionalSelectParameter',
        DisplayName: 'Additional Select Parameter',
        EvaluationType: 'SQL',
        EvaluationSource: 'SELECT 1',
        ParamType: 'SELECT'
      }, {
        Id: 1,
        Name: 'AdditionalSelectParameter2',
        DisplayName: 'Additional Select Parameter',
        EvaluationType: 'SQL',
        EvaluationSource: 'SELECT 1',
        ParamType: 'SELECT'
      }
    ];
    fakeGetParameterOptions = function() {
      return $.when([
        {
          key: 1,
          desc: "some text 1"
        }, {
          key: 2,
          desc: "some text 2"
        }
      ]);
    };
    factory = parametersFactory();
    additionalParameters = _.map(additionalParameters, function(p) {
      return factory.createParameter(ko.toJS(p));
    });
    return describe("Is parameters context", function() {
      beforeEach(function() {
        return this.context = parametersContext(parameters, ko.observable(additionalParameters), {
          getParameterOptions: fakeGetParameterOptions
        });
      });
      it("publish changes", function(done) {
        var parameter;
        parameter = this.context.parameters()[0];
        this.context.subscribeOnUserSelectionsChanged(function(p) {
          (expect(p.Id)).toBe(parameter.Id);
          return done();
        });
        return parameter.deserializeUserSelection(2);
      });
      it("detects if it isn't fulfilled", function() {
        return (expect(this.context.isFulfilled())).toBeFalsy();
      });
      it("detects if it's fulfilled", function() {
        var requaered;
        requaered = _.filter(this.context.parameters, function(p) {
          return !p.IsOptionalParameter;
        });
        _.each(requaered, function(p) {
          return p.userSelection({
            key: 1,
            desc: "some text 1"
          });
        });
        (expect(this.context.isFulfilled())).toBeTruthy();
        requaered[0].userSelection(void 0);
        return (expect(this.context.isFulfilled())).toBeFalsy();
      });
      return describe("could change parameter user selection by name", function() {
        it("in TEXT typed parameter", function() {
          var parameter;
          parameter = _.find(this.context.parameters(), function(p) {
            return p.ParamType() === 'TEXT';
          });
          this.context.deserializeParameterWithName(parameter.Name(), "x");
          return (expect(parameter.userSelection())).toBe("x");
        });
        it("in CHECKBOX typed parameter", function() {
          var parameter;
          parameter = _.find(this.context.parameters(), function(p) {
            return p.ParamType() === 'CHECKBOX';
          });
          this.context.deserializeParameterWithName(parameter.Name(), 2);
          return (expect(parameter.userSelection())).toEqual({
            key: "2",
            desc: "some text 2"
          });
        });
        it("in SELECT typed parameter", function() {
          var parameter;
          parameter = _.find(this.context.parameters(), function(p) {
            return p.ParamType() === 'SELECT';
          });
          this.context.deserializeParameterWithName(parameter.Name(), 2);
          return (expect(parameter.userSelection())).toEqual({
            key: "2",
            desc: "some text 2"
          });
        });
        return it("in MULTISELECT typed parameter", function() {
          var parameter;
          parameter = _.find(this.context.parameters(), function(p) {
            return p.ParamType() === 'MULTISELECT';
          });
          this.context.deserializeParameterWithName(parameter.Name(), ko.toJSON(["1", "2"]));
          return (expect(parameter.userSelection().key)).toEqual(ko.toJSON(["1", "2"]));
        });
      });
    });
  });

}).call(this);
