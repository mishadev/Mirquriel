﻿(function() {
  define(['jasmine', 'underscore', 'knockout', 'jquery', 'parameters/textParameter', 'parameters/checkboxParameter', 'parameters/selectParameter', 'parameters/multiselectParameter', 'parameters/searchSelectParameter'], function(jasmine, _, ko, $, textParameter, checkboxParameter, selectParameter, multiselectParameter, searchselectParameter) {
    var parameter;
    parameter = {
      text: {
        Id: 1,
        Name: 'TextParameter',
        DisplayName: 'Text Parameter',
        ParamType: 'TEXT',
        DefaultSelection: 'TextParameter',
        EvaluationType: 'NONE'
      },
      checkbox: {
        Id: 2,
        Name: 'CheckboxParameter',
        DisplayName: 'Checkbox Parameter',
        ParamType: 'CHECKBOX',
        EvaluationType: 'JSON'
      },
      select: {
        Id: 3,
        Name: 'SelectParameter',
        DisplayName: 'Select Parameter',
        ParamType: 'SELECT',
        DefaultSelection: ko.toJSON({
          key: 1,
          desc: "some text 1"
        }),
        EvaluationType: 'JSON'
      },
      multiselect: {
        Id: 4,
        Name: 'MultiselectParameter',
        DisplayName: 'Multiselect Parameter',
        DefaultSelection: ko.toJSON({
          key: 1,
          desc: "some text 1"
        }),
        EvaluationType: 'JSON',
        ParamType: 'MULTISELECT'
      },
      searchselect: {
        Id: 5,
        Name: 'SearchselectParameter',
        DisplayName: 'Searchselect Parameter',
        EvaluationType: 'SQL',
        ParamType: 'SEARCHSELECT'
      }
    };
    return describe("Is parameter with", function() {
      describe("text type", function() {
        var param, userSelection;
        param = textParameter(parameter.text);
        param.setEvaluatedValues([
          {
            key: 1,
            desc: "some text 1"
          }
        ]);
        param.evaluated(true);
        userSelection = "some text";
        it("constructs properly", function() {
          (expect(function() {
            return textParameter(_.extend({}, parameter.text, {
              EvaluationType: 'NONE'
            }));
          })).not.toThrow();
          (expect(function() {
            return textParameter(_.extend({}, parameter.text, {
              EvaluationType: 'SQL'
            }));
          })).not.toThrow();
          return (expect(function() {
            return textParameter(_.extend({}, parameter.text, {
              EvaluationType: 'JSON'
            }));
          })).not.toThrow();
        });
        it("serialize user selection properly", function() {
          param.userSelection(userSelection);
          return (expect(param.serializeUserSelection())).toBe(userSelection);
        });
        it("deserialize user selection properly", function() {
          param.deserializeUserSelection(userSelection + "2");
          (expect(param.userSelection())).toBe(userSelection + "2");
          param.deserializeUserSelection(99999);
          (expect(param.userSelection())).toBe("99999");
          param.deserializeUserSelection({
            x: 'y'
          });
          return (expect(param.userSelection())).toBe("[object Object]");
        });
        return it("evaluation considered properly", function() {
          param.userSelection(void 0);
          param.evaluated(false);
          param.setEvaluatedValues([
            {
              key: "some text",
              desc: "some text"
            }, {
              key: 2,
              desc: "some text 2"
            }
          ]);
          param.evaluated(true);
          (expect(param.userSelection())).toBe("some text");
          param.userSelection(void 0);
          param.evaluated(false);
          param.setEvaluatedValues([
            {
              key: 1,
              desc: "some text 1"
            }, {
              key: 2,
              desc: "some text 2"
            }
          ]);
          param.evaluated(true);
          return (expect(param.userSelection())).toBe("1");
        });
      });
      describe("checkbox type", function() {
        it("constructs properly", function() {
          (expect(function() {
            return checkboxParameter(_.extend({}, parameter.text, {
              EvaluationType: 'NONE'
            }));
          })).toThrow();
          (expect(function() {
            return checkboxParameter(_.extend({}, parameter.text, {
              EvaluationType: 'SQL'
            }));
          })).not.toThrow();
          return (expect(function() {
            return checkboxParameter(_.extend({}, parameter.text, {
              EvaluationType: 'JSON'
            }));
          })).not.toThrow();
        });
        return describe("with json evaluation type", function() {
          var param;
          param = checkboxParameter(parameter.checkbox);
          param.setEvaluatedValues([
            {
              key: 1,
              desc: "some text 1"
            }, {
              key: 2,
              desc: "some text 2"
            }
          ]);
          param.evaluated(true);
          it("serialize user selection properly", function() {
            param.userCheckboxSelection(false);
            (expect(param.serializeUserSelection())).toBe("1");
            param.userCheckboxSelection(true);
            return (expect(param.serializeUserSelection())).toBe("2");
          });
          return it("deserialize user selection properly", function() {
            param.deserializeUserSelection(1);
            (expect(param.userCheckboxSelection())).toBeFalsy();
            param.deserializeUserSelection(2);
            return (expect(param.userCheckboxSelection())).toBeTruthy();
          });
        });
      });
      describe("select type", function() {
        var param;
        param = selectParameter(parameter.select);
        param.setEvaluatedValues([
          {
            key: 1,
            desc: "some text 1"
          }, {
            key: 2,
            desc: "some text 2"
          }
        ]);
        param.evaluated(true);
        it("constructs properly", function() {
          (expect(function() {
            return selectParameter(_.extend({}, parameter.select, {
              EvaluationType: 'NONE'
            }));
          })).toThrow();
          (expect(function() {
            return selectParameter(_.extend({}, parameter.select, {
              EvaluationType: 'SQL'
            }));
          })).not.toThrow();
          return (expect(function() {
            return selectParameter(_.extend({}, parameter.select, {
              EvaluationType: 'JSON'
            }));
          })).not.toThrow();
        });
        it("serialize user selection properly", function() {
          param.userSelection(param.evaluatedValues()[0]);
          (expect(param.serializeUserSelection())).toBe("1");
          param.userSelection(param.evaluatedValues()[1]);
          return (expect(param.serializeUserSelection())).toBe("2");
        });
        return it("deserialize user selection properly", function() {
          param.deserializeUserSelection(1);
          (expect(param.userSelection())).toBe(param.evaluatedValues()[0]);
          param.deserializeUserSelection(2);
          return (expect(param.userSelection())).toBe(param.evaluatedValues()[1]);
        });
      });
      describe("multiselect type", function() {
        var param, selectedOptions, stringifyedSelectedOptions;
        param = multiselectParameter(parameter.multiselect);
        param.setEvaluatedValues([
          {
            key: 1,
            desc: "some text 1"
          }, {
            key: 2,
            desc: "some text 2"
          }
        ]);
        param.evaluated(true);
        selectedOptions = _.pluck(param.evaluatedValues(), 'key');
        stringifyedSelectedOptions = JSON.stringify(selectedOptions);
        it("constructs properly", function() {
          (expect(function() {
            return multiselectParameter(_.extend({}, parameter.multiselect, {
              EvaluationType: 'NONE'
            }));
          })).toThrow();
          (expect(function() {
            return multiselectParameter(_.extend({}, parameter.multiselect, {
              EvaluationType: 'SQL'
            }));
          })).not.toThrow();
          return (expect(function() {
            return multiselectParameter(_.extend({}, parameter.multiselect, {
              EvaluationType: 'JSON'
            }));
          })).not.toThrow();
        });
        describe("serialize user selection properly", function() {
          it("select all by all options", function() {
            param.deserializeUserSelection(stringifyedSelectedOptions);
            return (expect(param.serializeUserSelection())).toBe("*");
          });
          return it("select all by '*'", function() {
            param.deserializeUserSelection("*");
            (expect(param.serializeUserSelection())).toBe("*");
            return (expect(param.userSelection().key)).toBe(stringifyedSelectedOptions);
          });
        });
        it("deserialize user selection properly", function() {
          var option;
          option = param.evaluatedValues()[0];
          param.deserializeUserSelection(JSON.stringify([option.key]));
          (expect(param.userSelection().desc)).toBe(JSON.stringify([option.desc]));
          option = param.evaluatedValues()[1];
          param.deserializeUserSelection(JSON.stringify([option.key]));
          return (expect(param.selectedOptions())).toEqual([option.key]);
        });
        return it("set selectedOptions", function() {
          param.userSelection(void 0);
          (expect(param.selectedOptions())).toEqual([]);
          param.deserializeUserSelection("*");
          return (expect(param.selectedOptions())).toEqual(selectedOptions);
        });
      });
      return describe("searchselect type", function() {
        var param;
        param = searchselectParameter(parameter.searchselect);
        param.setEvaluatedValues([
          {
            key: 1,
            desc: "some text 1"
          }
        ]);
        param.evaluated(true);
        param.missingPrereqs = function() {
          return false;
        };
        it("constructs properly", function() {
          (expect(function() {
            return searchselectParameter(_.extend({}, parameter.searchselect, {
              EvaluationType: 'NONE'
            }));
          })).toThrow();
          (expect(function() {
            return searchselectParameter(_.extend({}, parameter.searchselect, {
              EvaluationType: 'SQL'
            }));
          })).not.toThrow();
          return (expect(function() {
            return searchselectParameter(_.extend({}, parameter.searchselect, {
              EvaluationType: 'JSON'
            }));
          })).toThrow();
        });
        return it("user search selection", function() {
          param.userSearchSelection('1');
          (expect(param.userSelection())).toEqual({
            key: '1',
            desc: "some text 1"
          });
          param.userSearchSelection('');
          return (expect(param.userSelection())).toEqual(void 0);
        });
      });
    });
  });

}).call(this);
