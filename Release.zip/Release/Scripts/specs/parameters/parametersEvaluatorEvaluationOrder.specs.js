﻿(function() {
  define(['jasmine', 'Squire', 'underscore', 'knockout'], function(jasmine, Squire, _, ko) {
    var customMatchers, getSimplifiedOrder, mockParametersEvaluatorAndRunNext, stubs;
    getSimplifiedOrder = function(name, level, dependants, dependsOn) {
      return {
        name: name,
        level: level,
        dependants: _.isArray(dependants) ? _.sortBy(dependants, function(d) {
          return d;
        }) : [],
        dependsOn: _.isArray(dependsOn) ? _.sortBy(dependsOn, function(d) {
          return d;
        }) : []
      };
    };
    stubs = {
      parametersWithoutAdditionalParametersPrerequisites: {
        parameters: ko.observableArray([
          {
            Id: 1,
            Name: ko.observable('p1'),
            ParamType: ko.observable('SELECT'),
            EvaluationType: ko.observable('SQL'),
            EvaluationSource: ko.observable('SELECT 1'),
            evaluated: ko.observable(false),
            clearUserSelection: function() {},
            userSelection: ko.observable()
          }, {
            Id: 2,
            Name: ko.observable('p2'),
            ParamType: ko.observable('SELECT'),
            EvaluationType: ko.observable('JSON'),
            EvaluationSource: ko.observable('[{ "key": "1", "desc":"1"}, { "key": "2", "desc":"2"}]'),
            evaluated: ko.observable(false),
            clearUserSelection: function() {},
            userSelection: ko.observable()
          }, {
            Id: 3,
            Name: ko.observable('p3'),
            ParamType: ko.observable('SELECT'),
            EvaluationType: ko.observable('SQL'),
            EvaluationSource: ko.observable('SELECT @p1, @p2'),
            evaluated: ko.observable(false),
            clearUserSelection: function() {},
            userSelection: ko.observable()
          }, {
            Id: 4,
            Name: ko.observable('p4'),
            ParamType: ko.observable('SELECT'),
            EvaluationType: ko.observable('SQL'),
            EvaluationSource: ko.observable('SELECT @p1, @p3'),
            evaluated: ko.observable(false),
            clearUserSelection: function() {},
            userSelection: ko.observable()
          }, {
            Id: 5,
            Name: ko.observable('p5'),
            ParamType: ko.observable('TEXT'),
            EvaluationType: ko.observable('NONE'),
            EvaluationSource: ko.observable(null),
            evaluated: ko.observable(false),
            clearUserSelection: function() {},
            userSelection: ko.observable()
          }
        ]),
        additionalParameters: ko.observableArray(),
        expected: [[getSimplifiedOrder('p1', 0, ['p3', 'p4']), getSimplifiedOrder('p2', 0, ['p3']), getSimplifiedOrder('p5', 0)], [getSimplifiedOrder('p3', 1, ['p4'], ['p1', 'p2'])], [getSimplifiedOrder('p4', 2, [], ['p1', 'p3'])]]
      },
      parametersWithMissedPrerequisite: {
        parameters: ko.observableArray([
          {
            Id: 1,
            Name: ko.observable('p1'),
            ParamType: ko.observable('SELECT'),
            EvaluationType: ko.observable('SQL'),
            EvaluationSource: ko.observable('SELECT 1')
          }, {
            Id: 2,
            Name: ko.observable('p2'),
            ParamType: ko.observable('SELECT'),
            EvaluationType: ko.observable('JSON'),
            EvaluationSource: ko.observable('[{ "key": "1", "desc":"1"}, { "key": "2", "desc":"2"}]')
          }, {
            Id: 3,
            Name: ko.observable('p3'),
            ParamType: ko.observable('SELECT'),
            EvaluationType: ko.observable('SQL'),
            EvaluationSource: ko.observable('SELECT @p1, @p100')
          }, {
            Id: 4,
            Name: ko.observable('p4'),
            ParamType: ko.observable('SELECT'),
            EvaluationType: ko.observable('SQL'),
            EvaluationSource: ko.observable('SELECT @p1, @p3')
          }, {
            Id: 5,
            Name: ko.observable('p5'),
            ParamType: ko.observable('TEXT'),
            EvaluationType: ko.observable('NONE'),
            EvaluationSource: ko.observable(null)
          }
        ]),
        additionalParameters: ko.observableArray(),
        expected: [[getSimplifiedOrder('p1', 0, ['p3', 'p4']), getSimplifiedOrder('p2', 0), getSimplifiedOrder('p5', 0)], [getSimplifiedOrder('p3', 1, ['p4'], ['p1'])], [getSimplifiedOrder('p4', 2, [], ['p1', 'p3'])]]
      },
      parametersWithAdditionalParametersPrerequisite: {
        parameters: ko.observableArray([
          {
            Id: 1,
            Name: ko.observable('p1'),
            ParamType: ko.observable('SELECT'),
            EvaluationType: ko.observable('SQL'),
            EvaluationSource: ko.observable('SELECT 1'),
            evaluated: ko.observable(false),
            userSelection: ko.observable(),
            clearUserSelection: function() {}
          }, {
            Id: 2,
            Name: ko.observable('p2'),
            ParamType: ko.observable('SELECT'),
            EvaluationType: ko.observable('JSON'),
            EvaluationSource: ko.observable('[{ "key": "1", "desc":"1"}, { "key": "2", "desc":"2"}]'),
            evaluated: ko.observable(false),
            userSelection: ko.observable(),
            clearUserSelection: function() {}
          }, {
            Id: 3,
            Name: ko.observable('p3'),
            ParamType: ko.observable('SELECT'),
            EvaluationType: ko.observable('SQL'),
            EvaluationSource: ko.observable('SELECT @p1, @a1'),
            evaluated: ko.observable(false),
            userSelection: ko.observable(),
            clearUserSelection: function() {}
          }, {
            Id: 4,
            Name: ko.observable('p4'),
            ParamType: ko.observable('SELECT'),
            EvaluationType: ko.observable('SQL'),
            EvaluationSource: ko.observable('SELECT @p1, @p3'),
            evaluated: ko.observable(false),
            userSelection: ko.observable(),
            clearUserSelection: function() {}
          }, {
            Id: 5,
            Name: ko.observable('p5'),
            ParamType: ko.observable('TEXT'),
            EvaluationType: ko.observable('NONE'),
            EvaluationSource: ko.observable(null),
            evaluated: ko.observable(false),
            userSelection: ko.observable(),
            clearUserSelection: function() {}
          }
        ]),
        additionalParameters: ko.observableArray([
          {
            Id: 6,
            Name: ko.observable('a1'),
            ParamType: ko.observable('SELECT'),
            EvaluationType: ko.observable('SQL'),
            EvaluationSource: ko.observable('SELECT 1')
          }, {
            Id: 7,
            Name: ko.observable('a2'),
            ParamType: ko.observable('SELECT'),
            EvaluationType: ko.observable('SQL'),
            EvaluationSource: ko.observable('SELECT 1')
          }
        ]),
        expected: [[getSimplifiedOrder('p1', 0, ['p3', 'p4']), getSimplifiedOrder('p2', 0), getSimplifiedOrder('p5', 0)], [getSimplifiedOrder('p3', 1, ['p4'], ['p1'])], [getSimplifiedOrder('p4', 2, [], ['p1', 'p3'])]]
      }
    };
    customMatchers = {
      toBeSameEvaluationOrder: function() {
        return {
          compare: function(actual, expected) {
            var getOrderAsSimplifiedOrder, show, simplifiedActual;
            getOrderAsSimplifiedOrder = function(order) {
              return _.map(order, function(level) {
                return _.map(level, function(o) {
                  return getSimplifiedOrder(o.parameter.Name(), o.level, _.map(o.dependants, function(d) {
                    return d.parameter.Name();
                  }), _.map(o.dependsOn, function(d) {
                    return d.parameter.Name();
                  }));
                });
              });
            };
            simplifiedActual = getOrderAsSimplifiedOrder(actual);
            _.each(simplifiedActual, function(level, index) {
              return simplifiedActual[index] = _.sortBy(simplifiedActual[index], function(o) {
                return o.name;
              });
            });
            show = function(object) {
              if (object) {
                return JSON.stringify(object);
              } else {
                return '(null)';
              }
            };
            return {
              pass: _.isEqual(simplifiedActual, expected),
              message: "Expected order " + (show(expected)) + "\nbut found      " + (show(simplifiedActual))
            };
          }
        };
      }
    };
    mockParametersEvaluatorAndRunNext = function(parametersStubs, next) {
      this.mocks = {};
      _.visitObject(this.mocks, (function(_this) {
        return function(val, name, parent) {
          if (_.isFunction(val)) {
            return (spyOn(parent, name)).and.callThrough();
          }
        };
      })(this));
      this.injector = new Squire().mock(this.mocks);
      return this.injector.require(['parameters/parametersEvaluator'], (function(_this) {
        return function(evaluator) {
          _this.parametersEvaluator = evaluator(parametersStubs.parameters, parametersStubs.additionalParameters);
          return next();
        };
      })(this));
    };
    return describe("Is Parameters Evaluator calculates evaluation order", function() {
      describe("without additional parameters prerequisites", function() {
        beforeEach(function(next) {
          jasmine.addMatchers(customMatchers);
          return mockParametersEvaluatorAndRunNext.apply(this, [stubs.parametersWithoutAdditionalParametersPrerequisites, next]);
        });
        it("with sequentionally ordered dependencies", function() {
          var expected;
          stubs.parametersWithoutAdditionalParametersPrerequisites.parameters(_.sortBy(stubs.parametersWithoutAdditionalParametersPrerequisites.parameters(), function(p) {
            return p.Name();
          }));
          expected = stubs.parametersWithoutAdditionalParametersPrerequisites.expected;
          return expect(this.parametersEvaluator.createEvaluationOrder()).toBeSameEvaluationOrder(expected);
        });
        return it("with not sequentionally ordered dependencies", function() {
          var expected;
          stubs.parametersWithoutAdditionalParametersPrerequisites.parameters(_.shuffle(stubs.parametersWithoutAdditionalParametersPrerequisites.parameters()));
          expected = stubs.parametersWithoutAdditionalParametersPrerequisites.expected;
          return expect(this.parametersEvaluator.createEvaluationOrder()).toBeSameEvaluationOrder(expected);
        });
      });
      describe("with additional parameters prerequisites", function() {
        beforeEach(function(next) {
          jasmine.addMatchers(customMatchers);
          return mockParametersEvaluatorAndRunNext.apply(this, [stubs.parametersWithAdditionalParametersPrerequisite, next]);
        });
        it("with sequentionally ordered dependencies", function() {
          var expected;
          stubs.parametersWithAdditionalParametersPrerequisite.parameters(_.sortBy(stubs.parametersWithAdditionalParametersPrerequisite.parameters(), function(p) {
            return p.Name();
          }));
          expected = stubs.parametersWithAdditionalParametersPrerequisite.expected;
          return expect(this.parametersEvaluator.createEvaluationOrder()).toBeSameEvaluationOrder(expected);
        });
        return it("with not sequentionally ordered dependencies", function() {
          var expected;
          stubs.parametersWithAdditionalParametersPrerequisite.parameters(_.shuffle(stubs.parametersWithAdditionalParametersPrerequisite.parameters()));
          expected = stubs.parametersWithAdditionalParametersPrerequisite.expected;
          return expect(this.parametersEvaluator.createEvaluationOrder()).toBeSameEvaluationOrder(expected);
        });
      });
      return describe("with missed prerequisites", function() {
        beforeEach(function(next) {
          jasmine.addMatchers(customMatchers);
          return mockParametersEvaluatorAndRunNext.apply(this, [stubs.parametersWithMissedPrerequisite, next]);
        });
        return it("correctly", function() {
          var expected;
          expected = stubs.parametersWithMissedPrerequisite.expected;
          return expect(this.parametersEvaluator.createEvaluationOrder()).toBeSameEvaluationOrder(expected);
        });
      });
    });
  });

}).call(this);
