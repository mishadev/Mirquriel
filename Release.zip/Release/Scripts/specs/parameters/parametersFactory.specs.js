﻿(function() {
  define(['jasmine', 'Squire', 'underscore', 'knockout', 'knockout.mapping'], function(jasmine, Squire, _, ko, mapping) {
    var checkParametersFactoryToWorkWith, createParameterFromModel, stubs;
    stubs = {
      textParameterModel: {
        Id: 1,
        Name: 'TextParameter',
        DisplayName: 'Text Parameter',
        ParamType: 'TEXT',
        EvaluationType: 'NONE',
        EvaluationSource: null,
        DefaultSelection: "Text Parameter Default Selection"
      },
      selectParameterModel: {
        Id: 2,
        Name: 'SelectParameter',
        DisplayName: 'Select Parameter',
        ParamType: 'SELECT',
        EvaluationType: 'JSON',
        EvaluationSource: '[{ "key": "1", "desc":"Select 1"}, { "key": "2", "desc":"Select 2"}]',
        DefaultSelection: "Select Parameter Default Selection"
      },
      checkboxParameterModel: {
        Id: 3,
        Name: 'CheckboxParameter',
        DisplayName: 'Checkbox Parameter',
        ParamType: 'CHECKBOX',
        EvaluationType: 'JSON',
        EvaluationSource: '[{ "key": "1", "desc":"Checkbox 1"}, { "key": "2", "desc":"Checkbox 2"}]',
        DefaultSelection: "Checkbox Parameter Default Selection"
      },
      multiselectParameterModel: {
        Id: 4,
        Name: 'MultiselectParameter',
        DisplayName: 'Multiselect Parameter',
        ParamType: 'MULTISELECT',
        EvaluationType: 'JSON',
        EvaluationSource: '[{ "key": "1", "desc":"Multiselect 1"}, { "key": "2", "desc":"Multiselect 2"}]',
        DefaultSelection: "Multiselect Parameter Default Selection"
      }
    };
    createParameterFromModel = function(model) {
      return _.extend(mapping.fromJS(model, {
        copy: ['Id']
      }));
    };
    checkParametersFactoryToWorkWith = function(parameterType, model, constructorFunctionGetter) {
      return describe(parameterType + " parameter", function() {
        beforeEach(function() {
          return this.parameter = this.parametersFactory.createParameter(model);
        });
        it("has " + parameterType + " parameterType in known types", function() {
          return (expect(_.contains(this.parametersFactory.parameterTypes, parameterType))).toBe(true);
        });
        it("calls " + parameterType + " constructor", function() {
          return expect(constructorFunctionGetter(this.mocks)).toHaveBeenCalledWith(model);
        });
        return it("returns parameter with same id", function() {
          return expect(this.parameter.Id).toBe(model.Id);
        });
      });
    };
    return describe("Is Parameters Factory", function() {
      beforeEach(function(next) {
        this.mocks = {
          'parameters/textParameter': createParameterFromModel,
          'parameters/selectParameter': createParameterFromModel,
          'parameters/checkboxParameter': createParameterFromModel,
          'parameters/multiselectParameter': createParameterFromModel
        };
        _.visitObject(this.mocks, (function(_this) {
          return function(val, name, parent) {
            if (_.isFunction(val)) {
              return (spyOn(parent, name)).and.callThrough();
            }
          };
        })(this));
        this.injector = new Squire().mock(this.mocks);
        return this.injector.require(['parameters/parametersFactory'], (function(_this) {
          return function(factory) {
            _this.parametersFactory = factory();
            return next();
          };
        })(this));
      });
      return describe("creating", function() {
        checkParametersFactoryToWorkWith("TEXT", stubs.textParameterModel, function(mocks) {
          return mocks['parameters/textParameter'];
        });
        checkParametersFactoryToWorkWith("SELECT", stubs.selectParameterModel, function(mocks) {
          return mocks['parameters/selectParameter'];
        });
        checkParametersFactoryToWorkWith("CHECKBOX", stubs.checkboxParameterModel, function(mocks) {
          return mocks['parameters/checkboxParameter'];
        });
        checkParametersFactoryToWorkWith("MULTISELECT", stubs.multiselectParameterModel, function(mocks) {
          return mocks['parameters/multiselectParameter'];
        });
        return it("parameter with incorrect type throws error", function() {
          return expect(function() {
            return this.parametersFactory.createParameter({
              ParamType: ko.oservable("incorrectType")
            });
          }).toThrow;
        });
      });
    });
  });

}).call(this);
