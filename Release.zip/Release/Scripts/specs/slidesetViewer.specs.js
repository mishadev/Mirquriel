﻿(function() {
  define(['jasmine', 'Squire', 'underscore', 'jquery', 'knockout', 'specs/helpers/parseSlideSetDsl'], function(jasmine, Squire, _, $, ko, parseSlideSetDsl) {
    var categorySlideSets, changeHierarchyParameterSelectionAndWaitUntilEventFired, changeHrefWithHierarchyParametersAndWaitUntilEventFired, commonParameters, customMatchers, doActionAndWaitUntilSelectionsChangedEventFired, expectUrlToMatch, fakeParamOptions, getAvailableSlideSets, hierarchyParameters, noHierarchySlideSets, slideSetDefinitions, stubs, subCategorySlideSets;
    stubs = parseSlideSetDsl("SlideSet 1\n  Param 2 region SQL MULTISELECT true\n  Param 25 branch SQL MULTISELECT true\n  Repeating Slide 3 x2\n  Slide 4\n  Slide 5\nSlideSet 6\n  Param 2 region\n  Param 7 department SQL\n  Slide 8\n  Slide 9\nSlideSet 10\n  Param 2 region\n  Param 7 department\n  Slide 11");
    slideSetDefinitions = stubs.allSlideSetDefinitions;
    noHierarchySlideSets = [slideSetDefinitions[1]];
    categorySlideSets = [slideSetDefinitions[1], slideSetDefinitions[6]];
    subCategorySlideSets = [slideSetDefinitions[10]];
    fakeParamOptions = function(name) {
      return _.chain(_.range(1, 4)).map(function(i) {
        return "" + name + "-" + i;
      }).mapObject(function(x) {
        return [
          x, {
            desc: x,
            key: x
          }
        ];
      }).value();
    };
    expectUrlToMatch = function(matcher) {
      return function() {
        return (expect(matcher.test(location.href))).toBe(true);
      };
    };
    hierarchyParameters = [
      {
        Id: 1,
        Name: 'category',
        DisplayName: 'category',
        EvaluationType: 'SQL',
        Options: [
          {
            "Description": "category-1",
            "Key": "category-1",
            "ParentKey": null
          }, {
            "Description": "category-2",
            "Key": "category-2",
            "ParentKey": null
          }
        ],
        Prereqs: [],
        ParamType: 'SELECT',
        IsEvaluationTypeJson: false,
        IsEvaluationTypeSql: true
      }, {
        Id: 2,
        Name: 'subcategory',
        DisplayName: 'subcategory',
        EvaluationType: 'SQL',
        Options: [
          {
            "Description": "subcategory-1",
            "Key": "subcategory-1",
            "ParentKey": "category-1"
          }, {
            "Description": "subcategory-2",
            "Key": "subcategory-2",
            "ParentKey": "category-1"
          }, {
            "Description": "subcategory-3",
            "Key": "subcategory-3",
            "ParentKey": "category-2"
          }, {
            "Description": "subcategory-4",
            "Key": "subcategory-4",
            "ParentKey": "category-2"
          }
        ],
        Prereqs: ['category'],
        ParamType: 'SELECT',
        IsEvaluationTypeJson: false,
        IsEvaluationTypeSql: true
      }
    ];
    commonParameters = [];
    doActionAndWaitUntilSelectionsChangedEventFired = function(action, slideSetViewer, done) {
      var received, receiving, selectionSubscription, waiter;
      received = false;
      receiving = function() {
        return received = true;
      };
      selectionSubscription = slideSetViewer.hierarchyParameters.events.selectionsChanged.add(receiving);
      action();
      waiter = function() {
        if (received) {
          selectionSubscription.remove(received);
          return done();
        } else {
          return setTimeout(waiter, 50);
        }
      };
      return setTimeout(waiter, 50);
    };
    changeHierarchyParameterSelectionAndWaitUntilEventFired = function(hierarchyParameter, key, slideSetViewer, done) {
      var action;
      action = function() {
        return hierarchyParameter.setUserSelection(key);
      };
      return doActionAndWaitUntilSelectionsChangedEventFired(action, slideSetViewer, done);
    };
    changeHrefWithHierarchyParametersAndWaitUntilEventFired = function(href, slideSetViewer, done) {
      var action;
      action = function() {
        return location.href = href;
      };
      return doActionAndWaitUntilSelectionsChangedEventFired(action, slideSetViewer, done);
    };
    customMatchers = {
      toBeSameSlideSetsAs: function() {
        return {
          compare: function(actual, expected) {
            var show;
            actual = (_.pluck(actual, 'SlideSetId')).sort();
            expected = (_.pluck(expected, 'SlideSetId')).sort();
            show = function(arr) {
              if (arr) {
                return JSON.stringify(arr);
              } else {
                return '(null)';
              }
            };
            return {
              pass: _.isEqual(actual, expected),
              message: "Expected slidesets " + (show(expected)) + " but found " + (show(actual))
            };
          }
        };
      }
    };
    getAvailableSlideSets = function(viewer) {
      return _.flatten(_.pluck(viewer.groupedSlideSets(), 'matchedSlideSets'));
    };
    return describe("open slidesets viewer for Europe datamart with hierarchy parameters category,subcategory", function() {
      beforeEach(function(next) {
        var injector;
        jasmine.addMatchers(customMatchers);
        location.href = location.href.split('#/')[0] + '#/';
        this.fakeSlideSetInstances = _.mapObject(stubs.createSlideSetInstances(), function(ssi) {
          return [ssi.__slideSetDefinition.SlideSetId, ssi];
        });
        this.mocks = {
          "knockout-hashParamerterBinding": {
            bindToUrl: function() {},
            unbindFromUrl: function() {}
          },
          slideSetInstance: (function(_this) {
            return function(ssd) {
              return _this.fakeSlideSetInstances[ssd.SlideSetId];
            };
          })(this),
          apiUrls: {
            getSlideSetParamOptions: function(x) {
              return $.when((function() {
                switch (x.parameterId) {
                  case 2:
                    return {
                      Result: _.values(fakeParamOptions("region"))
                    };
                  case 7:
                    return {
                      Result: _.values(fakeParamOptions("department"))
                    };
                  case 25:
                    return {
                      Result: _.values(fakeParamOptions("branch"))
                    };
                }
              })());
            },
            availableSlideSetsDefinitionsFor: function(datamartId, selections) {
              return $.when((function() {
                switch (false) {
                  case !selections.subcategory:
                    return subCategorySlideSets;
                  case !selections.category:
                    return categorySlideSets;
                  case !true:
                    return noHierarchySlideSets;
                }
              })());
            },
            exportRenderedSlideSets: function() {
              return $.when(true);
            },
            renderSlideSetsInNewWindow: function() {
              return $.when(true);
            }
          }
        };
        _.visitObject(this.mocks, (function(_this) {
          return function(val, name, parent) {
            if (_.isFunction(val)) {
              return (spyOn(parent, name)).and.callThrough();
            }
          };
        })(this));
        injector = new Squire().mock(this.mocks);
        return injector.require(['slideSetsViewer2'], (function(_this) {
          return function(newSlideSetsViewer) {
            _this._slideSetsViewer = newSlideSetsViewer({
              Name: 'Europe',
              HierarchyParameters: {
                DatamartName: 'Europe',
                HierarchyParameters: hierarchyParameters
              },
              CommonParameters: {
                Name: 'Europe',
                CommonParameters: commonParameters
              }
            });
            _this.hierarchyParametersUi = _.mapObject(_this._slideSetsViewer.hierarchyParameters.params(), function(p) {
              return [p.Name(), p];
            });
            _this._currentSlideSetViewer = _this._slideSetsViewer.currentSlideSetViewer;
            return next();
          };
        })(this));
      });
      describe("with no hierarchy parameter selection", function() {
        it("fetches availableSlideSets for no hierarchy parameters", function() {
          return (expect(_.pluck(_.pluck(getAvailableSlideSets(this._slideSetsViewer), 'slideSetConfiguration'), 'slideSetDefinition'))).toBeSameSlideSetsAs(noHierarchySlideSets);
        });
        return describe("select category-1", function() {
          beforeEach(function(done) {
            return changeHierarchyParameterSelectionAndWaitUntilEventFired(this.hierarchyParametersUi['category'], 'category-1', this._slideSetsViewer, done);
          });
          it("url adjusts to #/category-1", expectUrlToMatch(/#\/category-1\/?/));
          it("exposes slidesets for category", function() {
            return (expect(_.pluck(_.pluck(getAvailableSlideSets(this._slideSetsViewer), 'slideSetConfiguration'), 'slideSetDefinition'))).toBeSameSlideSetsAs(categorySlideSets);
          });
          it("exposes a parametersContext for each slideset", function() {
            return _.each(_.pluck(getAvailableSlideSets(this._slideSetsViewer), 'parametersContext'), function(pc) {
              return (expect(pc)).not.toBe(null);
            });
          });
          describe("when the prameter context for the first slideset is fulfilled", function() {
            beforeEach(function() {
              var _ref;
              this.availableSlideSet = getAvailableSlideSets(this._slideSetsViewer)[0].slideSetConfiguration;
              _.each(this.availableSlideSet.parametersContext.parameters(), function(p) {
                if (p.IsStackingParameter) {
                  return p.selectedOptions(_.pluck(p.evaluatedValues(), 'key'));
                } else {
                  return p.userSelection(p.evaluatedValues()[0].key);
                }
              });
              getAvailableSlideSets(this._slideSetsViewer)[0].loadSlideSetInstance();
              return _ref = this._slideSetsViewer.openSlideSets(), this.slideSet = _ref[_ref.length - 1], _ref;
            });
            it("queries for the slideset instance with the hierarchy plus slideset parameters", function() {
              return (expect(_.any(this.mocks.slideSetInstance.calls.all(), (function(_this) {
                return function(x) {
                  var selections;
                  selections = x.args[1];
                  return x.args[0].SlideSetId === _this.slideSet.slideSetDefinition.SlideSetId && selections.category && selections.region;
                };
              })(this)))).toBe(true);
            });
            return describe("when slideset instance is loaded", function() {
              beforeEach(function() {
                return this.slideSet.slideSetInstance.loading.resolve();
              });
              it("current slideset is this slideset", function() {
                return (expect(this._currentSlideSetViewer.currentSlideSet())).toBe(this.slideSet);
              });
              it("current slide is the first slide of the slideset", function() {
                return (expect(this._currentSlideSetViewer.currentSlide())).toBe(this.slideSet.slideSetInstance.slides()[0]);
              });
              it("cannot move to a previous slide", function() {
                return (expect(this._currentSlideSetViewer.prevSlide())).toBe(null);
              });
              it("whole stack opens", function() {
                return (expect(this._slideSetsViewer.openSlideSets().length)).toBe(9);
              });
              describe("going to the next slide", function() {
                beforeEach(function() {
                  this._currentSlideSetViewer.nextSlide.evaluateImmediate();
                  this._currentSlideSetViewer.nextSlide()();
                  return this._currentSlideSetViewer.currentSlide.evaluateImmediate();
                });
                it("current slide is the next slide of the slideset", function() {
                  return (expect(this._currentSlideSetViewer.currentSlide())).toBe(this.slideSet.slideSetInstance.slides()[1]);
                });
                return describe("going to the previous slide", function() {
                  beforeEach(function() {
                    this._currentSlideSetViewer.prevSlide.evaluateImmediate();
                    this._currentSlideSetViewer.prevSlide()();
                    return this._currentSlideSetViewer.currentSlide.evaluateImmediate();
                  });
                  return it("current slide is the first slide of the slideset", function() {
                    return (expect(this._currentSlideSetViewer.currentSlide())).toBe(this.slideSet.slideSetInstance.slides()[0]);
                  });
                });
              });
              describe("without opened slidesets selection", function() {
                describe("export", function() {
                  beforeEach(function() {
                    return this.mocks.apiUrls.exportRenderedSlideSets.calls.reset();
                  });
                  describe("to pdf", function() {
                    beforeEach(function() {
                      return this._currentSlideSetViewer.exportSlideSetPdf();
                    });
                    return describe("exports", function() {
                      it("one slide set", function() {
                        return (expect(this.mocks.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].renderingParameters.length)).toBe(1);
                      });
                      it("have right report name", function() {
                        return (expect(this.mocks.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].renderingParameters[0].name.split(' - ').length)).toBe(1 + _.compact(this._slideSetsViewer.hierarchyParameters.allSelections()).length + _.compact(this._currentSlideSetViewer.currentSlideSet().slideSetDefinition.Params).length);
                      });
                      it("rendedering parameters has currentSlideSet id", function() {
                        return (expect(this.mocks.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].renderingParameters[0].slideSetId)).toBe(this._currentSlideSetViewer.currentSlideSet().slideSetDefinition.SlideSetId);
                      });
                      return it("with PDF or empty type", function() {
                        var m;
                        m = this.mocks;
                        return (expect(_.any(["", "Pdf"], function(t) {
                          return m.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].type;
                        }))).toBe(true);
                      });
                    });
                  });
                  return describe("to pptx", function() {
                    beforeEach(function() {
                      return this._currentSlideSetViewer.exportSlideSetPptx();
                    });
                    return describe("exports", function() {
                      it("one slide set", function() {
                        return (expect(this.mocks.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].renderingParameters.length)).toBe(1);
                      });
                      it("have right report name", function() {
                        return (expect(this.mocks.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].renderingParameters[0].name.split(' - ').length)).toBe(1 + _.compact(this._slideSetsViewer.hierarchyParameters.allSelections()).length + _.compact(this._currentSlideSetViewer.currentSlideSet().slideSetDefinition.Params).length);
                      });
                      it("rendedering parameters has currentSlideSet id", function() {
                        return (expect(this.mocks.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].renderingParameters[0].slideSetId)).toBe(this._currentSlideSetViewer.currentSlideSet().slideSetDefinition.SlideSetId);
                      });
                      return it("with Pptx type", function() {
                        return (expect(this.mocks.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].type)).toBe("Pptx");
                      });
                    });
                  });
                });
                return describe("print", function() {
                  beforeEach(function() {
                    this.mocks.apiUrls.renderSlideSetsInNewWindow.calls.reset();
                    return this._currentSlideSetViewer.printSlideSet();
                  });
                  it("one slide set", function() {
                    return (expect(this.mocks.apiUrls.renderSlideSetsInNewWindow.calls.mostRecent().args[0].renderingParameters.length)).toBe(1);
                  });
                  return it("rendering parameters has current slideset id", function() {
                    return (expect(this.mocks.apiUrls.renderSlideSetsInNewWindow.calls.mostRecent().args[0].renderingParameters[0].slideSetId)).toBe(this._currentSlideSetViewer.currentSlideSet().slideSetDefinition.SlideSetId);
                  });
                });
              });
              return describe("when open and load second slideset", function() {
                beforeEach(function() {
                  var _ref;
                  this.secondAvailableSlideSet = getAvailableSlideSets(this._slideSetsViewer)[1].slideSetConfiguration;
                  _.each(this.secondAvailableSlideSet.parametersContext.parameters(), function(p) {
                    if (p.IsStackingParameter) {
                      return p.selectedOptions(_.pluck(p.evaluatedValues(), 'key'));
                    } else {
                      return p.userSelection(p.evaluatedValues()[0].key);
                    }
                  });
                  getAvailableSlideSets(this._slideSetsViewer)[1].loadSlideSetInstance();
                  _ref = this._slideSetsViewer.openSlideSets(), this.slideSet2 = _ref[_ref.length - 1];
                  return this.slideSet2.slideSetInstance.loading.resolve();
                });
                describe("export", function() {
                  beforeEach(function() {
                    return this.mocks.apiUrls.exportRenderedSlideSets.calls.reset();
                  });
                  describe("to pdf", function() {
                    beforeEach(function() {
                      return this._currentSlideSetViewer.exportSlideSetPdf();
                    });
                    return describe("exports", function() {
                      it("one slide set", function() {
                        return (expect(this.mocks.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].renderingParameters.length)).toBe(1);
                      });
                      it("have right report name", function() {
                        return (expect(this.mocks.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].renderingParameters[0].name.split(' - ').length)).toBe(1 + _.compact(this._slideSetsViewer.hierarchyParameters.allSelections()).length + _.compact(this.secondAvailableSlideSet.slideSetDefinition.Params).length);
                      });
                      it("rendedering parameters has second slideset id", function() {
                        return (expect(this.mocks.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].renderingParameters[0].slideSetId)).toBe(this.secondAvailableSlideSet.slideSetDefinition.SlideSetId);
                      });
                      return it("with PDF or empty type", function() {
                        var m;
                        m = this.mocks;
                        return (expect(_.any(["", "Pdf"], function(t) {
                          return m.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].type;
                        }))).toBe(true);
                      });
                    });
                  });
                  return describe("to pptx", function() {
                    beforeEach(function() {
                      return this._currentSlideSetViewer.exportSlideSetPptx();
                    });
                    return describe("exports", function() {
                      it("one slide set", function() {
                        return (expect(this.mocks.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].renderingParameters.length)).toBe(1);
                      });
                      it("have right report name", function() {
                        return (expect(this.mocks.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].renderingParameters[0].name.split(' - ').length)).toBe(1 + _.compact(this._slideSetsViewer.hierarchyParameters.allSelections()).length + _.compact(this.secondAvailableSlideSet.slideSetDefinition.Params).length);
                      });
                      it("rendedering parameters has second slideset id", function() {
                        return (expect(this.mocks.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].renderingParameters[0].slideSetId)).toBe(this.secondAvailableSlideSet.slideSetDefinition.SlideSetId);
                      });
                      return it("with Pptx type", function() {
                        return (expect(this.mocks.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].type)).toBe("Pptx");
                      });
                    });
                  });
                });
                describe("print", function() {
                  beforeEach(function() {
                    this.mocks.apiUrls.renderSlideSetsInNewWindow.calls.reset();
                    return this._currentSlideSetViewer.printSlideSet();
                  });
                  it("one slide set", function() {
                    return (expect(this.mocks.apiUrls.renderSlideSetsInNewWindow.calls.mostRecent().args[0].renderingParameters.length)).toBe(1);
                  });
                  return it("rendering parameters has second slideset id", function() {
                    return (expect(this.mocks.apiUrls.renderSlideSetsInNewWindow.calls.mostRecent().args[0].renderingParameters[0].slideSetId)).toBe(this.secondAvailableSlideSet.slideSetDefinition.SlideSetId);
                  });
                });
                return describe("selecting first slideset", function() {
                  beforeEach(function() {
                    return this.slideSet.isSelected(true);
                  });
                  describe("export", function() {
                    beforeEach(function() {
                      return this.mocks.apiUrls.exportRenderedSlideSets.calls.reset();
                    });
                    describe("to pdf", function() {
                      beforeEach(function() {
                        return this._currentSlideSetViewer.exportSlideSetPdf();
                      });
                      return describe("exports", function() {
                        it("two slide sets", function() {
                          return (expect(this.mocks.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].renderingParameters.length)).toBe(2);
                        });
                        it("first have right report name", function() {
                          return (expect(this.mocks.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].renderingParameters[0].name.split(' - ').length)).toBe(1 + _.compact(this._slideSetsViewer.hierarchyParameters.allSelections()).length + _.compact(this.availableSlideSet.slideSetDefinition.Params).length);
                        });
                        it("second have right report name", function() {
                          return (expect(this.mocks.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].renderingParameters[1].name.split(' - ').length)).toBe(1 + _.compact(this._slideSetsViewer.hierarchyParameters.allSelections()).length + _.compact(this.secondAvailableSlideSet.slideSetDefinition.Params).length);
                        });
                        it("rendedering parameters has first slideset id", function() {
                          return (expect(this.mocks.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].renderingParameters[0].slideSetId)).toBe(this.availableSlideSet.slideSetDefinition.SlideSetId);
                        });
                        it("rendedering parameters has second slideset id", function() {
                          return (expect(this.mocks.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].renderingParameters[1].slideSetId)).toBe(this.secondAvailableSlideSet.slideSetDefinition.SlideSetId);
                        });
                        return it("with PDF or empty type", function() {
                          var m;
                          m = this.mocks;
                          return (expect(_.any(["", "Pdf"], function(t) {
                            return m.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].type;
                          }))).toBe(true);
                        });
                      });
                    });
                    return describe("to pptx", function() {
                      beforeEach(function() {
                        return this._currentSlideSetViewer.exportSlideSetPptx();
                      });
                      return describe("exports", function() {
                        it("two slide sets", function() {
                          return (expect(this.mocks.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].renderingParameters.length)).toBe(2);
                        });
                        it("first have right report name", function() {
                          return (expect(this.mocks.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].renderingParameters[0].name.split(' - ').length)).toBe(1 + _.compact(this._slideSetsViewer.hierarchyParameters.allSelections()).length + _.compact(this.availableSlideSet.slideSetDefinition.Params).length);
                        });
                        it("second have right report name", function() {
                          return (expect(this.mocks.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].renderingParameters[1].name.split(' - ').length)).toBe(1 + _.compact(this._slideSetsViewer.hierarchyParameters.allSelections()).length + _.compact(this.secondAvailableSlideSet.slideSetDefinition.Params).length);
                        });
                        it("rendedering parameters has first slideset id", function() {
                          return (expect(this.mocks.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].renderingParameters[0].slideSetId)).toBe(this.availableSlideSet.slideSetDefinition.SlideSetId);
                        });
                        it("rendedering parameters has second slideset id", function() {
                          return (expect(this.mocks.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].renderingParameters[1].slideSetId)).toBe(this.secondAvailableSlideSet.slideSetDefinition.SlideSetId);
                        });
                        return it("with Pptx type", function() {
                          return (expect(this.mocks.apiUrls.exportRenderedSlideSets.calls.mostRecent().args[0].type)).toBe("Pptx");
                        });
                      });
                    });
                  });
                  return describe("print", function() {
                    beforeEach(function() {
                      this.mocks.apiUrls.renderSlideSetsInNewWindow.calls.reset();
                      return this._currentSlideSetViewer.printSlideSet();
                    });
                    it("two slide sets", function() {
                      return (expect(this.mocks.apiUrls.renderSlideSetsInNewWindow.calls.mostRecent().args[0].renderingParameters.length)).toBe(2);
                    });
                    it("rendering parameters has first slideset id", function() {
                      return (expect(this.mocks.apiUrls.renderSlideSetsInNewWindow.calls.mostRecent().args[0].renderingParameters[0].slideSetId)).toBe(this.availableSlideSet.slideSetDefinition.SlideSetId);
                    });
                    return it("rendering parameters has second slideset id", function() {
                      return (expect(this.mocks.apiUrls.renderSlideSetsInNewWindow.calls.mostRecent().args[0].renderingParameters[1].slideSetId)).toBe(this.secondAvailableSlideSet.slideSetDefinition.SlideSetId);
                    });
                  });
                });
              });
            });
          });
          describe("select subcategory-2", function() {
            beforeEach(function(done) {
              return changeHierarchyParameterSelectionAndWaitUntilEventFired(this.hierarchyParametersUi['subcategory'], 'subcategory-2', this._slideSetsViewer, done);
            });
            it("url adjusts to #/category-1/subcategory-2", expectUrlToMatch(/#\/category-1\/subcategory-2\/?/));
            return it("fetches slidesets for subcategory", function() {
              return (this.mocks.apiUrls.availableSlideSetsDefinitionsFor('Europe', {
                category: 'category-1',
                subcategory: 'subcategory-2'
              })).then((function(_this) {
                return function(slideSets) {
                  return (expect(_.pluck(_.pluck(getAvailableSlideSets(_this._slideSetsViewer), 'slideSetConfiguration'), 'slideSetDefinition'))).toBeSameSlideSetsAs(slideSets);
                };
              })(this));
            });
          });
          return describe("select category-2", function() {
            beforeEach(function(done) {
              return changeHierarchyParameterSelectionAndWaitUntilEventFired(this.hierarchyParametersUi['category'], 'category-2', this._slideSetsViewer, done);
            });
            it("url adjusts to #/category-2", expectUrlToMatch(/#\/category-2\/?/));
            return describe("select subcategory-3", function() {
              beforeEach(function(done) {
                return changeHierarchyParameterSelectionAndWaitUntilEventFired(this.hierarchyParametersUi['subcategory'], 'subcategory-3', this._slideSetsViewer, done);
              });
              return it("url adjusts to #/category-2/subcategory-3", expectUrlToMatch(/#\/category-2\/subcategory-3\/?/));
            });
          });
        });
      });
      return describe("with url #/category-2/subcategory-3", function() {
        beforeEach(function(done) {
          return changeHrefWithHierarchyParametersAndWaitUntilEventFired(location.href.split('#/')[0] + '#/category-2/subcategory-3', this._slideSetsViewer, done);
        });
        it("category-2 is selected", function() {
          return (expect(this.hierarchyParametersUi['category'].userSelection().Key)).toBe('category-2');
        });
        return it("subcategory-3 is selected", function() {
          return (expect(this.hierarchyParametersUi['subcategory'].userSelection().Key)).toBe('subcategory-3');
        });
      });
    });
  });

}).call(this);
