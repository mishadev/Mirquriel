﻿(function() {
  define(['jquery', 'underscore', 'knockout', 'slideResizer'], function($, _, ko, slideResizer) {
    return describe("slideResizer tests:", function() {
      var customCfg, defaultCfg;
      defaultCfg = {
        sizeOptions: _.map(_.range(0, 10), function(x) {
          return (x + 1) / 10;
        }),
        size: .8,
        consts: {
          height: 750,
          width: 1050
        }
      };
      customCfg = {
        sizeOptions: _.map(_.range(0, 6), function(x) {
          return (x + 1) / 10;
        }),
        size: .3
      };
      return describe("when initializing the module", function() {
        describe("with configured values", function() {
          return it("it inited with configured values", function() {
            var resizer;
            resizer = slideResizer(customCfg);
            (expect(resizer.slideSize())).toBe(customCfg.size);
            return (expect(resizer.slideSizeOptions())).toEqual(customCfg.sizeOptions);
          });
        });
        return describe("with default values", function() {
          beforeEach(function() {
            return this.resizer = slideResizer();
          });
          it("it has observables on his state", function() {
            (expect(ko.isObservable(this.resizer.slideSize))).toBeTruthy();
            return (expect(ko.isObservable(this.resizer.slideSizeOptions))).toBeTruthy();
          });
          it("it inited with default values", function() {
            (expect(this.resizer.slideSize())).toBe(defaultCfg.size);
            return (expect(this.resizer.slideSizeOptions())).toEqual(defaultCfg.sizeOptions);
          });
          describe("and use slideSize function", function() {
            describe("for size that not exists in options", function() {
              var val;
              val = .15;
              beforeEach(function() {
                this.resizer = slideResizer();
                return this.resizer.slideSize(val);
              });
              it("it creates an option in right order", function() {
                return (expect(this.resizer.slideSizeOptions())).toEqual((_.union(defaultCfg.sizeOptions, [val])).sort());
              });
              return it("it changes observable", function() {
                return (expect(this.resizer.slideSize())).toBe(val);
              });
            });
            return describe("for size that exists in options", function() {
              var val;
              val = defaultCfg.sizeOptions[5];
              beforeEach(function() {
                this.resizer = slideResizer();
                return this.resizer.slideSize(val);
              });
              return it("it use existing option", function() {
                (expect(this.resizer.slideSizeOptions())).toEqual(defaultCfg.sizeOptions);
                return (expect(this.resizer.slideSize())).toBe(val);
              });
            });
          });
          describe("and use changeSizeToFitElement function", function() {
            beforeEach(function() {
              this.$div = $('<div>').appendTo('body').width(1920).height(1080).addClass('HD');
              return this.resizer = slideResizer();
            });
            afterEach(function() {
              return this.$div.remove();
            });
            it("it creates an option from element", function() {
              this.resizer.changeSizeToFitElement(this.$div[0]);
              (expect(this.resizer.slideSizeOptions().length)).toBe(defaultCfg.sizeOptions.length + 1);
              return (expect(this.resizer.slideSize())).toBe(this.$div.height() / defaultCfg.consts.height);
            });
            return it("it creates an option from selector", function() {
              this.resizer.changeSizeToFitElement('.HD');
              (expect(this.resizer.slideSizeOptions().length)).toBe(defaultCfg.sizeOptions.length + 1);
              return (expect(this.resizer.slideSize())).toBe(this.$div.height() / defaultCfg.consts.height);
            });
          });
          return describe("and use changeOptionToFitElement function", function() {
            beforeEach(function() {
              this.$div = $('<div>').appendTo('body').width(1920).height(1080).addClass('HD');
              return this.resizer = slideResizer();
            });
            afterEach(function() {
              return this.$div.remove();
            });
            it("it select an option to fit element", function() {
              this.resizer.changeOptionToFitElement(this.$div[0]);
              (expect(this.resizer.slideSizeOptions())).toEqual(defaultCfg.sizeOptions);
              return (expect(this.resizer.slideSize())).toBe(_.last(this.resizer.slideSizeOptions()));
            });
            return it("it select an option to fit element by selector with padding", function() {
              var paddingPercent;
              paddingPercent = 50;
              this.resizer.changeOptionToFitElement('.HD', paddingPercent);
              (expect(this.resizer.slideSizeOptions())).toEqual(defaultCfg.sizeOptions);
              return (expect(this.resizer.slideSize())).toBe((Math.floor((this.$div.height() / defaultCfg.consts.height - paddingPercent / 100) * 10)) / 10);
            });
          });
        });
      });
    });
  });

}).call(this);

//# sourceMappingURL=slideResizer.specs.js.map
