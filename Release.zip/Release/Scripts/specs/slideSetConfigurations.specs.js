﻿(function() {
  define(['jasmine', 'underscore', 'specs/helpers/parseSlideSetDsl', 'slideSetConfiguration', 'commonParametersContext'], function(jasmine, _, parseSlideSetDsl, slideSetConfiguration, commonParametersContext) {
    return describe("Given slide set with existing parameters is created", function() {
      var commonContext, commonParametersModel, getParameterByName, someOptions, ssn;
      someOptions = _.map(['one', 'two', 'three'], function(x) {
        return {
          key: x,
          desc: x
        };
      });
      ssn = parseSlideSetDsl("SlideSet 1\n	Slide 2\n	Param 1 select JSON SELECT\n	Param 2 multiselect JSON MULTISELECT\n	Param 3 text NONE TEXT\n	Param 4 check_json JSON CHECKBOX");
      ssn.allParameters[1].EvaluationSource = JSON.stringify(someOptions);
      ssn.allParameters[2].EvaluationSource = JSON.stringify(someOptions);
      ssn.allParameters[4].EvaluationSource = JSON.stringify([someOptions[0], someOptions[1]]);
      commonParametersModel = {
        CommonParameters: [
          {
            Id: 1,
            Parameter: ssn.allParameters[1]
          }, {
            Id: 2,
            Parameter: ssn.allParameters[2]
          }, {
            Id: 3,
            Parameter: ssn.allParameters[3]
          }, {
            Id: 4,
            Parameter: ssn.allParameters[4]
          }
        ]
      };
      commonContext = commonParametersContext(commonParametersModel);
      getParameterByName = function(name, params) {
        return _.findBy(params, name, 'Name');
      };
      return describe("creates slideset configuration from slideset", function() {
        var checkJsonCommonParameter, checkJsonSlideSetParameter, commonParams, configuration, multiselectCommonParameter, multiselectSlideSetParameter, selectCommonParameter, selectSlideSetParameter, slidesetParams, textCommonParameter, textSlideSetParameter;
        configuration = slideSetConfiguration(ssn.allSlideSetDefinitions[1], function() {});
        commonParams = commonContext.parameters();
        slidesetParams = configuration.parametersContext.parameters();
        selectCommonParameter = getParameterByName('select', commonParams);
        multiselectCommonParameter = getParameterByName('multiselect', commonParams);
        textCommonParameter = getParameterByName('text', commonParams);
        checkJsonCommonParameter = getParameterByName('check_json', commonParams);
        selectSlideSetParameter = getParameterByName('select', slidesetParams);
        multiselectSlideSetParameter = getParameterByName('multiselect', slidesetParams);
        textSlideSetParameter = getParameterByName('text', slidesetParams);
        checkJsonSlideSetParameter = getParameterByName('check_json', slidesetParams);
        commonContext.subscribeOnUserSelectionsChanged(function(p) {
          return configuration.deserializeParameterWithName(p.Name(), p.serializeUserSelection());
        });
        describe("expects SELECT typed parameter in context", function() {
          beforeEach(function() {
            return selectCommonParameter.userSelection(null);
          });
          it("to be selected if commonParameter is selected", function() {
            selectCommonParameter.userSelection(someOptions[0]);
            return (expect(selectSlideSetParameter.userSelection())).toEqual(someOptions[0]);
          });
          it("to be selected then to be unselected if commonParameter selected then unselected", function() {
            selectCommonParameter.userSelection(someOptions[0]);
            (expect(selectSlideSetParameter.userSelection())).toEqual(someOptions[0]);
            selectCommonParameter.userSelection(void 0);
            return (expect(selectSlideSetParameter.userSelection())).toBeUndefined();
          });
          it("to be selected then to be unselected if commonParameter second selection dose not exist", function() {
            selectCommonParameter.userSelection(someOptions[0]);
            (expect(selectSlideSetParameter.userSelection())).toEqual(someOptions[0]);
            selectCommonParameter.userSelection({
              key: '100500',
              value: 'misha'
            });
            return (expect(selectSlideSetParameter.userSelection())).toBeUndefined();
          });
          return it("to be selected then to be unselected if commonParameter second selection is not valid", function() {
            selectCommonParameter.userSelection(someOptions[0]);
            (expect(selectSlideSetParameter.userSelection())).toEqual(someOptions[0]);
            selectCommonParameter.userSelection({
              radius: '100500'
            });
            return (expect(selectSlideSetParameter.userSelection())).toBeUndefined();
          });
        });
        describe("expects TEXT typed parameter in context", function() {
          it("to be selected if commonParameter is selected", function() {
            textCommonParameter.userSelection(someOptions[0].key);
            return (expect(textSlideSetParameter.userSelection())).toBe(someOptions[0].key);
          });
          return it("to be selected then to be unselected if commonParameter selected then unselected", function() {
            textCommonParameter.userSelection(someOptions[0].key);
            (expect(textSlideSetParameter.userSelection())).toBe(someOptions[0].key);
            textCommonParameter.userSelection(void 0);
            return (expect(textSlideSetParameter.userSelection())).toBeUndefined();
          });
        });
        it("expects CHECKBOX typed parameter in context to be selected if commonParameter is selected couple times", function() {
          checkJsonCommonParameter.userCheckboxSelection(true);
          (expect(checkJsonSlideSetParameter.userSelection())).toEqual(someOptions[1]);
          checkJsonCommonParameter.userCheckboxSelection(false);
          return (expect(checkJsonSlideSetParameter.userSelection())).toEqual(someOptions[0]);
        });
        return describe("expects MULTISELECT typed parameter in context", function() {
          beforeEach(function(done) {
            multiselectSlideSetParameter.selectedOptions.subscribe(done);
            return multiselectCommonParameter.selectedOptions([someOptions[0].key, someOptions[2].key]);
          });
          return it("to be selected then to be unselected if commonParameter selected then unselected", function(done) {
            return _.defer(function() {
              multiselectSlideSetParameter.selectedOptions.subscribe(function() {
                (expect(multiselectSlideSetParameter.selectedOptions())).toEqual([]);
                return done();
              });
              return multiselectCommonParameter.selectedOptions([]);
            });
          });
        });
      });
    });
  });

}).call(this);
