﻿(function() {
  define(['jasmine', 'underscore', 'jquery', 'knockout', 'asyncComputed'], function(jasmine, _, $, ko, asyncComputed) {
    function eq(a, b) { return a == b };
    return describe("async computed which returns a promise", function() {
      var assertState;
      beforeEach(function() {
        var recalcTrigger;
        this.def = null;
        recalcTrigger = ko.observable(true);
        this.forceRecalc = function() {
          return recalcTrigger(!recalcTrigger());
        };
        return this.asyncComputed = asyncComputed((function(_this) {
          return function() {
            var dummy;
            dummy = recalcTrigger();
            _this.def = $.Deferred();
            return _this.def;
          };
        })(this));
      });
      assertState = function(value, error, state) {
        it((value != null ? "has value '" + value + "'" : "has no value"), function() {
          return (expect(eq(this.asyncComputed(), value))).toBe(true);
        });
        it((error != null ? "has error '" + error + "'" : "has no error"), function() {
          return (expect(eq(this.asyncComputed.error(), error))).toBe(true);
        });
        if (state != null) {
          return it("is " + state, function() {
            return (expect(this.asyncComputed.state())).toBe(state);
          });
        }
      };
      assertState(null, null, 'pending');
      describe("which is resolved", function() {
        beforeEach(function() {
          return this.def.resolve(5);
        });
        return assertState(5, null, 'resolved');
      });
      return describe("which is rejected", function() {
        beforeEach(function() {
          return this.def.reject("uh-oh");
        });
        assertState(null, "uh-oh", 'rejected');
        return describe("and a dependency triggers recalculation", function() {
          beforeEach(function() {
            return this.forceRecalc();
          });
          assertState(null, null, 'pending');
          return describe("it is resolved", function() {
            beforeEach(function() {
              return this.def.resolve(2);
            });
            return assertState(2, null, 'resolved');
          });
        });
      });
    });
  });

}).call(this);
