define(
[],
function() {
return {
  "slideDefinition": {
    "SlideId": 17,
    "SlideSetId": 5,
    "CreatedBy": "current user",
    "CreatedOn": "2013-02-15T16:08:04.49",
    "LastModifiedBy": "current user",
    "LastModifiedOn": "2013-02-20T13:46:54.267",
    "ETag": "B0848C3DC81238C844C6C48791CE5E6F",
    "Links": {},
    "Name": "v8 slide 5",
    "Description": "",
    "Ordering": 2,
    "Thumbnail": "<link href=\"/Content/nv.d3.css\" rel=\"stylesheet\" type=\"text/css\"><style>* {\n  box-sizing: border-box;\n  -moz-box-sizing: border-box; }\n\nbody {\n  background-color: #fff; }\n\n[data-editable=true].marked {\n  background-color: #aaf; }\n\nsvg text[data-editable=true].marked {\n  filter: url(#svg-editable-text-highlight); }\n</style><style>body {\n    font-family: Arial;\n}\n\n.header, .footer {\n    background-color: #EEE;\n    padding: 0.2em;\n    margin: 0;\n}\n.footer {\n    position: absolute;\n    bottom: 10px; \n    right: 10px;\n    left: 10px;\n}\n.header em {\n    font-weight: bold; \n    font-style: normal;\n    font-size: 1.5em;\n}\n\n.table-container { \n    padding: 10px;\n}\ntable {\n    width: 100%;\n    border-collapse: collapse;\n    font-size: 70%;\n}\ntr:not(.header-row){\n    font-size: 100%;\n}\ntd {\n    vertical-align: middle;\n    padding: .5em .3em; \n}\ntr:nth-child(odd) {\n  background-color: #eee;    \n}    \ntr.sub-header-row {\n    font-weight: bold;\n}\ntr.header-row {\n    font-weight: bold;\n    color: #38BDB2;\n    font-size: 2em;\n    background-color: transparent;\n}\n\n.pct:after { content: \"%\"; }\n.neg { color: red; }\n.neg:before { content: \"(\"; }\n.neg:after { content: \")\"; }\ntr.spacer { height: 1em; }</style>\n    \n    <svg style=\"width:0px; height:0px; overflow:hidden;\">\n      <filter id=\"svg-editable-text-highlight\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n       <feFlood flood-color=\"#aaf\"></feFlood>\n       <feComposite in=\"SourceGraphic\"></feComposite>\n     </filter>\n   </svg>\n<p class=\"header\"><em>P&amp;L</em><span class=\"marked\" data-editablelabel=\"Slide Name\" data-editable=\"true\">Key metrics by region</span></p><div class=\"table-container\"><table><tr class=\"header-row\"><td></td><td colspan=\"6\">Net Sales ($)</td><td colspan=\"6\">Gross Margins ($)</td><td colspan=\"6\">Gross Margins (%)</td></tr><tr class=\"sub-header-row\"><td>Shop</td><td>45415</td><td>45417</td><td>45425</td><td>45433</td><td>45439</td><td>45441</td><td>45415</td><td>45417</td><td>45425</td><td>45433</td><td>45439</td><td>45441</td><td>45415</td><td>45417</td><td>45425</td><td>45433</td><td>45439</td><td>45441</td></tr><tr><td>BAKERY</td><td><span class=\"\">50747</span></td><td><span class=\"neg\">32140</span></td><td><span class=\"\">8618</span></td><td><span class=\"\">449332</span></td><td><span class=\"neg\">6990</span></td><td><span class=\"\">311106</span></td><td><span class=\"neg\">69758</span></td><td><span class=\"\">43208</span></td><td><span class=\"\">142057</span></td><td><span class=\"\">516552</span></td><td><span class=\"\">180435</span></td><td><span class=\"\">231032</span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td></tr><tr><td>COFFEE SHOP</td><td><span class=\"\">2392</span></td><td><span class=\"neg\">3631</span></td><td><span class=\"neg\">6</span></td><td><span class=\"neg\">10</span></td><td><span class=\"\">31108</span></td><td><span class=\"\">44013</span></td><td><span class=\"neg\">944</span></td><td><span class=\"neg\">6784</span></td><td><span class=\"\">0</span></td><td><span class=\"\">0</span></td><td><span class=\"\">68544</span></td><td><span class=\"\">22028</span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td></tr><tr><td>DAIRY</td><td><span class=\"\">362571</span></td><td><span class=\"neg\">75594</span></td><td><span class=\"\">122405</span></td><td><span class=\"neg\">232008</span></td><td><span class=\"neg\">182147</span></td><td><span class=\"neg\">204559</span></td><td><span class=\"neg\">1126512</span></td><td><span class=\"\">75857</span></td><td><span class=\"neg\">164739</span></td><td><span class=\"neg\">484618</span></td><td><span class=\"neg\">172727</span></td><td><span class=\"neg\">1294265</span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td></tr><tr><td>DELI</td><td><span class=\"\">163258</span></td><td><span class=\"neg\">128065</span></td><td><span class=\"neg\">71683</span></td><td><span class=\"neg\">349879</span></td><td><span class=\"\">89725</span></td><td><span class=\"\">129320</span></td><td><span class=\"neg\">7705</span></td><td><span class=\"neg\">23980</span></td><td><span class=\"\">12192</span></td><td><span class=\"neg\">472522</span></td><td><span class=\"\">630721</span></td><td><span class=\"\">398581</span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td></tr><tr><td>FLORAL</td><td><span class=\"\">235377</span></td><td><span class=\"neg\">5696</span></td><td><span class=\"\">164809</span></td><td><span class=\"\">58572</span></td><td><span class=\"\">402889</span></td><td><span class=\"\">478276</span></td><td><span class=\"neg\">259183</span></td><td><span class=\"\">0</span></td><td><span class=\"neg\">187530</span></td><td><span class=\"neg\">2615108</span></td><td><span class=\"neg\">82762</span></td><td><span class=\"neg\">723203</span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"neg\">1</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td></tr><tr><td>FOOD</td><td><span class=\"neg\">816851</span></td><td><span class=\"\">10985</span></td><td><span class=\"neg\">449468</span></td><td><span class=\"neg\">453028</span></td><td><span class=\"neg\">38907</span></td><td><span class=\"\">169592</span></td><td><span class=\"\">481561</span></td><td><span class=\"neg\">610683</span></td><td><span class=\"\">1042543</span></td><td><span class=\"neg\">2714483</span></td><td><span class=\"neg\">223711</span></td><td><span class=\"\">1182689</span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td></tr><tr><td>FROZEN FOODS</td><td><span class=\"\">64299</span></td><td><span class=\"neg\">105021</span></td><td><span class=\"neg\">134557</span></td><td><span class=\"\">189520</span></td><td><span class=\"\">150329</span></td><td><span class=\"\">408372</span></td><td><span class=\"\">187374</span></td><td><span class=\"neg\">263814</span></td><td><span class=\"neg\">151853</span></td><td><span class=\"neg\">1431812</span></td><td><span class=\"\">263423</span></td><td><span class=\"\">1421833</span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td></tr><tr><td>GROCERY BEVERAGE</td><td><span class=\"neg\">205025</span></td><td><span class=\"\">121612</span></td><td><span class=\"\">136077</span></td><td><span class=\"\">472544</span></td><td><span class=\"neg\">621374</span></td><td><span class=\"neg\">1564296</span></td><td><span class=\"neg\">412495</span></td><td><span class=\"neg\">405548</span></td><td><span class=\"neg\">287796</span></td><td><span class=\"\">1139823</span></td><td><span class=\"\">352688</span></td><td><span class=\"\">1205491</span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td></tr><tr><td>MEAT</td><td><span class=\"\">706218</span></td><td><span class=\"\">110194</span></td><td><span class=\"\">52831</span></td><td><span class=\"\">1019694</span></td><td><span class=\"\">1653005</span></td><td><span class=\"\">1103308</span></td><td><span class=\"neg\">6605</span></td><td><span class=\"neg\">163542</span></td><td><span class=\"neg\">105633</span></td><td><span class=\"\">3317434</span></td><td><span class=\"neg\">460947</span></td><td><span class=\"neg\">2515565</span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td></tr><tr><td>NON FOODS</td><td><span class=\"neg\">760543</span></td><td><span class=\"neg\">276552</span></td><td><span class=\"neg\">386402</span></td><td><span class=\"\">241050</span></td><td><span class=\"neg\">352818</span></td><td><span class=\"neg\">223375</span></td><td><span class=\"neg\">154006</span></td><td><span class=\"neg\">273801</span></td><td><span class=\"\">371639</span></td><td><span class=\"neg\">1493999</span></td><td><span class=\"neg\">1293902</span></td><td><span class=\"\">75156</span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td></tr><tr><td>PHOTO &amp; PHONE CARDS</td><td><span class=\"\">2588</span></td><td><span class=\"\">1560</span></td><td><span class=\"\">1303</span></td><td><span class=\"\">24595</span></td><td><span class=\"neg\">30222</span></td><td><span class=\"\">5977</span></td><td><span class=\"neg\">25445</span></td><td><span class=\"neg\">1141</span></td><td><span class=\"neg\">7156</span></td><td><span class=\"neg\">44213</span></td><td><span class=\"neg\">39684</span></td><td><span class=\"\">5904</span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td></tr><tr><td>PRE-PACK MEAT</td><td><span class=\"neg\">213930</span></td><td><span class=\"\">27666</span></td><td><span class=\"neg\">150815</span></td><td><span class=\"neg\">48390</span></td><td><span class=\"neg\">21778</span></td><td><span class=\"neg\">270367</span></td><td><span class=\"\">218089</span></td><td><span class=\"neg\">97179</span></td><td><span class=\"\">114707</span></td><td><span class=\"\">20346</span></td><td><span class=\"neg\">104074</span></td><td><span class=\"\">633718</span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td></tr><tr><td>PRODUCE</td><td><span class=\"neg\">218166</span></td><td><span class=\"neg\">60284</span></td><td><span class=\"neg\">487302</span></td><td><span class=\"neg\">673210</span></td><td><span class=\"\">875886</span></td><td><span class=\"neg\">689199</span></td><td><span class=\"neg\">133730</span></td><td><span class=\"neg\">302997</span></td><td><span class=\"neg\">102758</span></td><td><span class=\"\">943026</span></td><td><span class=\"\">137303</span></td><td><span class=\"\">1679904</span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td></tr><tr><td>TOTAL ALCOHOL BEVERAGE</td><td><span class=\"\">2525</span></td><td><span class=\"neg\">161569</span></td><td><span class=\"neg\">72279</span></td><td><span class=\"neg\">1147786</span></td><td><span class=\"neg\">1101306</span></td><td><span class=\"\">380948</span></td><td><span class=\"neg\">42211</span></td><td><span class=\"\">15915</span></td><td><span class=\"\">110345</span></td><td><span class=\"neg\">1143060</span></td><td><span class=\"\">125818</span></td><td><span class=\"neg\">1576486</span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td></tr><tr><td>UNKNOWN SHOP</td><td><span class=\"\">28698</span></td><td><span class=\"neg\">101</span></td><td><span class=\"\">3465</span></td><td><span class=\"\">15061</span></td><td><span class=\"\">2794</span></td><td><span class=\"\">20638</span></td><td><span class=\"neg\">32124</span></td><td><span class=\"\">0</span></td><td><span class=\"neg\">106478</span></td><td><span class=\"neg\">105159</span></td><td><span class=\"\">21737</span></td><td><span class=\"neg\">68432</span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"neg\">1</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td><td><span class=\"pct\"><span class=\"\">0</span></span></td></tr></table></div>",
    "LayoutCode": "var  totals     = _.last(d.chart)\n    ,data       = _.initial(d.chart)\n    ,regionData = _.groupBy(data, 'region')\n    ,regions    = _.keys(regionData)\n    ; \n///////////////////////////////////////////\n// Helpers\n///////////////////////////////////////////\n\nfunction round(pts) {\n    var t = Math.pow(10,pts||0);\n    return function (x) { return Math.round(x*t)/t;};\n}\nfunction asPercentage(v) {\n    return '<span class=pct>'+v+'</span>';\n}\nfunction accountingNegative(v) {\n    return '<span class='+(v<0?'neg':'')+'>'+Math.abs(v)+'</span>';\n}\nfunction prepend(val, arr) {\n    arr.unshift(val);\n    return arr;\n}\nfunction pluck(prop) { return function(d) { return d[prop]; }; }\n\n///////////////////////////////////////////\n// Slide Header\n///////////////////////////////////////////\nvar slideHeader = s.append('p').classed('header', true);\nslideHeader.append('em').text(\"P&L\");\no.editableText(slideHeader, \"Slide Name\").text(\"Key metrics by region\");\n\n///////////////////////////////////////////\n// Table\n///////////////////////////////////////////\nvar  table = s.append('div').classed('table-container', true).append('table')\n    ,categories = [\n        {\n             prop: \"FCPlanNetSalesVariance\", text: \"Net Sales ($)\"\n            ,format: _.compose(accountingNegative, round(2))\n        }, {\n            prop: \"FCPlanGrossMarginVariance\", text: \"Gross Margins ($)\"\n            ,format: _.compose(accountingNegative, round(2))\n        }, {\n            prop: \"FCPlanGrossMarginPercentageVariance\", text: \"Gross Margins (%)\"\n            ,format: _.compose(asPercentage, accountingNegative, Math.round)\n        }\n    ]\n    ,departmentData = _.groupBy(data, 'department')\n    ,headerData = prepend(\"Shop\", _.flatten(_.map(categories, function(){return _.keys(regionData);})) )\n    ,tableData = _.map(departmentData, function(data,department) {\n        var  expandedToRegion = _.map(regions, function(r) {\n                return _.find(data, function(d) { return d.region === r; })||null;\n            })\n            ,regionsAllCategories = _.flatten(_.map(categories, function(c){\n                var res = _.map(expandedToRegion, function pluckCategoryProp(x){\n                    return {data: c.format(x[c.prop]) };\n                });                \n                if(_.first(res)) {\n                    _.first(res).tag += \"category-start\";\n                    _.last(res).tag += \"category-end\";\n                }\n                return res;\n            }))\n            ;        \n        return prepend({data: department, tag: \"department\"} , regionsAllCategories);\n    })\n    ;\nfunction row() { return table.append('tr'); }\nvar headerRow = row().classed('header-row', true); \nheaderRow.append('td');  //department name\nheaderRow.selectAll()\n    .data(categories).enter() \n    .append('td').attr('colspan', String(regions.length)).text(pluck('text')); \n\nvar headerRow2 = row().classed('sub-header-row', true);\nheaderRow2.selectAll()\n    .data(headerData).enter()\n    .append('td').text(_.identity);\n\n_.each(tableData, function(data) {\n    row().selectAll()\n        .data(data).enter()\n        .append('td').html(pluck('data'));\n});",
    "StyleCode": "body {\n    font-family: Arial;\n}\n\n.header, .footer {\n    background-color: #EEE;\n    padding: 0.2em;\n    margin: 0;\n}\n.footer {\n    position: absolute;\n    bottom: 10px; \n    right: 10px;\n    left: 10px;\n}\n.header em {\n    font-weight: bold; \n    font-style: normal;\n    font-size: 1.5em;\n}\n\n.table-container { \n    padding: 10px;\n}\ntable {\n    width: 100%;\n    border-collapse: collapse;\n    font-size: 70%;\n}\ntr:not(.header-row){\n    font-size: 100%;\n}\ntd {\n    vertical-align: middle;\n    padding: .5em .3em; \n}\ntr:nth-child(odd) {\n  background-color: #eee;    \n}    \ntr.sub-header-row {\n    font-weight: bold;\n}\ntr.header-row {\n    font-weight: bold;\n    color: #38BDB2;\n    font-size: 2em;\n    background-color: transparent;\n}\n\n.pct:after { content: \"%\"; }\n.neg { color: red; }\n.neg:before { content: \"(\"; }\n.neg:after { content: \")\"; }\ntr.spacer { height: 1em; }",
    "SqlCode": "chart:\nEXEC SPVMM.pmt.spGet_PL_LEVEL_PlanFCByRegion\n    @startDate        = @fromDate,\n    @endDate          = @toDate,\n    @dimension        = 'DEPARTMENT'"
  },
  "parameters": {"fromDate":"03/01/2012","toDate":"04/01/2012","fromDateDesc":"03/01/2012","toDateDesc":"04/01/2012"},
  "data": {
    "chart": [
      {
        "region": "45415",
        "department": "BAKERY",
        "FCPlanNetSalesVariance": "50747",
        "FCPlanGrossMarginVariance": "-69758",
        "FCPlanGrossMarginPercentageVariance": "-0.0169048261231646"
      },
      {
        "region": "45415",
        "department": "COFFEE SHOP",
        "FCPlanNetSalesVariance": "2392",
        "FCPlanGrossMarginVariance": "-944",
        "FCPlanGrossMarginPercentageVariance": "-0.0446082622596867"
      },
      {
        "region": "45415",
        "department": "DAIRY",
        "FCPlanNetSalesVariance": "362571",
        "FCPlanGrossMarginVariance": "-1126512",
        "FCPlanGrossMarginPercentageVariance": "-0.0547047266301415"
      },
      {
        "region": "45415",
        "department": "DELI",
        "FCPlanNetSalesVariance": "163258",
        "FCPlanGrossMarginVariance": "-7705",
        "FCPlanGrossMarginPercentageVariance": "-0.00723601869253998"
      },
      {
        "region": "45415",
        "department": "FLORAL",
        "FCPlanNetSalesVariance": "235377",
        "FCPlanGrossMarginVariance": "-259183",
        "FCPlanGrossMarginPercentageVariance": "-0.353946738945125"
      },
      {
        "region": "45415",
        "department": "FOOD",
        "FCPlanNetSalesVariance": "-816851",
        "FCPlanGrossMarginVariance": "481561",
        "FCPlanGrossMarginPercentageVariance": "0.0179027230348914"
      },
      {
        "region": "45415",
        "department": "FROZEN FOODS",
        "FCPlanNetSalesVariance": "64299",
        "FCPlanGrossMarginVariance": "187374",
        "FCPlanGrossMarginPercentageVariance": "0.0110015304237412"
      },
      {
        "region": "45415",
        "department": "GROCERY BEVERAGE",
        "FCPlanNetSalesVariance": "-205025",
        "FCPlanGrossMarginVariance": "-412495",
        "FCPlanGrossMarginPercentageVariance": "-0.014132527072193"
      },
      {
        "region": "45415",
        "department": "MEAT",
        "FCPlanNetSalesVariance": "706218",
        "FCPlanGrossMarginVariance": "-6605",
        "FCPlanGrossMarginPercentageVariance": "-0.0129316906923768"
      },
      {
        "region": "45415",
        "department": "NON FOODS",
        "FCPlanNetSalesVariance": "-760543",
        "FCPlanGrossMarginVariance": "-154006",
        "FCPlanGrossMarginPercentageVariance": "0.00329755350096089"
      },
      {
        "region": "45415",
        "department": "PHOTO & PHONE CARDS",
        "FCPlanNetSalesVariance": "2588",
        "FCPlanGrossMarginVariance": "-25445",
        "FCPlanGrossMarginPercentageVariance": "-0.0260676086720909"
      },
      {
        "region": "45415",
        "department": "PRE-PACK MEAT",
        "FCPlanNetSalesVariance": "-213930",
        "FCPlanGrossMarginVariance": "218089",
        "FCPlanGrossMarginPercentageVariance": "0.0693562795507951"
      },
      {
        "region": "45415",
        "department": "PRODUCE",
        "FCPlanNetSalesVariance": "-218166",
        "FCPlanGrossMarginVariance": "-133730",
        "FCPlanGrossMarginPercentageVariance": "-0.000266019351897073"
      },
      {
        "region": "45415",
        "department": "TOTAL ALCOHOL BEVERAGE",
        "FCPlanNetSalesVariance": "2525",
        "FCPlanGrossMarginVariance": "-42211",
        "FCPlanGrossMarginPercentageVariance": "-0.0626662560038128"
      },
      {
        "region": "45415",
        "department": "UNKNOWN SHOP",
        "FCPlanNetSalesVariance": "28698",
        "FCPlanGrossMarginVariance": "-32124",
        "FCPlanGrossMarginPercentageVariance": "-0.430438889321917"
      },
      {
        "region": "45417",
        "department": "BAKERY",
        "FCPlanNetSalesVariance": "-32140",
        "FCPlanGrossMarginVariance": "43208",
        "FCPlanGrossMarginPercentageVariance": "0.0353489015336974"
      },
      {
        "region": "45417",
        "department": "COFFEE SHOP",
        "FCPlanNetSalesVariance": "-3631",
        "FCPlanGrossMarginVariance": "-6784",
        "FCPlanGrossMarginPercentageVariance": "-0.00580055096065391"
      },
      {
        "region": "45417",
        "department": "DAIRY",
        "FCPlanNetSalesVariance": "-75594",
        "FCPlanGrossMarginVariance": "75857",
        "FCPlanGrossMarginPercentageVariance": "0.0183423149724425"
      },
      {
        "region": "45417",
        "department": "DELI",
        "FCPlanNetSalesVariance": "-128065",
        "FCPlanGrossMarginVariance": "-23980",
        "FCPlanGrossMarginPercentageVariance": "0.00783685424829872"
      },
      {
        "region": "45417",
        "department": "FLORAL",
        "FCPlanNetSalesVariance": "-5696",
        "FCPlanGrossMarginVariance": "",
        "FCPlanGrossMarginPercentageVariance": ""
      },
      {
        "region": "45417",
        "department": "FOOD",
        "FCPlanNetSalesVariance": "10985",
        "FCPlanGrossMarginVariance": "-610683",
        "FCPlanGrossMarginPercentageVariance": "-0.0559839534846496"
      },
      {
        "region": "45417",
        "department": "FROZEN FOODS",
        "FCPlanNetSalesVariance": "-105021",
        "FCPlanGrossMarginVariance": "-263814",
        "FCPlanGrossMarginPercentageVariance": "-0.0565537643702392"
      },
      {
        "region": "45417",
        "department": "GROCERY BEVERAGE",
        "FCPlanNetSalesVariance": "121612",
        "FCPlanGrossMarginVariance": "-405548",
        "FCPlanGrossMarginPercentageVariance": "-0.0602249231159369"
      },
      {
        "region": "45417",
        "department": "MEAT",
        "FCPlanNetSalesVariance": "110194",
        "FCPlanGrossMarginVariance": "-163542",
        "FCPlanGrossMarginPercentageVariance": "-0.0237640372034432"
      },
      {
        "region": "45417",
        "department": "NON FOODS",
        "FCPlanNetSalesVariance": "-276552",
        "FCPlanGrossMarginVariance": "-273801",
        "FCPlanGrossMarginPercentageVariance": "-0.0218217868963616"
      },
      {
        "region": "45417",
        "department": "PHOTO & PHONE CARDS",
        "FCPlanNetSalesVariance": "1560",
        "FCPlanGrossMarginVariance": "-1141",
        "FCPlanGrossMarginPercentageVariance": "-0.00593453734519334"
      },
      {
        "region": "45417",
        "department": "PRE-PACK MEAT",
        "FCPlanNetSalesVariance": "27666",
        "FCPlanGrossMarginVariance": "-97179",
        "FCPlanGrossMarginPercentageVariance": "-0.0647788463934217"
      },
      {
        "region": "45417",
        "department": "PRODUCE",
        "FCPlanNetSalesVariance": "-60284",
        "FCPlanGrossMarginVariance": "-302997",
        "FCPlanGrossMarginPercentageVariance": "-0.0522305288690772"
      },
      {
        "region": "45417",
        "department": "TOTAL ALCOHOL BEVERAGE",
        "FCPlanNetSalesVariance": "-161569",
        "FCPlanGrossMarginVariance": "15915",
        "FCPlanGrossMarginPercentageVariance": "0.00893063146538217"
      },
      {
        "region": "45417",
        "department": "UNKNOWN SHOP",
        "FCPlanNetSalesVariance": "-101",
        "FCPlanGrossMarginVariance": "",
        "FCPlanGrossMarginPercentageVariance": ""
      },
      {
        "region": "45425",
        "department": "BAKERY",
        "FCPlanNetSalesVariance": "8618",
        "FCPlanGrossMarginVariance": "142057",
        "FCPlanGrossMarginPercentageVariance": "0.0345154855468344"
      },
      {
        "region": "45425",
        "department": "COFFEE SHOP",
        "FCPlanNetSalesVariance": "-6",
        "FCPlanGrossMarginVariance": "",
        "FCPlanGrossMarginPercentageVariance": ""
      },
      {
        "region": "45425",
        "department": "DAIRY",
        "FCPlanNetSalesVariance": "122405",
        "FCPlanGrossMarginVariance": "-164739",
        "FCPlanGrossMarginPercentageVariance": "-0.010522388887041"
      },
      {
        "region": "45425",
        "department": "DELI",
        "FCPlanNetSalesVariance": "-71683",
        "FCPlanGrossMarginVariance": "12192",
        "FCPlanGrossMarginPercentageVariance": "0.0060763163357429"
      },
      {
        "region": "45425",
        "department": "FLORAL",
        "FCPlanNetSalesVariance": "164809",
        "FCPlanGrossMarginVariance": "-187530",
        "FCPlanGrossMarginPercentageVariance": "-0.275161659188352"
      },
      {
        "region": "45425",
        "department": "FOOD",
        "FCPlanNetSalesVariance": "-449468",
        "FCPlanGrossMarginVariance": "1042543",
        "FCPlanGrossMarginPercentageVariance": "0.0355756304800691"
      },
      {
        "region": "45425",
        "department": "FROZEN FOODS",
        "FCPlanNetSalesVariance": "-134557",
        "FCPlanGrossMarginVariance": "-151853",
        "FCPlanGrossMarginPercentageVariance": "-0.00944228707770334"
      },
      {
        "region": "45425",
        "department": "GROCERY BEVERAGE",
        "FCPlanNetSalesVariance": "136077",
        "FCPlanGrossMarginVariance": "-287796",
        "FCPlanGrossMarginPercentageVariance": "-0.0203287334341941"
      },
      {
        "region": "45425",
        "department": "MEAT",
        "FCPlanNetSalesVariance": "52831",
        "FCPlanGrossMarginVariance": "-105633",
        "FCPlanGrossMarginPercentageVariance": "-0.00788073614910018"
      },
      {
        "region": "45425",
        "department": "NON FOODS",
        "FCPlanNetSalesVariance": "-386402",
        "FCPlanGrossMarginVariance": "371639",
        "FCPlanGrossMarginPercentageVariance": "0.0253075602456125"
      },
      {
        "region": "45425",
        "department": "PHOTO & PHONE CARDS",
        "FCPlanNetSalesVariance": "1303",
        "FCPlanGrossMarginVariance": "-7156",
        "FCPlanGrossMarginPercentageVariance": "-0.0156084655808023"
      },
      {
        "region": "45425",
        "department": "PRE-PACK MEAT",
        "FCPlanNetSalesVariance": "-150815",
        "FCPlanGrossMarginVariance": "114707",
        "FCPlanGrossMarginPercentageVariance": "0.0387081272590368"
      },
      {
        "region": "45425",
        "department": "PRODUCE",
        "FCPlanNetSalesVariance": "-487302",
        "FCPlanGrossMarginVariance": "-102758",
        "FCPlanGrossMarginPercentageVariance": "0.00644756172446553"
      },
      {
        "region": "45425",
        "department": "TOTAL ALCOHOL BEVERAGE",
        "FCPlanNetSalesVariance": "-72279",
        "FCPlanGrossMarginVariance": "110345",
        "FCPlanGrossMarginPercentageVariance": "0.034530799671771"
      },
      {
        "region": "45425",
        "department": "UNKNOWN SHOP",
        "FCPlanNetSalesVariance": "3465",
        "FCPlanGrossMarginVariance": "-106478",
        "FCPlanGrossMarginPercentageVariance": "-0.226223255930936"
      },
      {
        "region": "45433",
        "department": "BAKERY",
        "FCPlanNetSalesVariance": "449332",
        "FCPlanGrossMarginVariance": "516552",
        "FCPlanGrossMarginPercentageVariance": "0.0186855213228774"
      },
      {
        "region": "45433",
        "department": "COFFEE SHOP",
        "FCPlanNetSalesVariance": "-10",
        "FCPlanGrossMarginVariance": "",
        "FCPlanGrossMarginPercentageVariance": ""
      },
      {
        "region": "45433",
        "department": "DAIRY",
        "FCPlanNetSalesVariance": "-232008",
        "FCPlanGrossMarginVariance": "-484618",
        "FCPlanGrossMarginPercentageVariance": "-0.00974706224661315"
      },
      {
        "region": "45433",
        "department": "DELI",
        "FCPlanNetSalesVariance": "-349879",
        "FCPlanGrossMarginVariance": "-472522",
        "FCPlanGrossMarginPercentageVariance": "-0.0105057418918859"
      },
      {
        "region": "45433",
        "department": "FLORAL",
        "FCPlanNetSalesVariance": "58572",
        "FCPlanGrossMarginVariance": "-2615108",
        "FCPlanGrossMarginPercentageVariance": "-0.682586224988579"
      },
      {
        "region": "45433",
        "department": "FOOD",
        "FCPlanNetSalesVariance": "-453028",
        "FCPlanGrossMarginVariance": "-2714483",
        "FCPlanGrossMarginPercentageVariance": "-0.0332150186519838"
      },
      {
        "region": "45433",
        "department": "FROZEN FOODS",
        "FCPlanNetSalesVariance": "189520",
        "FCPlanGrossMarginVariance": "-1431812",
        "FCPlanGrossMarginPercentageVariance": "-0.0471959931757053"
      },
      {
        "region": "45433",
        "department": "GROCERY BEVERAGE",
        "FCPlanNetSalesVariance": "472544",
        "FCPlanGrossMarginVariance": "1139823",
        "FCPlanGrossMarginPercentageVariance": "0.0252701457797131"
      },
      {
        "region": "45433",
        "department": "MEAT",
        "FCPlanNetSalesVariance": "1019694",
        "FCPlanGrossMarginVariance": "3317434",
        "FCPlanGrossMarginPercentageVariance": "0.0761870478251018"
      },
      {
        "region": "45433",
        "department": "NON FOODS",
        "FCPlanNetSalesVariance": "241050",
        "FCPlanGrossMarginVariance": "-1493999",
        "FCPlanGrossMarginPercentageVariance": "-0.0211076594190752"
      },
      {
        "region": "45433",
        "department": "PHOTO & PHONE CARDS",
        "FCPlanNetSalesVariance": "24595",
        "FCPlanGrossMarginVariance": "-44213",
        "FCPlanGrossMarginPercentageVariance": "-0.0224833529650141"
      },
      {
        "region": "45433",
        "department": "PRE-PACK MEAT",
        "FCPlanNetSalesVariance": "-48390",
        "FCPlanGrossMarginVariance": "20346",
        "FCPlanGrossMarginPercentageVariance": "0.0036046123887068"
      },
      {
        "region": "45433",
        "department": "PRODUCE",
        "FCPlanNetSalesVariance": "-673210",
        "FCPlanGrossMarginVariance": "943026",
        "FCPlanGrossMarginPercentageVariance": "0.0286954596331006"
      },
      {
        "region": "45433",
        "department": "TOTAL ALCOHOL BEVERAGE",
        "FCPlanNetSalesVariance": "-1147786",
        "FCPlanGrossMarginVariance": "-1143060",
        "FCPlanGrossMarginPercentageVariance": "-0.0222296502058771"
      },
      {
        "region": "45433",
        "department": "UNKNOWN SHOP",
        "FCPlanNetSalesVariance": "15061",
        "FCPlanGrossMarginVariance": "-105159",
        "FCPlanGrossMarginPercentageVariance": "-0.62877963193463"
      },
      {
        "region": "45439",
        "department": "BAKERY",
        "FCPlanNetSalesVariance": "-6990",
        "FCPlanGrossMarginVariance": "180435",
        "FCPlanGrossMarginPercentageVariance": "0.0206749520431556"
      },
      {
        "region": "45439",
        "department": "COFFEE SHOP",
        "FCPlanNetSalesVariance": "31108",
        "FCPlanGrossMarginVariance": "68544",
        "FCPlanGrossMarginPercentageVariance": "0.0252491021162113"
      },
      {
        "region": "45439",
        "department": "DAIRY",
        "FCPlanNetSalesVariance": "-182147",
        "FCPlanGrossMarginVariance": "-172727",
        "FCPlanGrossMarginPercentageVariance": "-0.00364559217761473"
      },
      {
        "region": "45439",
        "department": "DELI",
        "FCPlanNetSalesVariance": "89725",
        "FCPlanGrossMarginVariance": "630721",
        "FCPlanGrossMarginPercentageVariance": "0.0394745638399882"
      },
      {
        "region": "45439",
        "department": "FLORAL",
        "FCPlanNetSalesVariance": "402889",
        "FCPlanGrossMarginVariance": "-82762",
        "FCPlanGrossMarginPercentageVariance": "-0.179996134539128"
      },
      {
        "region": "45439",
        "department": "FOOD",
        "FCPlanNetSalesVariance": "-38907",
        "FCPlanGrossMarginVariance": "-223711",
        "FCPlanGrossMarginPercentageVariance": "-0.00409646844259953"
      },
      {
        "region": "45439",
        "department": "FROZEN FOODS",
        "FCPlanNetSalesVariance": "150329",
        "FCPlanGrossMarginVariance": "263423",
        "FCPlanGrossMarginPercentageVariance": "0.013013546749631"
      },
      {
        "region": "45439",
        "department": "GROCERY BEVERAGE",
        "FCPlanNetSalesVariance": "-621374",
        "FCPlanGrossMarginVariance": "352688",
        "FCPlanGrossMarginPercentageVariance": "0.0139599504726438"
      },
      {
        "region": "45439",
        "department": "MEAT",
        "FCPlanNetSalesVariance": "1653005",
        "FCPlanGrossMarginVariance": "-460947",
        "FCPlanGrossMarginPercentageVariance": "-0.0448694199062423"
      },
      {
        "region": "45439",
        "department": "NON FOODS",
        "FCPlanNetSalesVariance": "-352818",
        "FCPlanGrossMarginVariance": "-1293902",
        "FCPlanGrossMarginPercentageVariance": "-0.0279593964364558"
      },
      {
        "region": "45439",
        "department": "PHOTO & PHONE CARDS",
        "FCPlanNetSalesVariance": "-30222",
        "FCPlanGrossMarginVariance": "-39684",
        "FCPlanGrossMarginPercentageVariance": "-0.0198396668373754"
      },
      {
        "region": "45439",
        "department": "PRE-PACK MEAT",
        "FCPlanNetSalesVariance": "-21778",
        "FCPlanGrossMarginVariance": "-104074",
        "FCPlanGrossMarginPercentageVariance": "-0.0147329289903533"
      },
      {
        "region": "45439",
        "department": "PRODUCE",
        "FCPlanNetSalesVariance": "875886",
        "FCPlanGrossMarginVariance": "137303",
        "FCPlanGrossMarginPercentageVariance": "-0.0142335470495401"
      },
      {
        "region": "45439",
        "department": "TOTAL ALCOHOL BEVERAGE",
        "FCPlanNetSalesVariance": "-1101306",
        "FCPlanGrossMarginVariance": "125818",
        "FCPlanGrossMarginPercentageVariance": "0.021289397855874"
      },
      {
        "region": "45439",
        "department": "UNKNOWN SHOP",
        "FCPlanNetSalesVariance": "2794",
        "FCPlanGrossMarginVariance": "21737",
        "FCPlanGrossMarginPercentageVariance": "0.0566535979164924"
      },
      {
        "region": "45441",
        "department": "BAKERY",
        "FCPlanNetSalesVariance": "311106",
        "FCPlanGrossMarginVariance": "231032",
        "FCPlanGrossMarginPercentageVariance": "0.00354804852999191"
      },
      {
        "region": "45441",
        "department": "COFFEE SHOP",
        "FCPlanNetSalesVariance": "44013",
        "FCPlanGrossMarginVariance": "22028",
        "FCPlanGrossMarginPercentageVariance": "-0.00212031690102976"
      },
      {
        "region": "45441",
        "department": "DAIRY",
        "FCPlanNetSalesVariance": "-204559",
        "FCPlanGrossMarginVariance": "-1294265",
        "FCPlanGrossMarginPercentageVariance": "-0.0277959930985992"
      },
      {
        "region": "45441",
        "department": "DELI",
        "FCPlanNetSalesVariance": "129320",
        "FCPlanGrossMarginVariance": "398581",
        "FCPlanGrossMarginPercentageVariance": "0.0141115160634756"
      },
      {
        "region": "45441",
        "department": "FLORAL",
        "FCPlanNetSalesVariance": "478276",
        "FCPlanGrossMarginVariance": "-723203",
        "FCPlanGrossMarginPercentageVariance": "-0.316613503688051"
      },
      {
        "region": "45441",
        "department": "FOOD",
        "FCPlanNetSalesVariance": "169592",
        "FCPlanGrossMarginVariance": "1182689",
        "FCPlanGrossMarginPercentageVariance": "0.015112006361203"
      },
      {
        "region": "45441",
        "department": "FROZEN FOODS",
        "FCPlanNetSalesVariance": "408372",
        "FCPlanGrossMarginVariance": "1421833",
        "FCPlanGrossMarginPercentageVariance": "0.0486642469249802"
      },
      {
        "region": "45441",
        "department": "GROCERY BEVERAGE",
        "FCPlanNetSalesVariance": "-1564296",
        "FCPlanGrossMarginVariance": "1205491",
        "FCPlanGrossMarginPercentageVariance": "0.0280176868600859"
      },
      {
        "region": "45441",
        "department": "MEAT",
        "FCPlanNetSalesVariance": "1103308",
        "FCPlanGrossMarginVariance": "-2515565",
        "FCPlanGrossMarginPercentageVariance": "-0.0834257685567905"
      },
      {
        "region": "45441",
        "department": "NON FOODS",
        "FCPlanNetSalesVariance": "-223375",
        "FCPlanGrossMarginVariance": "75156",
        "FCPlanGrossMarginPercentageVariance": "0.0028791271026829"
      },
      {
        "region": "45441",
        "department": "PHOTO & PHONE CARDS",
        "FCPlanNetSalesVariance": "5977",
        "FCPlanGrossMarginVariance": "5904",
        "FCPlanGrossMarginPercentageVariance": "0.00190357346201897"
      },
      {
        "region": "45441",
        "department": "PRE-PACK MEAT",
        "FCPlanNetSalesVariance": "-270367",
        "FCPlanGrossMarginVariance": "633718",
        "FCPlanGrossMarginPercentageVariance": "0.0800281644258333"
      },
      {
        "region": "45441",
        "department": "PRODUCE",
        "FCPlanNetSalesVariance": "-689199",
        "FCPlanGrossMarginVariance": "1679904",
        "FCPlanGrossMarginPercentageVariance": "0.0464302006640109"
      },
      {
        "region": "45441",
        "department": "TOTAL ALCOHOL BEVERAGE",
        "FCPlanNetSalesVariance": "380948",
        "FCPlanGrossMarginVariance": "-1576486",
        "FCPlanGrossMarginPercentageVariance": "-0.0454757481607195"
      },
      {
        "region": "45441",
        "department": "UNKNOWN SHOP",
        "FCPlanNetSalesVariance": "20638",
        "FCPlanGrossMarginVariance": "-68432",
        "FCPlanGrossMarginPercentageVariance": "-0.211647055679831"
      },
      {
        "region": "TOTAL",
        "department": "",
        "FCPlanNetSalesVariance": "-1919477",
        "FCPlanGrossMarginVariance": "-7205189",
        "FCPlanGrossMarginPercentageVariance": "-3.47383515626422"
      }
    ]
  }
};
});