﻿
/*
Parse a simple dsl representing a slide report tree eg
	SlideSet 1
	  Param 2 numberOfResults
	  Repeating Slide 3 x2
	    Drilldown SlideSet 4
	      Param 5 department
	      Slide 6
	  Slide 7
	    Drilldown SlideSet 8
	      Param 9
	      Slide 10
	        Drilldown SlideSet 11
	          Param 12
	          Slide 13
	  Slide 14

DRilldown parameters will automatically have parent slidesets' parameters added in
Returns an object with
	definitionTree: {}
	allSlideSetDefinitions: {} //hashed by id
	allSlideDefinitions: {}
	allParameters: {}
	createSlideSetInstances: (slideSetDefinition) -> a stubbed slideset instance
 */

(function() {
  define(['underscore', 'jquery', 'knockout'], function(_, $, ko) {
    return function(dsl) {
      var allSlideSetDefinitions, createSlideSetInstances, definitionTree, getChildSlideSets, lines, parseDefinitionLines, pluckParams, pluckSlides, whereHas;
      parseDefinitionLines = (function() {
        var addParamsToChildSlideSets, cache, cachedOr, leadingSpaces, nextLineIsIndented, paramTemplate, parseLineBlock, parseNode, reapeatingSlideTemplate, slideSetTemplate, slideTemplate;
        slideSetTemplate = /SlideSet (\d+)/i;
        paramTemplate = /Param(?:eter)? (\d+)(?: (\w+))?(?: (\w+))?(?: (\w+))?(?: (\w+))?/i;
        reapeatingSlideTemplate = /(?:Repeating )?Slide (\d+)\s*[x\*](\d+)/i;
        slideTemplate = /Slide (\d+)/i;
        parseNode = function(definition, children) {
          var res;
          switch (false) {
            case !(res = paramTemplate.exec(definition)):
              return cachedOr('Param', res[1], function() {
                var name;
                name = res[2] || _.uniqueId("testName");
                return {
                  Id: +res[1],
                  Name: name,
                  DisplayName: name,
                  EvaluationType: res[3] || "JSON",
                  EvaluationSource: '',
                  ParamType: res[4] || 'SELECT',
                  IsEvaluationTypeSql: "SQL" === (res[3] || "JSON"),
                  IsEvaluationTypeJson: "JSON" === (res[3] || "JSON"),
                  IsStackingParameter: res[5] === "true",
                  DisplayInTheTitle: false
                };
              });
            case !(res = slideSetTemplate.exec(definition)):
              return cachedOr('SlideSet', res[1], function() {
                var ss;
                ss = {
                  SlideSetId: +res[1],
                  Name: 'SlideSet' + res[1],
                  Params: pluckParams(children),
                  Slides: pluckSlides(children)
                };
                addParamsToChildSlideSets(ss);
                return ss;
              });
            case !(res = reapeatingSlideTemplate.exec(definition)):
              return cachedOr('Slide', res[1], function() {
                return {
                  SlideId: +res[1],
                  drilldowns: children,
                  __timesRepeating: +res[2]
                };
              });
            case !(res = slideTemplate.exec(definition)):
              return cachedOr('Slide', res[1], function() {
                return {
                  SlideId: +res[1],
                  drilldowns: children
                };
              });
            default:
              throw "Could not parse line '" + definition + "'";
          }
        };
        cache = {};
        cachedOr = function(category, id, factory) {
          var key;
          key = "" + category + "-" + id;
          return cache[key] || (cache[key] = factory());
        };
        addParamsToChildSlideSets = function(ss) {
          return _.chain(ss.Slides).map(getChildSlideSets).flatten().each(function(childss) {
            return childss.Params = _.unique(childss.Params.concat(ss.Params), function(p) {
              return p.Id;
            });
          });
        };
        leadingSpaces = /^\s*/;
        nextLineIsIndented = function(currentLine, nextLine) {
          if (!nextLine) {
            return false;
          } else {
            return (leadingSpaces.exec(nextLine))[0].length > (leadingSpaces.exec(currentLine))[0].length;
          }
        };
        parseLineBlock = function(remainingLines) {
          var child, children, node, thisDefinition, _ref;
          thisDefinition = remainingLines[0];
          remainingLines = remainingLines.slice(1);
          if (!thisDefinition) {
            return [null, []];
          }
          children = [];
          while (nextLineIsIndented(thisDefinition, remainingLines[0])) {
            _ref = parseLineBlock(remainingLines), child = _ref[0], remainingLines = _ref[1];
            children.push(child);
          }
          node = parseNode(thisDefinition, children);
          return [node, remainingLines];
        };
        return function(lines) {
          var blocks, node, _ref;
          blocks = [];
          while (_.any(lines)) {
            _ref = parseLineBlock(lines), node = _ref[0], lines = _ref[1];
            blocks.push(node);
          }
          return blocks;
        };
      })();
      createSlideSetInstances = function(allSlideSetDefinitions) {
        var createSlideInstance;
        createSlideInstance = function(s) {
          return _.map(_.range(s.__timesRepeating || 1), function(idx) {
            return {
              slideDefinition: s,
              Ordering: idx,
              slideData: {}
            };
          });
        };
        return _.map(allSlideSetDefinitions, function(ss) {
          var instance, isFullyLoaded, loading, moveSlide;
          isFullyLoaded = ko.observable(false);
          loading = $.Deferred().done(function() {
            return isFullyLoaded(true);
          });
          instance = {
            __slideSetDefinition: ss,
            isFullyLoaded: isFullyLoaded,
            loading: loading,
            slides: ko.observableArray(_.flatten(_.map(ss.Slides, createSlideInstance))),
            currentSlideIndex: ko.observable(0)
          };
          instance.currentSlide = ko.computed(function() {
            return instance.slides()[instance.currentSlideIndex()];
          });
          moveSlide = function(vector) {
            return function() {
              var newIndex;
              newIndex = instance.currentSlideIndex() + vector;
              if (instance.slides()[newIndex]) {
                return function() {
                  return instance.currentSlideIndex(newIndex);
                };
              } else {
                return null;
              }
            };
          };
          instance.nextSlide = ko.computed(moveSlide(1));
          instance.prevSlide = ko.computed(moveSlide(-1));
          return instance;
        });
      };
      whereHas = function(propName) {
        return function(x) {
          return _.has(x, propName);
        };
      };
      pluckParams = function(arr) {
        return _.filter(arr, whereHas('Id'));
      };
      pluckSlides = function(arr) {
        return _.filter(arr, whereHas('SlideId'));
      };
      getChildSlideSets = function(x) {
        return _.collectTree(x, whereHas('SlideSetId'), function(n) {
          if (_.isArray(n)) {
            return n;
          } else {
            return n.Slides || n.drilldowns;
          }
        });
      };
      lines = dsl.trim().split('\n');
      definitionTree = parseDefinitionLines(lines);
      allSlideSetDefinitions = getChildSlideSets(definitionTree);
      return {
        definitionTree: definitionTree,
        allSlideSetDefinitions: _.mapObject(allSlideSetDefinitions, function(ss) {
          return [ss.SlideSetId, ss];
        }),
        allParameters: _.chain(allSlideSetDefinitions).pluck('Params').flatten().unique().mapObject(function(p) {
          return [p.Id, p];
        }).value(),
        allSlideDefinitions: _.chain(allSlideSetDefinitions).pluck('Slides').flatten().mapObject(function(s) {
          return [s.SlideId, s];
        }).value(),
        createSlideSetInstances: function() {
          return createSlideSetInstances(allSlideSetDefinitions);
        }
      };
    };
  });

}).call(this);
