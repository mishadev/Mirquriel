﻿(function() {
  define(['jasmine', 'underscore', 'Squire', 'jquery'], function(jasmine, _, Squire, $) {
    var injector, jsModel, mocks;
    jsModel = {
      "DefaultSelection": null,
      "HideIfMatchingCommonParamExists": false,
      "IsStackingParameter": false,
      "IsOptionalParameter": false,
      "SelectAllByDefault": false,
      "DisplayInTheTitle": false,
      "Id": 4,
      "Name": "levelBsForLevelA",
      "DisplayName": "levelBsForLevelA",
      "OverriddenDisplayName": null,
      "ParamType": "SELECT",
      "EvaluationType": "SQL",
      "EvaluationSource": "SELECT DISTINCT hierarchyLevelBDesc AS [desc], hierarchyLevelBKey AS [key] FROM outputs.ScenarioTimeframeLevelALevelBInScope WHERE hierarchyLevelAKey = @top20LevelAs",
      "LastModifiedBy": "George.Mauer",
      "LastModifiedOn": "2014-09-01T22:20:38.39",
      "OverriddenDisplayName": null
    };
    mocks = {
      apiUrls: {
        modifyUsedParameter: function(x) {
          return $.when({
            Result: jsModel
          });
        }
      }
    };
    _.visitObject(mocks, (function(_this) {
      return function(val, name, parent) {
        if (_.isFunction(val)) {
          return (spyOn(parent, name)).and.callThrough();
        }
      };
    })(this));
    injector = new Squire().mock(mocks);
    return describe("mapping used SELECT parameter into ko model", function() {
      var allFlagsToVerify, typeFlags;
      beforeEach(function(done) {
        return injector.require(['usedParameterConfigurationModel', 'knockout.mapping'], (function(_this) {
          return function(usedParameterConfigurationModel, mapping) {
            _this.model = usedParameterConfigurationModel(jsModel);
            _this.mapping = mapping;
            return done();
          };
        })(this));
      });
      it("can be reversed", function() {
        return (expect(_.isEqual(jsModel, this.mapping.toJS(this.model)))).toBe(true);
      });
      typeFlags = {
        'SELECT': {},
        'CHECKBOX': {},
        'TEXT': {
          isTrue: ['canBeOptional']
        },
        'MULTISELECT': {
          isTrue: ['isMultiSelect', 'canBeStacked', 'canSelectAllByDefault'],
          verifyManually: ['hasDefaultSelectionConfigured']
        }
      };
      allFlagsToVerify = _.compact(_.unionAll(['hasDefaultSelectionConfigured'].concat(_.pluck(typeFlags, 'isTrue'))));
      _.each(typeFlags, function(cfg, type) {
        return describe("set paramType to " + type, function() {
          beforeEach(function() {
            return this.model.ParamType(type);
          });
          _.each(cfg.isTrue, function(flag) {
            return it("it " + flag, function() {
              return (expect(this.model[flag]())).toBe(true);
            });
          });
          return _.each(_.difference(allFlagsToVerify, cfg.isTrue, cfg.verifyManually), function(flag) {
            return it("it is not " + flag, function() {
              return (expect(this.model[flag]())).toBe(false);
            });
          });
        });
      });
      return describe("set paramType to MULTISELECT", function() {
        beforeEach(function() {
          return this.model.ParamType('MULTISELECT');
        });
        describe("SelectAllByDefault = true", function() {
          beforeEach(function() {
            return this.model.SelectAllByDefault(true);
          });
          return it("it hasDefaultSelectionConfigured", function() {
            return (expect(this.model.hasDefaultSelectionConfigured())).toBe(true);
          });
        });
        return describe("SelectAllByDefault = false", function() {
          beforeEach(function() {
            return this.model.SelectAllByDefault(false);
          });
          describe("has DefaultSelection", function() {
            beforeEach(function() {
              return this.model.DefaultSelection('defaultVal');
            });
            return it("it hasDefaultSelectionConfigured", function() {
              return (expect(this.model.hasDefaultSelectionConfigured())).toBe(true);
            });
          });
          return describe("has no DefaultSelection", function() {
            beforeEach(function() {
              return this.model.DefaultSelection(null);
            });
            return it("it does not hasDefaultSelectionConfigured", function() {
              return (expect(this.model.hasDefaultSelectionConfigured())).toBe(false);
            });
          });
        });
      });
    });
  });

}).call(this);

//# sourceMappingURL=usedParameterConfigurationModel.specs.js.map
