﻿(function() {
  define(['underscore', '../../OgrePlugins/textWrapper'], function(_, wrapper) {
    return describe("Wrapping text of the slide", function() {
      var text_wrapped_by_rule;
      text_wrapped_by_rule = function(text, expected, rule) {
        if (rule == null) {
          rule = (function(text) {
            return text.length > 3;
          });
        }
        return describe("wrapped [" + text + "]", function() {
          return it("should be [" + expected + "]", function() {
            return (expect(wrapper.wrap(text, rule))).toEqual(expected);
          });
        });
      };
      text_wrapped_by_rule("foo", ["foo"]);
      text_wrapped_by_rule("   foo  bar     foo ", ["foo", "bar", "foo"]);
      text_wrapped_by_rule("foobarfoobar", ["foo-", "bar-", "foo-", "bar"]);
      text_wrapped_by_rule("foobar foobar", ["foo-", "bar", "foo-", "bar"]);
      text_wrapped_by_rule("f foobar o foobar o", ["f", "foo-", "bar", "o", "foo-", "bar", "o"]);
      text_wrapped_by_rule("foo-bar", ["foo-", "bar"]);
      text_wrapped_by_rule("fo-obar", ["fo-", "oba-", "r"]);
      return text_wrapped_by_rule("foob-ar", ["foo-", "b-a-", "r"]);
    });
  });

}).call(this);
