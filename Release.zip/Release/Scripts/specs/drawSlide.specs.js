﻿(function() {
  var __slice = [].slice;

  define(['jquery', 'underscore', 'knockout', 'ogre.widgets.slideWidgets'], function($, _, ko) {
    var delay, slideInstance, textOf;
    delay = function(ms, fn) {
      return _.delay.call(_, fn, ms);
    };
    slideInstance = function() {
      var extensions;
      extensions = 1 <= arguments.length ? __slice.call(arguments, 0) : [];
      return $.extend.apply($, [
        true, {
          data: {
            vals: [1, 2, 3],
            text: [
              {
                TextKey: 'greeting',
                LanguageKey: 'en',
                LocalizedTextValue: "hello"
              }, {
                TextKey: 'greeting',
                LanguageKey: 'es',
                LocalizedTextValue: "hola"
              }
            ]
          },
          parameters: {
            param1: "value 1",
            param2: "value 2"
          },
          slideDefinition: {
            StyleCode: 'h1 { font-size: 80pt }',
            LayoutCode: 'console.log("foo")'
          }
        }
      ].concat(extensions));
    };
    textOf = function($widget) {
      var _ref;
      return (_ref = ($widget.slideView('slideDocument')).getElementById('slide-canvas').textContent) != null ? _ref.trim() : void 0;
    };
    describe("when a drawSlide is created", function() {
      beforeEach(function(done) {
        this.slideInstance = slideInstance({
          slideDefinition: {
            LayoutCode: '$s.html(\'<h1>foo</h1>\');\nwindow.createdVar = "a string";'
          },
          redrawing: _.once(function(e, def) {
            return def.done(done);
          })
        });
        return this.$slide = $('<div>').appendTo('body').drawSlide(this.slideInstance);
      });
      afterEach(function(done) {
        this.$slide.remove();
        return _.delay(done, 25);
      });
      it("draws the slide html", function() {
        return (expect(textOf(this.$slide))).toBe("foo");
      });
      return it("doesn't run scripts in the context of the parent page", function() {
        return (expect(window.createdVar)).toBe(void 0);
      });
    });
    return describe("when a drawSlide is created with modifyable layout code", function() {
      var beforeEachSetLayoutAndRedraw, bodyContains, givenLayoutCodeThat;
      beforeEach(function(done) {
        this.slideInstance = slideInstance({
          slideDefinition: {
            LayoutCode: ko.observable('')
          },
          redrawing: _.once(function(e, def) {
            return def.done(done);
          })
        });
        return this.$slide = $('<div>').appendTo('body').drawSlide(this.slideInstance);
      });
      afterEach(function(done) {
        this.$slide.remove();
        return _.delay(done, 25);
      });
      beforeEachSetLayoutAndRedraw = function(code) {
        return beforeEach(function(done) {
          this.slideInstance.slideDefinition.LayoutCode(code);
          this.$slide.on('drawslideredrawing', _.once((function(_this) {
            return function(e, def) {
              return def.fail(function(e) {
                return _this.error = e;
              }).always(done);
            };
          })(this)));
          return this.$slide.drawSlide('redraw', true);
        });
      };
      givenLayoutCodeThat = function(title, layoutCode, assertions) {
        return describe("that " + title, function() {
          beforeEachSetLayoutAndRedraw(layoutCode);
          return assertions.apply(this, arguments);
        });
      };
      bodyContains = function(text) {
        return function() {
          return (expect(textOf(this.$slide))).toContain(text);
        };
      };
      describe("slide layout code changes and is redrawn", function() {
        beforeEachSetLayoutAndRedraw('$s.html(\'<h1>bar</h1>\');');
        it("can redraw", function() {
          return (expect(textOf(this.$slide))).toBe("bar");
        });
        return it("has no error", function() {
          return (expect(this.error)).toBeFalsy();
        });
      });
      givenLayoutCodeThat("uses jquery slide via ogre object", 'o.$s.html("blah");', function() {
        return it("has o.$s available", bodyContains('blah'));
      });
      givenLayoutCodeThat("uses plugins", '$s.html(_.keys(o).join(", "));', function() {
        return it("has plugins availble", bodyContains('clientColors'));
      });
      givenLayoutCodeThat("uses longform plugins", '$s.html(_.keys(ogre).join(", "));', function() {
        return it("has plugins availble", bodyContains('clientColors'));
      });
      givenLayoutCodeThat("uses d3", 's.selectAll(\'p\').data([1,2]).enter().append(\'p\').text("xxx")', function() {
        return it("has d3 available", bodyContains("xxx"));
      });
      givenLayoutCodeThat("uses d3 via the ogre object", 'o.s.selectAll(\'p\').data([1,2]).enter().append(\'p\').text("xxx")', function() {
        return it("has d3 available", bodyContains("xxx"));
      });
      givenLayoutCodeThat("uses longform d3", 'slide.selectAll(\'p\').data([1,2]).enter().append(\'p\').text("xxx")', function() {
        return it("has d3 available", bodyContains("xxx"));
      });
      givenLayoutCodeThat("uses builtin variables", '$s.html(b.slideAssetsPath)', function() {
        return it("has access to slide assets path", bodyContains("/SlideAssets"));
      });
      givenLayoutCodeThat("uses builtin variables via the ogre object", '$s.html(o.b.slideAssetsPath)', function() {
        return it("has access to slide assets path", bodyContains("/SlideAssets"));
      });
      givenLayoutCodeThat("uses longform builtin variables", '$s.html(builtins.slideAssetsPath)', function() {
        return it("has access to slide assets path", bodyContains("/SlideAssets"));
      });
      givenLayoutCodeThat("uses params", '$s.html(params.param1)', function() {
        return it("has access to first parameter", bodyContains("value 1"));
      });
      givenLayoutCodeThat("uses params via the ogre object", '$s.html(o.p.param1)', function() {
        return it("has access to first parameter", bodyContains("value 1"));
      });
      givenLayoutCodeThat("uses longform params", '$s.html(p.param1)', function() {
        return it("has access to first parameter", bodyContains("value 1"));
      });
      givenLayoutCodeThat("acesses data", '$s.html(JSON.stringify(d.vals))', function() {
        return it("has access to data", bodyContains("[1,2,3]"));
      });
      givenLayoutCodeThat("acesses data via the ogre object", '$s.html(JSON.stringify(o.d.vals))', function() {
        return it("has access to data", bodyContains("[1,2,3]"));
      });
      givenLayoutCodeThat("accesses longform data", '$s.html(JSON.stringify(data.vals))', function() {
        return it("has access to data", bodyContains("[1,2,3]"));
      });
      givenLayoutCodeThat("acesses text", '$s.html(JSON.stringify(t.greeting))', function() {
        return it("has access to text", bodyContains('{"en":"hello","es":"hola"}'));
      });
      givenLayoutCodeThat("accesses longform text", '$s.html(JSON.stringify(text.greeting))', function() {
        return it("has access to text", bodyContains('{"en":"hello","es":"hola"}'));
      });
      givenLayoutCodeThat("acesses the editorMode variable via ogre object", '$s.html(JSON.stringify(o.editorMode))', function() {
        return it("can print the value", bodyContains('false'));
      });
      givenLayoutCodeThat("draws something", '$s.html("foo")', function() {
        return describe("detach, replace, and redraw widget", function() {
          beforeEach(function(done) {
            return delay(25, (function(_this) {
              return function() {
                _this.$slide.detach().appendTo('body');
                _this.$slide.on('drawslideredrawing', _.once(function(e, def) {
                  return def.fail(function(e) {
                    return _this.error = e;
                  }).always(done);
                }));
                return _this.$slide.drawSlide('redraw', true);
              };
            })(this));
          });
          return it("retains its content", bodyContains("foo"));
        });
      });
      givenLayoutCodeThat("uses errroneous code", 'console.log(thisVariableDoesntExist);', function() {
        return it("reports a drawing error", function() {
          return (expect(this.error)).toBeTruthy();
        });
      });
      return givenLayoutCodeThat("explicitly attempts to close the script", '<\/script>', function() {
        return it("reports a drawing error", function() {
          return (expect(this.error)).toBeTruthy();
        });
      });
    });
  });

}).call(this);
