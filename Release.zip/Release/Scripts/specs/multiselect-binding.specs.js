﻿(function() {
  define(['jquery', 'underscore', 'knockout', 'knockoutExtensions'], function($, _, ko) {
    return describe("multi-select binding", function() {
      describe("DOM tests:", function() {
        var options, selectedOptions, vm;
        options = selectedOptions = null;
        vm = null;
        beforeEach(function() {
          options = ko.observableArray([
            {
              desc: 'abc',
              key: 1
            }, {
              desc: 'def',
              key: 2
            }, {
              desc: 'ghi',
              key: 3
            }
          ]);
          selectedOptions = ko.observableArray([]);
          vm = {
            options: options,
            missingPrereqs: ko.observable(false),
            selectedOptions: selectedOptions
          };
          this.$ctx = $('<select multiple="multiple" data-bind=" disable: missingPrereqs ,options: options ,optionsText: \'desc\' ,optionsValue: \'key\' ,selectedOptions: selectedOptions ,multiselect: { includeSelectAllOption: true, enableFiltering: true }">').appendTo('body');
          return ko.applyBindings(vm, this.$ctx[0]);
        });
        afterEach(function() {
          console.log('should clean up, but won"t');
          this.$ctx.multiselect('destroy');
          return this.$ctx.remove();
        });
        describe("when initializing the plugin by hand", function() {
          it("it inited", function() {
            return (expect(this.$ctx.data('multiselect'))).toBeDefined();
          });
          return it("it doesn't throw any errors", function() {
            console.log(this.$ctx[0]);
            return (expect(true)).toBeTruthy();
          });
        });
        describe("when selecting a value via the plugin API", function() {
          return it("it gets added to the observable array of selected values", function() {
            (this.$ctx.multiselect('select', '1')).change();
            return (expect(vm.selectedOptions().length)).toEqual(1);
          });
        });
        describe("when an object is added to the options observableArray", function() {
          beforeEach(function(done) {
            vm.options.push({
              desc: 'z',
              key: 4
            });
            return done();
          });
          it("it ripples through to the ul", function() {
            var numCheckboxes;
            numCheckboxes = this.$ctx.data('multiselect').$ul.find('input[type=checkbox]').length;
            return (expect(numCheckboxes)).toEqual(5);
          });
          return it("it ripples through to the origin select", function() {
            var numCheckboxes;
            numCheckboxes = this.$ctx.data('multiselect').$ul.find('input[type=checkbox]').length;
            return (expect(numCheckboxes)).toEqual(5);
          });
        });
        describe("when an object is added to the selectedOptions observableArray", function() {
          beforeEach(function(done) {
            vm.selectedOptions.push(vm.options()[0].key);
            return done();
          });
          it("it becomes selected in the ul", function() {
            var numCheckedCheckboxes;
            numCheckedCheckboxes = this.$ctx.data('multiselect').$ul.find('input[type=checkbox]:checked').length;
            return (expect(numCheckedCheckboxes)).toEqual(1);
          });
          return it("it becomes selected in the origin select", function() {
            var numCheckedCheckboxes;
            numCheckedCheckboxes = this.$ctx.data('multiselect').$select.find(':selected').length;
            return (expect(numCheckedCheckboxes)).toEqual(1);
          });
        });
        return describe("when the widget is destroying", function() {
          beforeEach(function(done) {
            this.multiselectContainer = (this.$ctx.data('multiselect')).$container;
            this.$ctx.multiselect('destroy');
            return done();
          });
          it("it multiselect data becomes false", function() {
            return (expect(this.$ctx.data('multiselect'))).toBeFalsy();
          });
          return it("it container deleted from DOM", function() {
            return (expect(this.multiselectContainer.parent()[0])).toBeUndefined();
          });
        });
      });
      return describe("template tests:", function() {
        beforeEach(function() {
          var options, selectedOptions;
          options = ko.observableArray([
            {
              desc: '1',
              key: 1
            }, {
              desc: '2',
              key: 2
            }, {
              desc: '3',
              key: 3
            }, {
              desc: '4',
              key: 4
            }
          ]);
          selectedOptions = ko.observableArray([]);
          this.vm = {
            options: options,
            selectedOptions: selectedOptions
          };
          this.$html = $('<select id="mstest" multiple="multiple" data-bind=" ,options: options ,optionsText: \'desc\' ,optionsValue: \'key\' ,selectedOptions: selectedOptions ,multiselect: { includeSelectAllOption: true, enableFiltering: true, numberDisplayed: 2, nSelectedTextTemplate: \'--!count {{selectedCount}}!--\', nonSelectedText: \'non\' }">').appendTo('body');
          return ko.applyBindings(this.vm, this.$html[0]);
        });
        afterEach(function() {
          this.$html.multiselect('destroy');
          return ($('#mstest')).remove();
        });
        describe("where not selected", function() {
          return it("it shows text", function() {
            return (expect(this.$html.data('multiselect').$button.text())).toBe("non ");
          });
        });
        describe("where selected 1", function() {
          return it("it shows text", function() {
            this.$html.multiselect('select', '1');
            return (expect(this.$html.data('multiselect').$button.text())).toBe("1 ");
          });
        });
        describe("where selected 1 then 2", function() {
          return it("it shows text", function() {
            this.$html.multiselect('select', '1');
            this.$html.multiselect('select', '2');
            return (expect(this.$html.data('multiselect').$button.text())).toBe("1, 2 ");
          });
        });
        describe("where selected 2 then 1 (order regardless)", function() {
          return it("it shows text", function() {
            this.$html.multiselect('select', '2');
            this.$html.multiselect('select', '1');
            return (expect(this.$html.data('multiselect').$button.text())).toBe("1, 2 ");
          });
        });
        return describe("where selected 3 then 1 then 2", function() {
          return it("it shows text", function() {
            this.$html.multiselect('select', '3');
            this.$html.multiselect('select', '1');
            this.$html.multiselect('select', '2');
            return (expect(this.$html.data('multiselect').$button.text())).toBe("--!count 3!-- ");
          });
        });
      });
    });
  });

}).call(this);
