﻿define(
    ['jquery', 'knockout', 'apiUrls', 'parameters/editorParametersFactory', 'parameters/parametersEvaluator', 'parameters/parametersSelectionsEvaluator'],
     function ($, ko, apiUrls, parametersFactory, parametersEvaluator, parametersSelectionsEvaluator) {
     	'use strict';

     	return function (datamart) {
     		var sortingAvailable = true;
     		var evaluator;
     		var factory = parametersFactory(datamart);
     		var debounceEvaluateOrder = _.debounce(evaluateOrder, 500);

     		var _commonParametersEditor = {
     			commonParametersList: ko.observableArray([]),
     			deleteParamConfirmation: ko.observable(),
     			availableParameters: ko.observableArray([]),
     			currentParameter: ko.observable(),
     			getPrerequisites: getPrerequisitesForParameter,

     			//initialization
     			newParameter: function () {
     				sortingAvailable = false;
     				apiUrls.newCommonParameter(createParamModel(null, _commonParametersEditor.currentParameter(), 1))
					.done(function (newItem) {
						_commonParametersEditor.commonParametersList.push(createParamModel(newItem));
						evaluator.evaluateParameters();
						sortingAvailable = true;
					});
     			},
     			deleteParam: function (param) {
     				_commonParametersEditor.deleteParamConfirmation({
     					yes: function () {
     						apiUrls.deleteCommonParameter(ko.unwrap(param.Id))
							.done(function () {
								_commonParametersEditor.commonParametersList.remove(param);
							});
     					}
     				});
     			}
     		};

     		loadParameters();

     		return _commonParametersEditor;

     		function evaluateOrder(parameters) {
     			if (!sortingAvailable) return;
     			_.each(parameters, function (param, index) {
     				param.DisplayOrder = index + 1;
     				saveParameter(param);
     			});
     		}

     		//is used for displaying prerequisite list for the parameter
     		function getPrerequisitesForParameter(parameter) {
     			return evaluator.getNamesOfPrerequisiteParameters(parameter).join(',');
     		}

     		function saveParameter(param) {
     			apiUrls.saveCommonParameter(ko.unwrap(param.Id), param)
				.done(_.runWhen(isSavedParameter, function (parameterData) {
					param = createParamModel(parameterData);
				}));
     		};

     		function isSavedParameter(p) { return p && _.has(p, 'Id'); }

     		function loadParameters() {
     			sortingAvailable = false;
     			apiUrls.getCommonParameters(datamart).then(boundCommonParametersList);
     			apiUrls.getParameters().then(boundAvalableParameters);
     			_commonParametersEditor.commonParametersList.subscribe(debounceEvaluateOrder);
     		}

     		function boundAvalableParameters(model) {
     			_commonParametersEditor.availableParameters(adjustDisplayNames(model));
     		}

     		// An evaluation will react to changes of 'parameters' that passed to evaluator constructor
     		// but this module will change 'commonParametersList' (delete/add) so we have to bound this two arrays.
     		function boundCommonParametersList(model) {
     			var commonParameters = _.map(model, function (p) { return createParamModel(p, null) });
     			var parameters = ko.observableArray(_.pluck(commonParameters, 'Parameter'));

     			evaluator = getParametersEvaluator(parameters);
     			evaluator.evaluateParameters();

     			_commonParametersEditor.commonParametersList(commonParameters);
     			_commonParametersEditor.commonParametersList.subscribe(function (list) {
     				parameters(_.pluck(list, 'Parameter'));
     			});

     			sortingAvailable = true;
     		}

     		function createParamModel(parameterData, parameterId, order) {
     			var param = {
     				DatamartName: datamart,
     				DisplayOrder: order,
     				Parameter: {
     					Id: parameterId
     				}
     			};
     			if (!parameterData)
     				return param;

     			_.extend(param, parameterData);
     			param.Parameter = factory.createParameter(param.Parameter);
     			return param;
     		}

     		function getParametersEvaluator(parameters) {
     			var selectionsEvaluator = parametersSelectionsEvaluator(parameters, function () { });
     			return parametersEvaluator(parameters, function () { }, { getParameterOptions: getParameterOptions }, selectionsEvaluator);
     		}

     		function getParameterOptions(parameter, allSelections) {
     			return apiUrls.getEditorParameterOptions({
     				parameterId: parameter.Id,
     				datamart: datamart,
     				allSelections: allSelections
     			});
     		}

     		function adjustDisplayNames(parameters) {
     			return _.map(parameters, function (p) {
     				return _.extend(p, { optionName: p.DisplayName + " (" + p.Name + " - " + p.Id + ")" });
     			});
     		}
     	}
     });