define(['jquery', 'underscore', 'node-querystring'],
function ($, _, queryString) {
  // This class is under test in url-binding.specs.coffee
  // Suppose that you have an input, select or checkbox that is stored in an observable and needs to be kept in sync with a portion of the url
  // eg mysite.com/#/MyPage?numberOfItems=10 This will set up bindings so that when the url is changed the knockout observable will change
  // and vice versa. Observable should be a knockout-style observable set by invocation and with a subscribe method that returns a subscription object
  'use strict';
  var createdBindings = [];

  !function polyfillLocationOrigin() {      //TODO - GM - Move this to modernizr if needed in more than one place
    if (!window.location.origin)
      window.location.origin = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':' + window.location.port: '');
  }()

  return {
     //Setup bindings for observable to update hash parameter whenever url is changed and to update url hash whenever observable is changed
     //If you want  
     // Usage to serialize a complex object to the url hash (eg: {selections: {numberOfItems: 10}}):
     //    hashParamerterBinding.bindToUrl({
     //       observable: numberOfItemsObservable
     //       getHashValue: function(params) { return params.selections.numberOfItems } //note this will be more complex as in reality you will want to ensure 'selections' exists
     //       setHashValue: function(params, value) { params.selections.numberOfItems = value }
     //    });
     // If seralizing a simple value, a parameterName can be provided so that get/set/delete can be inferred
     // Usage:
     //    hashParamerterBinding.bindToUrl({
     //       parameterName: 'numberOfItems' 
     //       observable: numberOfItemsObservable
     //    })
     // If the value being seralized itself is a complex object (eg {val: 10, label: "10 Items"}) two additional overrides are optionally available
     //    setObservable: function(val) { ...set observable... } //Note that val will always be a string and might need to be coerced to a proper type (eg Numeric). It also does not check for an observable being set to the same value it already is
     //    serializableValue: function(observable) { ...get value from observable... }
     bindToUrl: bindToUrl
     //Remove bindings for the observable.
     // Usage:
     //    hashParamerterBinding.unbindFromUrl numberOfItemsObservable
    ,unbindFromUrl: unbindFromUrl
  }

  ////////////////////////////////////////////////////////////
  function bindToUrl(op) {
      _.ensureHasKeys('observable');
      _.defaults(op, {
         setObservable: _.partial(defaultSet, op.observable)
        ,serializableValue: function (observable) { return op.observable(); }
      });
      if(op.parameterName) //if a parameterName is provided these functions can be inferred, otherwise they must be provided manually
        _.defaults(op, {
			getHashValue:		function(params) { return params[op.parameterName] }
			,setHashValue:		function (params, val) { params[op.parameterName] = val }
			,removeHashValue:	function (params) { delete params[op.parameterName]; }
        });
      _.ensureHasKeys(op, 'getHashValue', 'setHashValue');

      var updateObservableFromUrlFunc = _.partial(updateObservableFromUrl, op);
      var updateUrlFromObservableFunc = _.partial(updateUrlFromObservable, op);
      var subscription = op.observable.subscribe(updateUrlFromObservableFunc);
      $(window).on('hashchange', updateObservableFromUrlFunc);

      createdBindings.push({
         options: op
        ,hashChangeBinding: updateObservableFromUrlFunc
        ,observableSubscription: subscription
      });

      updateObservableFromUrlFunc();
      updateUrlFromObservableFunc(op);
  };

    function unbindFromUrl(observable, cleanUrl) {
      var idx = _.findIndex(createdBindings, function(x) { return x.options.observable === observable });
      if (!~idx) return;
      var thisBinding = createdBindings.splice(idx, 1)[0];
      $(window).off('hashchange', thisBinding.hashChangeBinding);
      thisBinding.observableSubscription.dispose();
	  if (_.isUndefined(cleanUrl) || cleanUrl)
		removeFromUrl(thisBinding.options);
    };

    ////////////////////////////////////////////
    function updateObservableFromUrl(op) {
      var  parts = hashParts()
          ,val   = op.getHashValue(parts.hashParams) 
          ;
      if (_.isUndefined(val) || (((val || null) == null) && op.observable() == null) || _.isEqual(val, op.serializableValue())) //loose comparison used on purpose  
          return;
      op.setObservable( val, op.observable);
    };

    function updateUrlFromObservable(op) {
      var  parts = hashParts()
          ,val = op.serializableValue()
          ;
      op.setHashValue(parts.hashParams, val);
      location.href = parts.getUrlWithHashParams();
    }

	function removeFromUrl(op) {
		var parts = hashParts();
		op.removeHashValue(parts.hashParams);
		location.href = parts.getUrlWithHashParams();
	}

    function hashParts() {
      var parts;
      parts = (location.href.split('#')[1] || "").split('?');//hash is automatically unencoded in FF so we need to use href instead this works for all borwsers

      return {
        urlWithoutHashParams: "" + location.origin + location.pathname + "#" + parts[0],
        hashParams: queryString.parse(parts[1] || {}),
        getUrlWithHashParams: function() {
             return this.urlWithoutHashParams + "?" + ($.param(this.hashParams));
        }
      };
    };
    function defaultSet(observable, val) {
        return observable(val);
    }
})