define(
['jquery', 'constants'], 
function($, constants){
	// Utilities useful when rendering slides
	return {
		configureSeamlessIframe: function($iframe) {
			$iframe.prop('seamless', true)
				.width(constants.SLIDE_VIEWBOX_WIDTH).height(constants.SLIDE_VIEWBOX_HEIGHT)
		        .css('overflow', 'hidden');
		}
		,configureContentBody: function(body) {
			var $body = $(body);
	        if($body.is('.initialized-slide-body'))
	        	return;
            $body.css({
                	'max-height': constants.SLIDE_VIEWBOX_HEIGHT, 
                	'max-width': constants.SLIDE_VIEWBOX_WIDTH, 
                	'min-width': constants.SLIDE_VIEWBOX_WIDTH,
                	overflow: 'hidden',
                	'background-color': 'white'
                }).addClass('initialized-slide-body');
		}
	    ,documentOf: function($iframe) {
	        var iframe = $($iframe)[0];
	        return iframe.contentDocument || iframe.contentWindow.document;
	    }
	    ,scale: function(slideScaling, scaleBy) {
            return $(slideScaling)
                .css('transform', 'scale('+scaleBy+')')
                .width(scaleBy * constants.SLIDE_VIEWBOX_WIDTH)
                .height(scaleBy * constants.SLIDE_VIEWBOX_HEIGHT)
	    }
	};
})