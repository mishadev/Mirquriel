/*
*  jQuery by default shims out css properties like opacity to protect against 
*  browser inconsistencies. Add more shims using $.cssHooks for styles we want
*  programmatic access to
*/
define([
'jquery'
],
function jQueryCssShims($) {

vendorPrefix('transform');

function vendorPrefix(styleName) {
    var prefixedStyleName = styleSupport(styleName);
    if(styleName != prefixedStyleName) {
        $.cssHooks[styleName] = {
             get: function(el) { return $.css(el, prefixedStyleName) }
            ,set: function(el, value) {el.style[prefixedStyleName] = value}
        }
    }
}

//straight from http://api.jquery.com/jQuery.cssHooks/
function styleSupport( prop ) {
    var vendorProp, supportedProp,

    // capitalize first character of the prop to test vendor prefix
    capProp = prop.charAt(0).toUpperCase() + prop.slice(1),
    prefixes = [ "Moz", "Webkit", "O", "ms" ],
    div = document.createElement( "div" );

    if ( prop in div.style ) {
      // browser supports standard CSS property name
      supportedProp = prop;
    } else {

      // otherwise test support for vendor-prefixed property names
      for ( var i = 0; i < prefixes.length; i++ ) {
        vendorProp = prefixes[i] + capProp;
        if ( vendorProp in div.style ) {
            supportedProp = vendorProp;
            break;
        }
      }
    }

    // avoid memory leak in IE
    div = null;

    // add property to $.support so it can be accessed elsewhere
    $.support[ prop ] = supportedProp;

    return supportedProp;
}
});