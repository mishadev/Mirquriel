﻿define(
['underscore', 'jquery', 'knockout', 'jquery.fileDownload', 'serverUtils'], 
function(_, $, ko, fileDownload, serverUtils){
	 //TODO - GM - We no longer need appPath
	 // for convenience, we set appPath in a Razor view where we can inject the application base path from the ASP.NET HttpContext
	var appPath = window.ow.appPath;

	return {

		 //TODO - GM - NOTE THAT IN THE FUTURE METHODS SHOULD NOT USE THIS AS AN OBJECT OF URLS, BUT SHOULD USE SIMPLE FUNCTION STUBS.
		 //            THIS WILL MAKE AJAX REQUESTS FAR EASIER TO STUB. IF YOU NEED A NEW REQUEST ADD A FUNCTION, NOT A STRING
		SlideDeckPdf:               appPath + '/api/Pdf' //Obsolete: could not be deleted until slideDeckDownloader.js using it
		,SlideDeckPptx:             appPath + '/api/Pptx' //Obsolete: could not be deleted until slideDeckDownloader.js using it

		,slideConfigurationUrlTemplate: slideConfigurationUrlTemplate
		,slidesetConfigurationUrlTemplate: slidesetConfigurationUrlTemplate

		,getSlideData:                getSlideData
		,getSlide:                    getSlide

		,availableSlideSetsDefinitionsFor: availableSlideSetsDefinitionsFor

		,getLocalizationData:		  getLocalizationData
		
		,getSlideSetsForEditor:		  getSlideSetsForEditor
		,getSlideSetParameters:       getSlideSetParameters

		,getParameters:               getParameters
		,newParameter:                newParameter
		,deleteParameter:             deleteParameter
		,saveParameter:               saveParameter

		,getHierarchyParameters:      getHierarchyParameters
		,newHierarchyParameter:       newHierarchyParameter
		,deleteHierarchyParameter:    deleteHierarchyParameter
		,saveHierarchyParameter:      saveHierarchyParameter
		,getHierarchyParamOptions:    getHierarchyParamOptions

		,getCommonParameters:         getCommonParameters
		,newCommonParameter:          newCommonParameter
		,deleteCommonParameter:       deleteCommonParameter
		,saveCommonParameter:         saveCommonParameter
		,getCommonParamOptions:		  getCommonParamOptions

		,getSlideAssets:              getSlideAssets
		,getSlideSetParamOptions:     getSlideSetParam
		,getSlidesetParameterValues:  getSlidesetParameterValues
		,getEditorParameterOptions:   getEditorParameterOptions
		
		,datamartParametersUrlTemplate: datamartParametersUrlTemplate

		,strippedSlideSetInNewWindow: strippedSlideSetInNewWindow

		,updateThumbnail:			  updateThumbnail
		,useSlide:                    useSlide
		,stopUsingSlide:              stopUsingSlide
		,updateSlideSlidesetContext:  updateSlideSlidesetContext
		,modifyUsedSlideOrder:        modifySlidesetRelationOrder('/api/Slideset/{{slidesetId}}/SlideOrder/')
		,useParameter:                useParameter
		,stopUsingParameter:          stopUsingParameter
		,modifyUsedParameterOrder:    modifySlidesetRelationOrder('/api/Slideset/{{slidesetId}}/ParameterOrder/')
		,modifyUsedParameter:		  modifyUsedParameter
		,deleteSlide:                 deleteSlide
		,deleteSlideSet:			  deleteSlideSet

		,exportRenderedSlideSets:     exportRenderedSlideSets
		,renderSlideSetsInNewWindow:  renderSlideSetsInNewWindow
		,renderHtmlAs:                renderHtmlAs
		,downloadHtmlAs:              downloadHtmlAs
		,downloadQueryReport:         _.partial(downloadQueryReport, false)
		,downloadDetailedQueryReport: _.partial(downloadQueryReport, true)

		,getDatamartHierarchyParameterValues: getDatamartHierarchyParameterValues

		,markParameterDefaultSelection: markParameterDefaultSelection
		,saveSlidesetDescriptors:       saveSlidesetDescriptors
		,createSlideset:				createSlideset
		,createSlide:                   createSlide
		,cloneSlide:					cloneSlide
		,updateSlide:					updateSlide

		,addUser:                       addUser
		,getDataSyncStatus: 			getDataSyncStatus
	}

	function getDataSyncStatus() {
		return $.getJSON("/SlideVersionControl/SyncStatus");
	}
	function deleteSlide(slideId) {
		return window.delRequest = serverUtils.del({url: '/api/Slide/'+slideId});
	}

	function datamartParametersUrlTemplate(datamart) {
		return _.template('/Editor/DatamartParameters?{{datamart}}')({ datamart: datamart });
	}

	function slideConfigurationUrlTemplate(slidesetId, slideId) {
		return _.template('Slide/{{slideId}}/Configuration/?slidesetContext={{slidesetId}}')({ slidesetId: slidesetId, slideId: slideId });
	}

	function slidesetConfigurationUrlTemplate(slidesetId) {
		return _.template('Slideset/{{slidesetId}}/Configuration')({ slidesetId: slidesetId });
	}

	function addUser(username) {
		return serverUtils.post({url: '/api/User/', data: { Username: username } });
	}
	
	function createSlide() {
		return serverUtils.post({ url: '/api/Slide' });
	}

	function createSlideset(datamart) {
		return serverUtils.post({ url: '/api/Slideset', data: { datamart: datamart } });
	}

	function updateThumbnail(op) {
		_.ensureHasKeys(op, 'slideSetId', 'slideId', 'data');
		return serverUtils.put({ url: _.template('/api/Thumbnail/Slideset/{{slideSetId}}/Slide/{{slideId}}')(op), data: op.data });
	}

	function cloneSlide(op) {
		_.ensureHasKeys(op, 'slideSetId', 'slideId');
		return serverUtils.put({ url: _.template('/api/Slideset/{{slideSetId}}/Slide/{{slideId}}/Clone')(op) });
 	}
	function updateSlide(slide) {
		return serverUtils.put({ url: '/api/Slide', data:slide });
	}

	function saveSlidesetDescriptors(ss) {
		var op = {slidesetId: (ss.slidesetId || ss.Id )}
		return serverUtils.put({
			url: _.template('/api/Slideset/{{slidesetId}}/Descriptors')(op)
			,data: ss
		})
	}

	function getSlideSetParameters(slideSetId) {
		return $.getJSON(_.template('/api/Slideset/{{slideSetId}}/Parameter/')({ slideSetId: slideSetId }))
	}

	function markParameterDefaultSelection(op) {
		_.ensureHasKeys(op, 'slidesetId', 'parameterId', 'value');
		return serverUtils.put({
			url: _.template('/api/Slideset/{{slidesetId}}/Parameter/{{parameterId}}/DefaultSelection')(op)
			,data: op.value
		});
	}

	function getDatamartHierarchyParameterValues(datamartName) {
		return $.getJSON('/api/Datamart/'+datamartName+'/Parameters/');
	}

	function modifySlidesetRelationOrder(urlTemplate){ return function modifySlidesetRelationOrder(slidesetId, orderedIds) {
		return serverUtils.put({
			url: _.template(urlTemplate)({ slidesetId: slidesetId }),
			data: orderedIds
		})
	} }

	function useParameter(slidesetId, parameterId) {
		return serverUtils.put({
			url: _.template('/api/Slideset/{{slidesetId}}/UsedParameter/{{parameterId}}')({ slidesetId: slidesetId, parameterId: parameterId })
		})
	}
	function stopUsingParameter(slidesetId, parameterId) {
		return serverUtils.del({
			url: _.template('/api/Slideset/{{slidesetId}}/UsedParameter/{{parameterId}}')({ slidesetId: slidesetId, parameterId: parameterId })
		})
	}

	function modifyUsedParameter(op) {
		_.ensureHasKeys(op, 'slideSetId', 'parameterId', 'data');

		return serverUtils.put({
			url: _.template('/api/Slideset/{{slideSetId}}/UsedParameter/{{parameterId}}/Configure')(op),
			data: op.data
		});
	}

	function useSlide(slidesetId, slideId) {
		return serverUtils.put({
			url: _.template('/api/Slideset/{{slidesetId}}/UsedSlide/{{slideId}}')({ slidesetId: slidesetId, slideId: slideId })
		});
	}
	function stopUsingSlide(slidesetId, slideId) {
		return serverUtils.del({
			url: _.template('/api/Slideset/{{slidesetId}}/UsedSlide/{{slideId}}')({ slidesetId: slidesetId, slideId: slideId })
		});
	}

	function updateSlideSlidesetContext(op) {		
		_.ensureHasKeys(op, 'slideId', 'slidesetId')
		return serverUtils.put({
			url: _.template('/api/Slide/{{slideId}}/Usage/{{slidesetId}}')(op),
			data: op
		});
	}

	function deleteSlideSet(slidesetId) {
		return serverUtils.del({
			url: _.template('/api/Slideset/{{slidesetId}}/Delete')({ slidesetId: slidesetId })
		});
	}

	function getSlideSetParam(op) {
		_.ensureHasKeys(op, 'slideSetId', 'parameterId', 'allSelections');
		var selections = (_.isString(op.allSelections) ? op.allSelections : JSON.stringify(op.allSelections));
		return serverUtils.post({
			url: _.template('/api/Selections/SlideSet/{{slideSetId}}/Parameter/{{parameterId}}')(op),
			data: selections
		});
	}

	function getEditorParameterOptions(op) {
		_.ensureHasKeys(op, 'parameterId', 'datamart', 'allSelections');
		return $.getJSON(_.template('/api/ParamOptions/{{parameterId}}')(op), {
			datamartConnectionStringName: op.datamart,
			allSelections: JSON.stringify(op.allSelections)
		});
	}

	function getSlidesetParameterValues(op) {
		_.ensureHasKeys(op, 'slidesetId', 'parameterId', 'parameterValues');
		return serverUtils.post({
			url: _.template('/api/Selections/Slideset/{{slidesetId}}/Parameter/{{parameterId}}')(op),
			data: op.parameterValues
		});
	}

	function getHierarchyParamOptions(parameter, preRequisiteSelections) {
		return $.getJSON(_.template('/api/Datamart/HierarchyParam/{{paramId}}')({ paramId: parameter.Id }), {
			allSelections: JSON.stringify(preRequisiteSelections)
		});
	}

	function getHierarchyParameter() {
		return $.getJSON('/api/HierarchyParameter');
	}

	function newHierarchyParameter(data) {
		return serverUtils.post({ url: '/api/HierarchyParameter', data: data });
	}
	function deleteHierarchyParameter(id) {
		return serverUtils.del({ url: _.template('/api/HierarchyParameter/{{id}}')({ id: id }) });
	}
	function saveHierarchyParameter(id, data) {
		return serverUtils.put({ url: _.template('/api/HierarchyParameter/{{id}}')({ id: id }), data: data });
	}

	function getSlide(id) {
		return $.getJSON(_.template('/api/Slides/{{id}}')({ id: id }));
	}

	function newCommonParameter(data) {
		return serverUtils.post({ url: '/api/CommonParameter', data: data });
	}

	function deleteCommonParameter(id) {
		return serverUtils.del({ url: _.template('/api/CommonParameter/{{id}}')({ id: id }) });
	}

	function saveCommonParameter(id, data) {
		return serverUtils.put({ url: _.template('/api/CommonParameter/{{id}}')({ id: id }), data: data });
	}

	function getParameters() {
		return $.getJSON('/api/Params');
	}

	function newParameter(data) {
		return serverUtils.post({ url: '/api/Params', data: data });
	}

	function deleteParameter(id) {
		return serverUtils.del({ url: _.template('/api/Params/{{id}}')({ id: id }) });
	}

	function saveParameter(id, data) {
		return serverUtils.put({ url: _.template('/api/Params/{{id}}')({ id: id }), data: data });
	}

	function getCommonParameters(datamart) {
		return $.getJSON(_.template('/api/CommonParameters/{{datamartName}}')({ datamartName: datamart }));
	}

	function getCommonParamOptions(preRequisiteSelections, paramId) {
		return $.getJSON(_.template('/api/Datamart/CommonParam/{{paramId}}')({ paramId: paramId }), {
			allSelections: JSON.stringify(preRequisiteSelections)
		});
	}

	function getHierarchyParameters(datamart) {
		return $.getJSON(_.template('/api/HierarchyParameters/{{datamartName}}')({ datamartName: datamart }));
	}

	function getSlideAssets() {
		return $.getJSON(appPath + 'api/SlideAssetsImages');
	}

	function getSlideData(op, paramSelections) {
		_.ensureHasKeys(op, 'slideSetId', 'slideId');
		var template = '/api/Slideset/{{slideSetId}}/Slide/{{slideId}}/Data'
			+ (_.has(op, 'includeLocalization') ? '/?includeLocalization={{includeLocalization}}' : '');
		return serverUtils.post({
			url: _.template(template)(op),
			data: ko.toJSON(paramSelections)
		});
	}

	function getLocalizationData() {
		return $.getJSON(appPath + 'api/Slides/LocalizationData');
	}

	function availableSlideSetsDefinitionsFor(datamartName, selections) {
		return $.getJSON( _.template('/api/Datamart/{{datamartName}}/AvailableSlidesets')({datamartName: datamartName}), {selections: selections} );
	}

	function getSlideSetsForEditor() {
		return $.getJSON('/api/Slidesets/AllSlidesetsForEditor');
	}

	function exportRenderedSlideSets(options) {
		_.ensureHasKeys(options, 'renderingParameters');
		var opt = {
			renderingParameters: JSON.stringify(options.renderingParameters)
			, type: options.type || ''
		}
	
		return fileDownload("/SlideSets/Download/" + opt.type, { httpMethod: "POST", data: "renderingParameters=" + encodeURIComponent( opt.renderingParameters )});
	}

	function renderSlideSetsInNewWindow(options) {
		_.ensureHasKeys(options, 'renderingParameters');
		return serverUtils.post({
			url: "/api/SlideSets/Render/Prepare"
			, data: { renderingParameters: JSON.stringify(options.renderingParameters) }
		}).then(serverUtils.getLocationHeader).then(openWindow);
	}

	function strippedSlideSetInNewWindow(options) {
		_.ensureHasKeys(options, 'renderingParameters');
		serverUtils.post({
			url: "/api/SlideSets/DirectLink/Prepare"
			, data: { renderingParameters: JSON.stringify(options.renderingParameters) }
		}).then(serverUtils.getLocationHeader).then(openWindow);
	}

	function renderHtmlAs(op, type) {
		_.ensureHasKeys(op, 'documents');
		type = type || 'Pdf';
		serverUtils.post({
			url: _.template('/api/{{type}}/Rendered')({type: type})
			, data: op
		}).then(serverUtils.getLocationHeader).then(openWindow);
	}

	function openWindow(uri) {
		window.open(uri) || (window.location.href = uri);
	}

	function downloadHtmlAs(op, type) {
		_.ensureHasKeys(op, 'documents');
		type = type || 'Pdf';

		serverUtils.post({
			url: '/api/' + type
			, data: op
		}).then(serverUtils.getLocationHeader).then(fileDownload);
	}

	function downloadQueryReport(detailed,op) {
		_.ensureHasKeys(op, 'sqlDataParams', 'slideId', 'slideSetId');
		var template = detailed ? '/api/SlideSet/{{slideSetId}}/Slide/{{slideId}}/DetailedQueryReport/Excel' : '/api/SlideSet/{{slideSetId}}/Slide/{{slideId}}/QueryReport/Excel'
		var url = _.template(template)(op);
				
		return fileDownload(url, { httpMethod: "POST", data: op.sqlDataParams });
	}
});
