﻿define(
['knockout', 'underscore',
 'apiUrls', 'generateReportName', 'slideRenderingUtils',
 'bindKeyboardShortcuts', 'bindFullScreenToSliderAndSlide', 'bindMobileDeviceEvent', 'slideResizer', 'slideDownloadTimeProvider',
 'knockoutExtensions', 'knockout.clickover'],
function (
    ko, _,
    api, generateReportName, slideRenderingUtils,
    bindKeyboardShortcuts, bindFullScreen, bindMobileDeviceEvent, slideResizer, slideDownloadTimeProvider) {
	'use strict';

	// This is the viewmodel for a single opened slideset in the viewer part of the application, in the bottom right part of the /Slidesets/datamartConnectionString file.
	// Includes the slideset, the slide actions, and the slideset actions (print/export)

	return function slideSetViewer(model) {
		var _viewer = {
		  printSlideSet: exportCurrentSlideSets(api.renderSlideSetsInNewWindow)
		, directLinkToSlideSet: exportCurrentSlideSet(api.strippedSlideSetInNewWindow)
        , exportSlideSetPdf: exportCurrentSlideSets(api.exportRenderedSlideSets, 'Pdf')
        , exportSlideSetPptx: exportCurrentSlideSets(api.exportRenderedSlideSets, 'Pptx')
		, printCurrentSlidePdf: printCurrentSlide('Pdf')
		, resizer: slideResizer()
		, isInFullScreenMode: ko.observable(false)
		, toggleFullScreen: _.partial(bindFullScreen.toggleFullScreen, '.slidesets-viewer .current-slide')
		, exportSlide: ko.observable(null)
		, currentSlideSet: ko.observable(null)
		, isSlideHelpVisible: ko.observable(false)
		, isExportRunning: ko.observable(false)
		, redrawErrors: ko.observable('')
		, expectedDownloadTime : ko.observable(null)
		, fitSlideToScreen : ko.observable(!!model.fitSlideToScreen)
		};
		
		_viewer.currentSlide = ko.forcibleComputed(getSlideSetInstanceCurrentSlide);
		_viewer.nextSlide = ko.forcibleComputed(function () { return getSlideSetInstance() && getSlideSetInstance().nextSlide(); });
		_viewer.prevSlide = ko.forcibleComputed(function () { return getSlideSetInstance() && getSlideSetInstance().prevSlide(); });
		_viewer.estimatedTimeLeft = ko.forcibleComputed(function () {
			if (!_viewer.expectedDownloadTime()) return;

			var date = new Date(_viewer.expectedDownloadTime().timeRemaining());
			if (date.getMinutes() != 0) {
				return date.getMinutes() + ":" + pad2(date.getSeconds());
			} else {
				return date.getSeconds() + "(s)";
			}
		});

		function pad2(number) { return ((number < 10) ? '0' : '') + number; }

		_viewer.numberOfSlides = ko.computed(function () {
			return getSlideSetInstance() ? getSlideSetInstance().slides().length : 0;
		});
		_viewer.currentSlideNumber = ko.computed(function () {
				return getSlideSetInstance() ? (getSlideSetInstance().currentSlideIndex() + 1) : 0;
		});
		_viewer.updateSlideNumber = function (data, event) {
			if (event.keyCode === 13 || event.type === "blur") 
				getSlideSetInstance().moveToSlideNumber(event.target.value);
		}
		_viewer.redrawingCallback = function(promise) {
			promise
				.always(_.partial(_viewer.redrawErrors, ""))
				.fail(_viewer.redrawErrors);
		}
		
		_viewer.goToSlideWithIdCallback = $.Callbacks().add(function(slideId, occurence) {
			getSlideSetInstance() && getSlideSetInstance().moveToSlideWithId(slideId, occurence);
		});
		_viewer.slideSetExportDisabled = ko.computed(function () {
			return !_viewer.currentSlideSet() || _viewer.isExportRunning();
		});

		//will display in export section link
		_viewer.strippedLinkVisible = model.strippedLinkVisible;

		var _exportSlide = {
			exportCurrentSlidePdf: downloadCurrentSlide('Pdf')
			, exportCurrentSlidePptx: downloadCurrentSlide('Pptx')
			, exportQueryReport: downloadQueryReport
			, exportDetailedQueryReport: downloadDetailedQueryReport
			, hasDetailedQueryReport: ko.computed(function () {
				return _viewer.currentSlide() && _viewer.currentSlide().slideDefinition.HasDetailedReport;
			})
		};

		_viewer.toggleExportSlideManually = function () {
			_viewer.exportSlide(_exportSlide);
		};

		_viewer.toggleHelp = function () {
			_viewer.isSlideHelpVisible(!_viewer.isSlideHelpVisible());
		}	

		var adjustSlideSize = _.throttle(function () {
			var slideContainerSelector = '.slide-view-container';
			var paddingPercent = 8;
			if (_viewer.fitSlideToScreen())
				_viewer.resizer.changeSizeToFitElement(slideContainerSelector, paddingPercent);
			else
				_viewer.resizer.changeOptionToFitElement(slideContainerSelector, paddingPercent);
		}, 200);

		// this function is called once during initialization of the zoom slider
		_viewer.getFittedSlideSizeObservable = function () {
			// set initial slide size depending on the _viewer.fitSlideToScreen value
			if (_viewer.fitSlideToScreen())
				// we have to try adjusting size several times because the slide container changes its size during page loading and initialization
				_.times(20, function (n) { _.delay(adjustSlideSize, 300 * n); }); // do it every 300 ms during 6 seconds 
			else 
				adjustSlideSize();
			setupAutoResizing();

			return _viewer.resizer.slideSize;
		}

		_viewer.fitSlideToScreen.subscribe(function () {
			adjustSlideSize();
			setupAutoResizing();
		});

		bindKeyboardShortcuts([
			{ keycodes: [39, 40], callback: nextSlide },
			{ keycodes: [37, 38], callback: prevSlide }
		]);

		bindMobileDeviceEvent("swipeleft", nextSlide, '.slide-view-container');
		bindMobileDeviceEvent("swiperight", prevSlide, '.slide-view-container');

		bindFullScreen.init({
			slideResizer: _viewer.resizer
			, sliderSelector: '.slidesets-viewer #slider'
			, scaleToFitElementSelector: '.slide-view-container'
			, fullScreenChangingCallback: _viewer.isInFullScreenMode
		});

		return _viewer;

		function setupAutoResizing() {
			if (_viewer.fitSlideToScreen())
				$(window).resize(adjustSlideSize);
			else
				$(window).off("resize", adjustSlideSize);
		}

		function nextSlide() {
			_viewer.nextSlide() && _viewer.nextSlide()();
		}

		function prevSlide() {
			_viewer.prevSlide() && _viewer.prevSlide()();
		}

		function getSlideSetInstance() { return _viewer.currentSlideSet() ? _viewer.currentSlideSet().slideSetInstance : null; }

		function getSlideSetInstanceCurrentSlide() { return getSlideSetInstance() ? getSlideSetInstance().currentSlide() : null; }

		function getSlideSetsRenderingParametersForExport(slideSets) {
			var selected = _.chain(slideSets)
				.where({ isSelected: true })
				.map(function (ss) {
					return {
						slideSetId: ss.slideSetDefinition.SlideSetId
						, parameterSelections: ss.parameterValuesAndDescriptionsHash
						, name: getReportName(ss.slideSetDefinition.Name, ss)
						, includeSlideRange: JSON.stringify(ss.slideSetInstance.slideRange)
					}
				}).value();
			return selected;
		}

		function exportCurrentSlideSets(apiRender, type) {
			return function () {
				
				_viewer.isExportRunning(true);

				//we do not use server API url because it is not datamart specific and it is hidden in apiUrls
				//instead we take current page URL as a key and add export type
				var url = window.location.hostname + window.location.pathname +'/'+ type;
				var slidesNumber = _.chain(model.openSlideSets())
									.filter(function (openSlideSet) {
										return openSlideSet.isSelected;
									})
									.map(function (selectedOpenSlideSet) {
										return selectedOpenSlideSet.slideSetInstance.slides().length;
									})
									.reduce(function (memo, num) { return memo + num; }, 0)
									.value();

				var provider = slideDownloadTimeProvider({
					url: url,
					slidesNumber: slidesNumber
				});

				_viewer.expectedDownloadTime(provider.startDownloading());
				apiRender(
					{
						renderingParameters: getSlideSetsRenderingParametersForExport(model.openSlideSets())
						, type: type || null
					}
				).always(function () {
					provider.downloadFinished();					
					_viewer.isExportRunning(false);
				});
			}
		}

		function exportCurrentSlideSet(apiRender, type) {
			return function () {
				apiRender(
					{
						renderingParameters: getSlideSetsRenderingParametersForExport([_viewer.currentSlideSet()])
						, type: type || null
					}
				);
			}
		}		

		function printCurrentSlide(type) {
			return function () {
				api.renderHtmlAs(getRenderSlideParameters(), type);
			}
		}

		function getRenderSlideParameters() {
			var html = slideRenderingUtils.documentOf('.current-slide iframe').all[0].innerHTML
					, parameterDescriptions = _viewer.currentSlideSet().descriptions
					, name = generateReportName({ name: _viewer.currentSlide().slideDefinition.Name, parameterDescriptions: parameterDescriptions })
			;
			return { documents: [html], name: name };
		}

		function downloadCurrentSlide(type) {
			return function () {
				api.downloadHtmlAs(getRenderSlideParameters(), type);
			};
		}

		function getQueryReportParameters() {
			return {
				sqlDataParams: _.extend(_viewer.currentSlide().slideData.parameters, _viewer.currentSlideSet().parameterValuesAndDescriptionsHash)
				, slideId: _viewer.currentSlide().slideDefinition.SlideId
				, slideSetId: _viewer.currentSlideSet().slideSetDefinition.SlideSetId
			}
		}
		function downloadQueryReport() {
			api.downloadQueryReport(getQueryReportParameters());
		}

		function downloadDetailedQueryReport() {
			api.downloadDetailedQueryReport(getQueryReportParameters());
		}

		function getReportName(baseName, ssNode) {
			return generateReportName({
				name: baseName
					, parameterDescriptions: ssNode.descriptions
			});
		}
	};
});