﻿define(['knockout', 'underscore', 'slideSetViewer3', 'slideSetInstance'],
function (ko, _, slideSetViewer, slideSetInstance) {
	'use strict';

	// This is the viewmodel for a full page that only shows the bottom-right part of the /Slidesets/datamartConnectionString UI

	return function strippedSlideSetViewer(model) {
		_.ensureHasKeys(model, 'slideSetDefinition', 'parameterSelections');
		updateSlideRange(model);

		var slideSet = createSlideSetInstanceNode(model.slideSetDefinition, model.parameterSelections, model.includeSlideRange);

		var _slideSetViewer = slideSetViewer({
			openSlideSets: ko.observableArray([slideSet]),
			fitSlideToScreen: model.fitSlideToScreen
		});

		var _viewer = {
			slideSet: _slideSetViewer.currentSlideSet(slideSet)
		};
	
		ko.applyBindings(_viewer, document.getElementById('main'));

		//When no includeSlideRange defined put null. slideSetInstance will fill it by default to all included
		function updateSlideRange(model) {
			model.includeSlideRange = model.includeSlideRange ? JSON.parse(model.includeSlideRange) : null;
		}

		function createSlideSetInstanceNode(slideSetDefinition, parameterSelections, slideRange) {

			var node = {
				slideSetDefinition: slideSetDefinition
				, parameterSelections: parameterSelections
				, slideSetInstance: slideSetInstance(slideSetDefinition, parameterSelections, null, slideRange)
				, parameterValuesAndDescriptionsHash: parameterSelections
				, isSelected: ko.observable(true)
				, isCurrent: ko.observable(true)
				, redrawErrors: ko.observable('')
			}

			node.redrawingCallback = function (promise) {
				promise
					.always(_.partial(_slideSetInstance.redrawErrors, ""))
					.fail(_slideSetInstance.redrawErrors);
			}

			node.isLoading = ko.computed(function () { return !node.slideSetInstance.isFullyLoaded() });
			node.title = ko.computed(function () {
				return this.slideSetDefinition.Name;
			}, node);

			return node;
		}
	}
})