define(
['d3', 'underscore'],
function(d3, _) {

    // IE 9 does not correctly coerce property values to strings (see https://github.com/mbostock/d3/issues/1371)
    // Almost everything in D3 V3 takes care of this, but the axis() method does not, setting opacity to 1e-6 instead of (1e-6).toString().
	if (/MSIE 9/.test(navigator.userAgent)) {
		d3.selection.prototype._style = d3.selection.prototype.style;
		d3.selection.prototype.style = function () {
			var args = [];
			for (var name in arguments)
				args.push(arguments[name].toString());
			return d3.selection.prototype._style.apply(this, args);
		};
	}

  //Create a method on d3 that allows easily extending all the basic prototypes
  //this is a work in progress
  d3.mixin = d3.mixin || function(name, val) {
    if (_.isObject(name)) {
      return _.each(name, function(v, k) {
        return d3.mixin(k, v);
      });
    }

    d3.selection.enter.prototype[name] = val;
    d3.selection.prototype[name] = val;
    return d3.transition.prototype[name] = val;
  };

  d3.mixin({

  	// Allow setting multiple attributes at once using a js object
  	//  selection.attrObj({
  	//	   x: 100
  	//    ,y: 100
  	//  });
    attrObj: acceptObject('attr')

  	// Allow setting multiple styles at once using a js object
  	//  selection.styleObj({
  	//	   fill: 'none'
  	//    ,stroke: 'blue'
  	//  })
    ,styleObj: acceptObject('style')

    // Similar to apppend but prepend a node
    // from https://github.com/mbostock/d3/issues/4
    ,prepend: function(el) { return this.insert(el, ":first-child"); }

  	// Sum of a scalar array. To save us a thousand _.reduce(array, function(memo, num)... function calls in the slides
	, sum: function(array) {
		return _.reduce(array, function (memo, num) {
			return memo + num;
		}, 0);
	}
  });


  function acceptObject(fnName) {
    return function(obj) {
      var _this = this;
      _.each(obj, function(val, key) {
        return _this[fnName](key, val);
      });
      return this;
    };
  };



});