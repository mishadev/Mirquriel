define(['jquery', 'knockout', 'underscore', 'sammy', 'slideSetsViewer', 'slideSets'], function ($, ko, _, sammy, newSlideSetsViewer, newSlideSets) {
    'use strict';

	// This file backs the SPA-style homepage (route #/).  Mostly obsolete now that we're using /SlideSets/datamartConnectionString.  
    // We can get rid of it as soon as we decide what the new homepage should be (or if it should just be "set a default datamart").
    var  defaultRoute = '#/'
        ,slideSets    = newSlideSets()
        ;
    var viewStates = {          //each different view type and how to initialize it
         slideSetsViewer:       function() { return newSlideSetsViewer({ slideSets: slideSets }) }
    };

    var _viewer = {
         slideSets:             slideSets
        ,resetViewer:               gotoRoute(defaultRoute)
        ,slideSetsViewer:           ko.observable(null)
    };


    // wire up 'home' button in Oaf.Header, since we don't want it to reload the page, just call the resetViewer() function instead
    $('.tool-menu-home').click( _viewer.resetViewer );

    var sammyApp = sammy(initializeClientRouting);
    sammyApp.raise_errors = true;
    _.defer(function() { sammyApp.run(window.location.hash||defaultRoute) } );

    ko.applyBindings(_viewer, document.getElementById('main'));
    setupDepressable();  
    return _viewer;
    
    ///////////////////////////////////////////////////

    function initializeClientRouting(app) {
        app.get(defaultRoute, changeViewState('slideSetsViewer', function(){
            return newSlideSetsViewer({ slideSets: slideSets });
        }));
    }

    function gotoRoute(route) { return function(){
        window.location.hash = _.isFunction(route) ? route .apply(this, arguments) : route
    } }

    function changeViewState(state, fn) { 
        var  viewStates = ['slideSetsViewer'] //TODO - GM - this doesn't actually work with the reportTreeMenu plugin architecture, Fortunately currently the page is always reloaded.
            ;
        return function changeViewState() {
            if( _viewer[state]() )  //already on this viewstate if it is not null
                return;                                                      
            _.each(viewStates, function(s) {           //null out all other viewstates
                _viewer[s]() && _viewer[s]().dispose && _viewer[s]().dispose();
                _viewer[s](null);
            } );       
            _viewer[state]( fn() );
        }
    };

    function setupDepressable(){
        //TODO - MB - put this somewhere else?
        $(document).on('mousedown', '.depressable', function onDepressed(e) {
          $(e.currentTarget).addClass('depressed');
          $(window).one('mouseout', function () {
            $(e.currentTarget).removeClass('depressed');
          });
        });        
    }
});