﻿define(['knockout', 'underscore', 'slideSetInstance'], 
function (ko, _, slideSetInstance) {
	'use strict';

	// This is the full-page view-model for a single slideset in its very simplest form -- just the slide iframes
	// Used when rendering a slideset for rasterization, maybe.  (used in RenderSlideset.cshtml)

return function slideSetViewer(model) {
    _.ensureHasKeys(model, 'slideSetDefinition', 'parameterSelections');
    var _slideSetInstance = slideSetInstance(model.slideSetDefinition, model.parameterSelections, false, getSlideRange(model), model.skipSlides, model.takeSlides);

    _slideSetInstance.redrawErrors = ko.observable('');
    _slideSetInstance.redrawing = function (promise) {
    	promise
			.always(_.partial(_slideSetInstance.redrawErrors, ""))
			.fail(_slideSetInstance.redrawErrors);
    }

    ko.applyBindings(_slideSetInstance, document.getElementById('single-slideset-viewer'));

	//When no includeSlideRange defined put null. slideSetInstance will fill it by default to all included
    function getSlideRange(model) {
    	return model.includeSlideRange ? JSON.parse(model.includeSlideRange) : null;
    }
}
})