define(
['knockout', 'underscore', 'jquery.fileDownload', 'serverUtils', 'slideDownloadTimeProvider', 'generateReportName'],
function (ko, _, fileDownload, serverUtils, slideDownloadTimeProvider, generateReportName) {
	'use strict'

	//Issue api calls to generate a slideDeck report in one of the supported formats
	//In a REST fashion, POSTs information to the renderUrl and then follows the returned Location header to download the
	//report. Note that download occurs via the jquery.fileDownload plugin which requires the second response to also
	//set a cookie so that it knows when the download has finished.
	//
	//This module also maintains statistics (in storage) on how long report generation of different type takes. This
	//is used to make an evidence-based guess on how long the given operation might take. This data is exposed in an object
	//which is passed to an optional callback function (slideInfoModel). This object includes a running countdown for the estimated time 
	//remaining in the timeRemaining key and an error (if any) in the error key. A recommended usage is to pass in a knockout
	//observable which can then be bound to an on-screen display
	//
	//Usage: slideDeckDownloader({
	//	 url: '/api/Rasterizer/Pdf'
	//  ,slideHtmlList: [slideHtml1, slideHtml2]
	//  ,name: "Desired Filename for Download"
	//  ,paramContext: pc        //optionally pass param context to append current parameter selections to name
	//  ,setInfoModel: downloadInfoModel
	// })
	return function download(op){
		_.ensureHasKeys(op, 'url', 'slideHtmlList');
		_.defaults(op, {
			setInfoModel: _.identity
		});

		var timeDownloadProvider = slideDownloadTimeProvider({
			url: op.url,
			slidesNumber: op.slideHtmlList.length
		});
		op.setInfoModel(timeDownloadProvider.startDownloading());

		return serverUtils.post({
				 url:  op.url
				,data: { documents: _.toArray(op.slideHtmlList), name: generateReportName(op) }
			}) .then(serverUtils.getLocationHeader).then(function startDownload(url){
				return fileDownload(url)
					.always(closeDownloadingDialog)				
					.fail(downloadError)
			});

		/////////////////////////////////////

		function closeDownloadingDialog() {
			timeDownloadProvider.downloadFinished();

		}		
		function downloadError() {
			downloadInfoModel.error("Something went wrong!")
			console.error("something went wrong with the download", arguments);	
		}	
	}

})