﻿define(
['knockout', 'jquery', 'underscore'],
function (ko, $, _) {

	var arrowHeight = 10
	, arrowWidth = 22
	, offsetFromBorders = 10
	, bodyHandlerNameTemplate = "click.knockoutClickover{{id}} touchstart.knockoutClickover{{id}}"
	, bodyHandlerNameTemplateWithKeydown = bodyHandlerNameTemplate +" keydown.knockoutClickover{{id}}"
	, id = 0;

	function createClickOver() {
		var clickover = {
			init: ko.bindingHandlers['with'].init
			, setPopoverPosition: function (popover, placementElement, arrow) {
				setPopoverPositionRelativelyToPlacement(popover, placementElement);
				setArrowPositionRelativelyToPlacement(popover, placementElement, arrow);
			}
		}

		clickover.bodyHandlerName = getBodyHandlerNameFromTemplate(bodyHandlerNameTemplate);

		clickover.update = function (el, valueAccessor) {
			var val = valueAccessor()
				, $el = $(el)
			;
			if (ko.unwrap(val)) {
				$el.css('z-index', 1010);
				var $arrow = $('<div>').addClass('arrow').prependTo($el);
				clickover.setPopoverPosition($el, $el.prev(), $arrow);
				createBodyHandler(val, $el, clickover.bodyHandlerName);
			} else {
				removeBodyHandler(clickover.bodyHandlerName);
			}
		}

		return clickover;
	}

	// Binding handler for an element that will appear as a (manually created, non-boostrap) clickover/popover. On a logical level
	// functions exactly like a `with` knockout binding. When the bound value is truthy it will style it in a clickover with an arrow
	// setting the bound observable to falsy will close the popover. Clicking outside of the clickover will also set the observable as falsy
	// Currently the arrow points to the previous element and is positioned on the left.
	ko.bindingHandlers.clickover = createClickOver();

	function createBodyHandler(setObservable, element, bodyHandlerName) {
		_.defer(function () {
			$('body').on(bodyHandlerName, function (e) {
				if (!element.has(e.target).length)
					setObservable(null);
			})
		});
	}

	function removeBodyHandler(bodyHandlerName) {
		_.defer(function () {
			$('body').off(bodyHandlerName);
		});
	}

	function getBodyHandlerNameFromTemplate(template) {
		return _.template(template)({ id: id++ });
	}

	function setPopoverPositionRelativelyToPlacement(popover, placementElement) {
		var placementElementTop = placementElement.offset().top;
		var placementElementHeight = placementElement.height();
		var windowHeight = $(window).height();
		var popoverHeight = popover.height();
		var desiredTop = windowHeight / 2 - popoverHeight / 2;
		var newTop = desiredTop;

		if (desiredTop > placementElementTop)
			newTop = placementElementTop - arrowHeight;

		if (desiredTop + popoverHeight < placementElementTop + placementElementHeight)
			newTop = placementElementTop - popoverHeight + placementElementHeight + arrowHeight;

		if (newTop < offsetFromBorders)
			newTop = offsetFromBorders;

		if (newTop + popoverHeight > windowHeight - offsetFromBorders)
			newTop = windowHeight - popoverHeight - offsetFromBorders;

		popover.offset({ top: newTop, left: (placementElement.width() + placementElement.offset().left + 15) });
	};

	function setArrowPositionRelativelyToPlacement(popover, placementElement, arrow) {
		var middle = placementElement.offset().top + placementElement.height() / 2
			, popoverTop = popover.offset().top
			, desiredTop = middle - (arrowHeight / 2) - 3;
		;
		if (desiredTop < popoverTop + offsetFromBorders)
			desiredTop = popoverTop + offsetFromBorders;
		if (desiredTop > popoverTop + popover.height() - offsetFromBorders - arrowHeight)
			desiredTop = popoverTop + popover.height() - offsetFromBorders - arrowHeight;
		arrow.offset({ top: desiredTop, left: arrow.offset().left });
	};

	ko.bindingHandlers.clickoverTop = _.extend(createClickOver(), {
		setPopoverPosition: function (popover, placementElement, arrow) {
			_.defer(function () {
				setPopoverRelativelyToPlacementTop(popover, placementElement);
				setArrowPositionRelativelyToPlacementTop(popover, placementElement, arrow);
			});
		}, bodyHandlerName: getBodyHandlerNameFromTemplate(bodyHandlerNameTemplateWithKeydown)
	});

	function setPopoverRelativelyToPlacementTop(popover, placementElement) {
		var placementElementTop = placementElement.offset().top;
		var placementElementLeft = placementElement.offset().left;
		var placementElementWidth = placementElement.width();
		var popoverHeight = popover.height();
		var popoverWidth = popover.width();
		var windowWidth = $(window).width();

		var desiredTop = placementElementTop - popoverHeight - arrowHeight * 2;
		var newTop = desiredTop;

		if (desiredTop < offsetFromBorders)
			newTop = offsetFromBorders;

		var desiredLeft = placementElementLeft + placementElementWidth / 2 - arrowHeight;
		var newLeft = desiredLeft;

		if (newLeft < offsetFromBorders)
			newLeft = offsetFromBorders;
		if (newLeft + popoverWidth > windowWidth - offsetFromBorders)
			newLeft = windowWidth - offsetFromBorders - popoverWidth;

		popover.offset({ top: newTop, left: newLeft });
	};

	function setArrowPositionRelativelyToPlacementTop(popover, placementElement, arrow) {
		var desiredMiddle = placementElement.offset().left + placementElement.width() / 2 - arrowWidth / 2;

		arrow.offset({ top: popover.offset().top + popover.height() + 3, left: desiredMiddle });
	};

})