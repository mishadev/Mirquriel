define([
	'knockout',
	'jquery',
	'underscore'
],
function (ko, $, _) {

	//	Binding for subscribe to ko.observable's and invoke widget methods or functions as handler
	//	"handler" - function or options to call widget method
	//		options case:
	//		"widget" - name of the jquery widget you want to invoke the method
	//			NOTE:	you could set widget with namespace like 'namespace.widgetname' to avoid possible collisions
	//		"method" - method of the widget that will be called
	//	"observables" - array or one observable for subscribe.
	//		NOTE:	if you could use it as "observables: $parent.someMethod" or "observables: [$parent.someMethod1, $parent.someMethod2]"
	//				it will ignore any not ko.observable's in the list
	//	Usage:
	//	<button data-bind="subscribe: {
	//		observables: $parent.isSlideHelpVisible,
	//		handler: { widget:'slideView', method:'toggleHelp' }
	//	}"></button>
	ko.bindingHandlers.subscribe = {
		init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
			var options = valueAccessor() || {},
				handler = options.handler,
				observables = toArray(options.observables);

			observables = _.isArray(observables) && _.filter(observables, function (obs) { return ko.isObservable(obs); });
			if (observables && _.any(observables)) {
				_.each(observables, function (observable) {
					var subscription = observable.subscribe(function (value) {
						if (_.isFunction(handler))
							invokeFunctionHandler(handler, element, value);
						else if (_.isObject(handler))
							invokeWidgetHandler(handler, element, value);
					});

					ko.utils.domNodeDisposal.addDisposeCallback(element, function () { subscription.dispose(); });
				});
			}
		}
	};

	function invokeFunctionHandler(handler, element, value) {
		handler.apply(element, [value]);
	}

	function invokeWidgetHandler(handler, element, value) {
		var $element = $(element),
			widgetName = _.last(handler.widget.split('.')),
			widget = $.fn[widgetName],
			method = (handler.method || '').trim();

		if ($element.length && widget && method && hasWidget($element, handler.widget))
			$element[widgetName](method, value);
	}

	function hasWidget($element, fullname) {
		var fullnameArray = fullname.split('.').reverse(),
			name = fullnameArray[0],
			namespace = fullnameArray[1];

		if (namespace)
			return $element.is(':' + namespace + '-' + name); //it will throw exception is not find

		return _.any(_.keys($element.data()), function (prop) { return endWith(prop, '-' + name) });
	}

	function endWith(source, suffix) {
		return source.indexOf(suffix, source.length - suffix.length) !== -1;
	}

	function toArray(items) {
		if (!items) return items;
		if (_.isArray(items)) return items;

		return [items]
	}
});