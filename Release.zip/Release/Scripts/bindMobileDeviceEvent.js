define([
	'jquery', 'underscore',
	'hammerjs'
], function ($, _) {
	'use strict';

	var touchEvents = [
		'touch', 'release', 'gesture', 'hold', 'tap', 'doubletap', 'dragstart', 'drag',
		'dragend', 'dragleft', 'dragright', 'dragup', 'dragdown', 'swipe', 'swipeleft', 'swiperight',
		'swipeup', 'swipedown', 'transformstart', 'transform', 'transformend', 'rotate', 'pinch', 'pinchin', 'pinchout'
	];

	return function (eventName, handler, element) {
		var $element = _.isString(element) || _.isElement(element) ? $(element) : $(document);
		if (!_.isString(eventName) || !eventName || !_.contains(touchEvents, eventName.toLowerCase()) || !_.isFunction(handler))
			return;

		$element.hammer({ behavior: { userSelect: true } }).on(eventName, handler);
	};
});