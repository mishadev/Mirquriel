define(
['knockout', 'jquery', 'underscore', 'constants', 'slideRenderingUtils', 'jqueryUI', 'ow.widgets.persistState'],
function(ko, $, _, constants, renderingUtils) {
'use strict'

/*
  Create a slider that controls the size of nearby slide iframes.
  By default will scale all $(this).closest('section').find('.slide-scaling')
  The current scaling factor can be queried and set programmatically with the scale method
*/
$.widget('ogre.slideSizeSlider', {
    options: {
         orientation:   "vertical"
        ,range:         "min"
        ,min:           0.2
        ,max:           2
        ,step:          0.1
        ,value:         .3

        ,height:        300
        ,target:        function(el) { return el.closest('section').find('.slide-scaling'); }
        ,positionRight: true
        ,defer:         true     //false - scale immediately, true - scale after the current processing loop
    }

    ,_create: function() {
        this.options.height &&          this.element.css({ height: this.options.height });
        this.options.positionRight &&   this.element.css({ position: 'absolute', right: 5 });
        
        this.element.addClass('slide-size-slider').slider($.extend(this.options, {
            slide: _.bind(function(e, ui){
                this.scale(ui.value);
            }, this)
        }));

        if(ko.isObservable(this.options.value))
            this.element.on('slidesizesliderchange', _.leftShiftArgs(this.options.value) )
        var scale = _.bind(this.scale, this, this.options.value);
        this.options.defer ? _.defer(scale) : scale();
    }

    ,getTargets: function() {
        return evalOrSelect(this.element)(this.options.target);
    }
    ,scale: function(incomingVal){
        if(_.isUndefined(incomingVal))
        	return this.element.slider('option', 'value');
        var  val = ko.unwrap(incomingVal)
            ,newSize = {
                 width:     val*constants.SLIDE_VIEWBOX_WIDTH
                ,height:    val*constants.SLIDE_VIEWBOX_HEIGHT
                ,scale:     val
            };

		if (val > this.element.slider('option', 'max'))
			this.element.slider('option', 'max',  val);
		this.element.slider('option', 'value', val);
        this.getTargets().each(function(){
            renderingUtils.scale(this, newSize.scale);
            $(this).trigger('svgsizesliderresize', newSize);
        });
        this._trigger('change', null, val);
    }
    ,rescale: function() {
        this.scale( this.scale() );
    }
	, setExclusiveScale: function (value) {
		this.element.slider('option', 'min', value);
		this.element.slider('option', 'max', value);
	}
	, clearExclusiveScale: function () {
		this.element.slider('option', 'min', this.options.min);
		this.element.slider('option', 'max', this.options.max);
	}
});

//The persistState widget saves/restores the widget's current scale
$.ow.persistState.elementPersistence[':ogre-slideSizeSlider'] = {
    saveState: function($el) {
        return {scale: $el.slideSizeSlider('scale') };
    },
    restoreState: function($el, state) {
        if(!state) return;
        $el.slideSizeSlider('scale', state.scale);
    }
};

return $.ogre.slideSizeSlider;

function evalOrSelect() { 
    var args = arguments;
    return function(selectorOrFn) {
        return $( _.isFunction(selectorOrFn) ? selectorOrFn.apply(undefined, args) : selectorOrFn );
    }
}

});

