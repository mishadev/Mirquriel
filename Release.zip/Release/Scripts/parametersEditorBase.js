﻿define(
['jquery', 'knockout', 'underscore', 'knockout.mapping', 'parameters/editorParametersContext'],
function ($, ko, _, mapping, parametersContext) {
	'use strict';

	return function (parametersEditorApi, availableDatamarts, specificModifiableProperties) {
		var _parametersEditor = {
			newParameter: newParameter
			, deleteParameter: deleteParameter
			, parametersContext: parametersContext(parametersEditorApi, _.first(availableDatamarts), onParameterUpdated)
			, saving: ko.observable(0)
			, messages: ko.observable(null)
			, availableDatamarts: availableDatamarts
			, deleteParamConfirmation: ko.observable(null)
			, loading: ko.observable(false)
			, saveOnAllChanges: saveOnAllChanges
			, saveParameter: saveParameter
			, modifiableProps: ['Name', 'DisplayName', 'ParamType', 'EvaluationType', 'EvaluationSource']
		};

		if (_.isArray(specificModifiableProperties))
			_parametersEditor.modifiableProps = _parametersEditor.modifiableProps.concat(specificModifiableProperties);

		return _parametersEditor;

		function onParameterUpdated(oldparameter, newparameter) {
			var parameters = _parametersEditor.parametersContext.parameters();
			parameters[parameters.indexOf(oldparameter)] = newparameter;
			_parametersEditor.parametersContext.parameters(parameters);

			saveOnAllChanges(newparameter);
			saveParameter(newparameter);
		}

		function newParameter() {
			parametersEditorApi.newParameter()
				.then(function (model) {
					var parameter = _parametersEditor.parametersContext.addParameter(model);
					saveOnAllChanges(parameter);
				}).always(saving());
		}

		function deleteParameter(parameter) {
			_parametersEditor.deleteParamConfirmation({
				yes: function () {
					parametersEditorApi.deleteParameter(parameter.Id)
					.done(function () {
						_parametersEditor.parametersContext.deleteParameter(parameter);
					});
				}
			})
		}

		function saving() {
			_parametersEditor.saving(_parametersEditor.saving() + 1);
			return function () {
				_parametersEditor.saving(_parametersEditor.saving() - 1);
			}
		}

		function getDatamart(parameter) {
			return parameter.datamartConnectionStringName;
		}

		function saveOnAllChanges(parameter) {
			var triggerSave = _.debounce(function () { saveParameter(parameter) }, 500);
			_.each(_parametersEditor.modifiableProps, function (prop) {
				parameter[prop].subscribe(triggerSave);
			});
			return parameter;
		}

		function saveParameter(parameter) {
			parametersEditorApi.saveParameter(parameter.Id, parameter)
			.done(_.runWhen(isParameter, function (model) {
				model = _.omit(model, computedProps(parameter));
				mapping.fromJS(model, {}, parameter);
				_parametersEditor.parametersContext.parameterUpdated(parameter)
			})).always(saving());
		};

		function isParameter(x) { return x && _.has(x, 'Id'); }
		function computedProps(obj) {
			return _.compact(_.map(obj, function (v, k) { return ko.isComputed(v) && k; }));
		}
	}
});