define(['underscore', 'ow', 'localStorageWrapper'], function (_, ow, storage) {
// Since we are using storage there is state persisted in the browser. This means that it can get outdated and
// need to be migrated from version to version (eg the SlideSet model is cached but a field in it gets renamed so the cached versions must be cleared out). 
// This runs javascript code the first time a particular app version (or above) has been loaded.

	var log = (console && console.log && Function.prototype.bind.call(console.log, console)) || _.identity
	;
onVersionUpdate({
	 '2.5.6': removeKeysFromLocalStorage('/SlideSets/')
	,'2.10.1': removeKeysFromLocalStorage('/SlideSet/')
});

return { //return to enable testing of this module. Typically you don't have to do anything with the return value as loading the module runs real migration
	 onVersionUpdate: onVersionUpdate
	,compareVersions: compareVersions
};
//////////////////////////////

function removeKeysFromLocalStorage(containedString) { return function() {
	_.chain(storage)
		.keys().filter(function (k) { return ~k.indexOf(containedString) })
		.tap(_.partial(log, "Removing from storage:"))
		.each(storage.removeItem.bind(storage));
} }

function onVersionUpdate(migrations, prevVersion) { //prevVersion parameter useful for testing
	var  persistenceKey = 'onVersionUpdate/prevVersion'
		,prevVersion = prevVersion || storage.getItem(persistenceKey)
		,sorted         = _.keys(migrations).sort(compareVersions)
		;
	_.chain(sorted)
		.filter(function(v) { return compareVersions(prevVersion, v) > 0 }) //hasn't run before
		.filter(function(v) { return compareVersions(v, ow.Version) >= 0 }) //before current version
		.each(function(v){
			log("Applying client-side migration", v);
			migrations[v](v);
		})
	storage.setItem(persistenceKey, ow.Version);
}

function compareVersions(lhs, rhs) {
	_.isArray(lhs) || (lhs = lhs ? lhs.split('.') : []);
	_.isArray(rhs) || (rhs = rhs ? rhs.split('.') : []);
	//[] c [1, 2] -> 1
	//[1, 2] c [] -> -1
	//[] c [] -> 0
	if(!_.any(lhs)) {
		if(!_.any(rhs))
			return 0;
		return 1;
	}
	if(!_.any(rhs))
		return -1;
	if(lhs[0] == rhs[0])
		return compareVersions(lhs.slice(1), rhs.slice(1));
	return rhs[0] - lhs[0];
}
})