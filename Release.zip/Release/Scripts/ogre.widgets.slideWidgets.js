define(
['jquery', 'underscore', 'constants', 'slideRenderer', 'slideRenderingUtils', 'knockout', 'fullscreen', 'jqueryUI'],
function($, _, constants, newSlideRenderer, renderingUtils, ko, fullscreen) {
	'use strict'

	var rescaleSizeSliders = _.throttle(rescaleSizeSlidersNow, 150)
        ,thumbScale         = constants.THUMBNAIL_DEFAULT_HEIGHT / constants.SLIDE_VIEWBOX_HEIGHT
        ;

    /* A view of a slide. In this context a slide is an html document, NOT
     * a domain entity. Specifically, this component handles setting up and 
     * writing the document to an iframe and maintaining proper element sizing.
     */
	$.widget('ogre.slideView', {
        options: {
             scaleBy:         null
            ,propogateEvents: ['click']
        }
    	,_create: function() {
            this.element.addClass('slide slide-view');

    		this.$slideScaling = $('<div class="slide-scaling">').appendTo(this.element);
    		this.$slideIframe = $('<iframe>').appendTo(this.$slideScaling);
            this.$slideIframe.prop('src', this.options.thumbnail);

    		renderingUtils.configureSeamlessIframe(this.$slideIframe);

            this.element.on('svgsizesliderresize', _.bind(function(e, newSize)  {
                this._resize(newSize);
            }, this));          
            
            if (this.options.isRepeating)
                this.element.addClass('repeating-slide');

            if(this.options.scaleBy) {
                var scaleBy = this.options.scaleBy;
                renderingUtils.scale(this.$slideScaling, scaleBy);
                this._resize({width: scaleBy*constants.SLIDE_VIEWBOX_WIDTH, height: scaleBy*constants.SLIDE_VIEWBOX_HEIGHT});
            }

            if(this.options.html) 
                this.html(this.options.html);

            //Since a slideView is an iframe events inside it stops propogation at the iframe's boundary. 
            //set up events to propogate outside the iframe boundary
            this.forwardEventPropagation();

            rescaleSizeSliders();
    	}
        ,_resize: function(newSize) {
            newSize && this.element.width(newSize.width).height(newSize.height);            
        }
        ,html: function(html) {
            if(_.isUndefined(html)) {
                var  body = this.slideDocument().body
                    ,htmlContents = $(body).closest('html').html() || body.innerHTML;
                return ['<html>', htmlContents, '</html>'].join('\n')
            }
            this._html = html;

            this.redraw();
        }

        ,fullScreen: function() {
			fullscreen($('iframe', this.element)[0], true);
        }

		, toggleHelp: function (option) {
			$(this.slideDocument()).find('.help').toggle(option);
		}

        // $el.slideView('modify', function(slideDocument) { 
        //   $(slideDocument).find('.foo').text("Foo"); 
        // });
        //When modifying the underlying iframe (eg jQuery or d3) use this method rather than the document directly.
        //this will ensure the node can be redrawn properly if it ever gets removed from the document eg while sorting
        ,modify: function(fn) {
            var  doc = this.slideDocument()
                ,res = fn(doc);
            this._html = doc.body.innerHTML;
            return res;
        }

        //Certain DOM manipulations (like sorting) might cause the iframe document to lose its context
        //call this to redraw the element
        ,redraw: function() {
            //TODO - GM - this will not retain any changes to the DOM not made through the modify method, needs to be beefed up
            //Why use open/close: http://stackoverflow.com/questions/15036514/why-can-i-not-set-innerhtml-of-an-iframe-body-in-firefox/15037600#comment21173647_15037600
            var doc = this.slideDocument();
            doc.open();
            doc.write(this._html);
            doc.close();
            _.defer(function(){
                renderingUtils.configureContentBody(doc.body);
            });
        }

        //Direct access to the slide iframe's document. Note that if you are making modification to the slide's 
        //html you should instead use the modify method
        ,slideDocument: function() {
            return renderingUtils.documentOf(this.$slideIframe);
        }

		//Wire up events to propogate accross the iframe boundary
		// $el.slideView('forwardEventPropagation');
		//will re-broadcast events accross the boundary. The event will originate on the iframe and will
		//Click events are forwarded by default
		,forwardEventPropagation: function () {
			var widget = this
				,$body = $(widget.slideDocument().body)
				,events = _.chain(widget.options.propogateEvents).toArray().flatten().unique()

			var editableFields = ['input','select','textarea','option'];

			events.each(function (eventName) {
				$body.on(eventName, function (e) {
					// that code is needed due to #73211262
					try{
						widget._trigger(eventName, e);
						widget.$slideIframe.trigger(e);
						if (!_.contains(editableFields, e.target.nodeName.toLowerCase())) {
							if (eventName != 'mousemove')
								document.activeElement.blur();

							e.preventDefault();
							e.stopPropagation();
						}
					} catch (e) {console.log(e)}

				});
			});
		}

        //Call from a derived widget so that $().slideView still works
        ,_bindToSlideViewMethod: function(derivedWidget) {
            this.element.data('ogre-slideView', derivedWidget);
        }      

    });

	function overlayElement(element, overlyClass) {
		element.css({ position: 'relative' });
		return $('<div>')
			.addClass(overlyClass)
			.css({ position: 'absolute', top: 0, left: 0, bottom: 0, right: 0, 'z-index': 100 })
			.appendTo(element);
	}

    //A slideView that can also be dragged by the user
	$.widget('ogre.draggableSlideView', $.ogre.slideView, {
		options: {
			disableDraggable: null,
			overlayClass: 'slide-draggable-overlay'
		},
    	_create: function() {
    		this._super();
            this.element.data('ogre-slideView', this.element.data('ogre-draggableSlideView')); //this should have the same :selectors

    		this._initOverlay();

    		this.element.draggable({
    			handle: '.' + this.options.overlayClass
    		});
    	}
    	,_initOverlay: function () {
    		var $overlay = overlayElement(this.element, this.options.overlayClass);

    		if (ko.isSubscribable(this.options.disableDraggable))
    			this._subscribeDisableDraggable($overlay);

    		$overlay.toggle(!ko.unwrap(this.options.disableDraggable));
    	}
    	,_subscribeDisableDraggable: function ($overlay) {
    		var subscription = this.options.disableDraggable.subscribe(function (value) { $overlay.toggle(!value) });

    		ko.utils.domNodeDisposal.addDisposeCallback(this.element[0], function () { subscription.dispose() });
    	}
    });
    //The persistState widget knows how to handle simple draggable widgets. If this widget gets
    //more complex will have to add a persistState extension to handle that.


    //Sorting slides will not work out of the box with the sortableWidget since clicks are not
    //propagated outside an iframe (and several other reasons). This will set up the proper sort 
    //targets. Additionally, sorting seems to occasionally lose iframe context so redraw
    //iframes after sorting.
    //
	//IMPORTANT: THIS ASSUMES THAT YOU'RE USING A VERSION OF draggableSlideView
    $.widget('ogre.sortableSlides', {
        _create: function() {
            this.element.sortable({
                 handle: '.slide-click-target'
                ,stop: _.bind(function(){
                    this.element.find('.slide-view').slideView('redraw');
                }, this)
            });
        }
    })

    // Use the renderer to draw a slide from a slide definition and some data into an instance
    // of a slideView (or a variation of slideView).
    // Requires slideDefinition, data, parameters options
    $.widget('ogre.drawSlide', {
        options: {
             widget:          $.fn['slideView']
            ,scaleBy:         thumbScale
        },
        _create: function() {
            var $el = this.element;

            this.options.widget.call( $el, _.extend({}, this.options, { html: ""}) )
            this.renderer = newSlideRenderer({
                 selector:      function() { return $el.find('iframe') }
                ,slide:         this.options.slideDefinition
				,slideSet:         this.options.slideSetDefinition
                ,pagenum:       this.options.pagenum
				,goToSlideWithIdCallback: this.options.goToSlideWithIdCallback
            });

            this.redraw();
        },
        redraw: function(force) {
            var dataContainer = this.options.slideData || this.options;
            this.renderer.setState( _.pick(dataContainer, 'data', 'parameters', 'loggingKey') ); 
            this.element.removeClass('drawing-complete');
            var redrawing = this.renderer[force === true ? 'redrawNow' : 'redraw']();
            this._trigger('redrawing', null, redrawing, this.element);
            return redrawing.then(function () {
                this.element.addClass('drawing-complete');
                if (_.any(_.keys(this.element.data())))  //TODO - GM - On IE sometimes the widget is not initialized here, why?
                    this.options.widget.call(this.element, 'forwardEventPropagation');
            }.bind(this))
        }
    });

    function rescaleSizeSlidersNow() {
        $(':ogre-slideSizeSlider').slideSizeSlider('rescale');
    }
});
