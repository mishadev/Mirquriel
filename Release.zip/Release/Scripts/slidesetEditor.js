define(
['underscore', 'knockout', 'apiUrls', 'knockout.mapping'
 , 'usedParameterConfigurationModel', 'parameters/parametersContext', 'breadcrumbs/breadcrumbContext', 'asyncComputed'
 , 'knockout-sortable', 'ogre.widgets.slideWidgets', 'ogre.widgets.collapsible'],
function (_, ko, api, mapping, usedParameterConfigurationModel, parametersContext, breadcrumbContext, asyncComputed) {
	return function slidesetConfiguration(model) {

		var slidesetId = model.Slideset.Id
			, _vm = mapping.fromJS(model, modelMappingConfig())
			, saveSlidesetDescriptors = debounceTyping(saveSlidesetDescriptorsNow)
		;
		_vm.filterOn = ko.observable("");
		_vm.filteredAvailableSlides = ko.computed(filteredAvailableSlides);

		_vm.deleteSlideSetConfirmation = ko.observable(null);
		_vm.deleteSlideSet = deleteSlideSet;

		_vm.createSlide = debounceTyping(createSlideNow);

		_vm.useSlide = useSlide;
		_vm.stopUsingSlideConfirmation = ko.observable(null);
		_vm.stopUsingSlide = stopUsingSlide;
		_vm.cloneSlideConfirmation = ko.observable(null);
		_vm.cloneSlide = cloneSlide;
		saveOrderOnSort('modifyUsedSlideOrder', _vm.CurrentSlides);

		_vm.useParameter = useParameter;
		_vm.stopUsingParameter = stopUsingParameter;
		saveOrderOnSort('modifyUsedParameterOrder', _vm.CurrentParameters);

		_vm.hierarchyParametersContext = asyncComputed(getHierarchyParameterContext);
		_vm.hierarchyParameters = ko.observableArray([]);
		createParamterContext();

		var descriptorProps = ['Name', 'DatamartConnectionStringName', 'Tags', 'DefaultSlideRange', 'Description', 'MostSpecificHierarchyParameterId']
		_.each(descriptorProps, function (prop, idx) { _vm.Slideset[prop].subscribe(saveSlidesetDescriptors) })

		return _vm;

		////////////////////////////////////////////////////

		function filteredAvailableSlides() {
			if (!_vm.filterOn().trim())
				return _vm.AvailableSlides();
			return _.filter(_vm.AvailableSlides, function (s) {
				return ~(s.Name() || "").toLowerCase().indexOf(_vm.filterOn().toLowerCase());
			})
		}

		function deleteSlideSet() {
			_vm.deleteSlideSetConfirmation({
				yes: function () {
					api.deleteSlideSet(slidesetId).done(function () {
						window.location.href = "/Editor";
					}); // reload the page to ensure we're fully sync'ed after the delete               
				}
			})
		}


		function createSlideNow() {
			api.createSlide().then(function (s) { return _vm.AvailableSlides.push(createAvailableSlide(s)) });
		}
		function saveSlidesetDescriptorsNow() {
			var ss = _.pick(_vm.Slideset, descriptorProps, 'Id')
			api.saveSlidesetDescriptors(mapping.toJS(ss));
		}
		function markParameterDefaultSelection(usedParameter) {
			if (!_vm.parametersContext())
				return null;
			var p = _.findBy(_vm.parametersContext().parameters, usedParameter.Id(), 'Id');
			if(!p)
				return null;
			return function markParameterDefaultSelection() {
				api.markParameterDefaultSelection({
					slidesetId: slidesetId
					, parameterId: usedParameter.Id()
					// if user selection is undefined (no selection), send null to the server
					// WebAPI coerces undefined to an empty string, which is not the right representation of "no default"
					, value: (p.userSelection() !== undefined) ? p.userSelection() : null
				}).then(function (data) { usedParameter.DefaultSelection(data.DefaultSelection); });
				updateDependentDefaultSelections(p);
			}
		}

		function updateDependentDefaultSelections(parameter) {
			if (parameter.userSelection())
				return;

			var dependentParameters = _vm.parametersContext().getDependentParameters(parameter);
			var currentParameters = _vm.CurrentParameters();

			_.each(dependentParameters, function (param) {
				var currentParameter = _.find(currentParameters, function (usedParameter) {
					return usedParameter.Id() === param.Id;
				});

				if (currentParameter)
					currentParameter.markParameterDefaultSelection()();
			});
		}

		var overrideDisplayNameSubscriptions = [];

		function createParamterContext() {
			//GM - Ideally we would just use a computed, but that doesn't work since creating a parametersContext invokes
			//observables like each paramter's options and userSelection. Doing so triggers the computed to recalculate whenever
			//you open a dropdown. So we want something similar but that depends only on the observables we want.
			_vm.parametersContext = ko.observable(null);
			_vm.hierarchyParametersContext.subscribe(tryCreate);
			_vm.CurrentParameters.subscribe(tryCreate);

			function subscribeToOverriddenDisplayNameChange() {
				_.each(overrideDisplayNameSubscriptions, function (item) {
					item.dispose();
				});

				overrideDisplayNameSubscriptions = [];
				_.each(_vm.CurrentParameters(), function (item) {
					overrideDisplayNameSubscriptions.push(item.OverriddenDisplayName.subscribe(tryCreate));
				});
 			}

			function tryCreate() {
				if (!_vm.hierarchyParametersContext())
					return;

				subscribeToOverriddenDisplayNameChange();
				_vm.parametersContext(parametersContext(_vm.CurrentParameters, _vm.hierarchyParametersContext().params, { getParameterOptions: getSelectParameterOptions }));
			}
		}
		function getHierarchyParameterContext() {
			return api.getDatamartHierarchyParameterValues(_vm.Slideset.DatamartConnectionStringName())
					.then(function (hp) {
						_vm.hierarchyParameters(hp);

						return breadcrumbContext({
							DatamartName: _vm.Slideset.DatamartConnectionStringName(),
							HierarchyParameters: hp
						})
					});
		}

		function getSelectParameterOptions(parameter, parameterValues) {
			return api.getSlidesetParameterValues({ slidesetId: slidesetId, parameterId: parameter.Id, parameterValues: parameterValues });
		}

		function useSlide(s) {
			api.useSlide(slidesetId, s.Id()).then(function (x) {
				_vm.AvailableSlides.remove(function (y) { return y.Id() === x.Id });
				_vm.CurrentSlides.push(createUsedSlide(x))
			})
		}
		function stopUsingSlide(s) {
			_vm.stopUsingSlideConfirmation({
				yes: function () {
					api.stopUsingSlide(slidesetId, s.Id()).then(function (newModel) {
						_vm.CurrentSlides.remove(function (x) { return x.Id() === s.Id() });
						_vm.AvailableSlides.push(createAvailableSlide(newModel));
					});
				}
				, slide: s
			});
		}
		function useParameter(p) {
			api.useParameter(slidesetId, p.Id()).then(function (x) {
				_vm.AvailableParameters.remove(function (y) { return y.Id() === x.Id });
				_vm.CurrentParameters.push(createUsedParameter(x))
			})
		}
		function stopUsingParameter(p) {
			api.stopUsingParameter(slidesetId, p.Id()).then(function (newModel) {
				_vm.CurrentParameters.remove(function (x) { return x.Id() === p.Id() });
				_vm.AvailableParameters.push(mapping.fromJS(newModel));
			})
		}

		function saveOrderOnSort(apiMethod, koSortableModels) {
			koSortableModels.subscribe(onKnockoutSortableReorder(function () {
				api[apiMethod](slidesetId, _.pluck(koSortableModels, 'Id'));
			}), null, 'arrayChange');
		}

		function cloneSlide(slide) {
			_vm.cloneSlideConfirmation({
				yes: function () {
					api.cloneSlide({ slideSetId: slidesetId, slideId: slide.Id() }).then(function (model) {
						_vm.CurrentSlides.push(createUsedSlide(model));
					});
				}
			});
		}

		function modelMappingConfig() {
			return {
				CurrentParameters: {
					create: createUsedParameter
				},
				AvailableSlides: {
					create: createAvailableSlide
				},
				CurrentSlides: {
					create: createUsedSlide
				},
				MostSpecificHierarchyParameterId: {
					update: function (options) {
						return _.isNull(options.data) ? undefined : options.data;
					}
				}
			}
		}

		function createUsedSlide(x) {
			var s = mapping.fromJS(x.data || x);
			s.Name.subscribe(debounceTyping(function () {
				api.updateSlideSlidesetContext({
					slideId: s.Id(),
					Name: s.Name(),
					slidesetId: slidesetId
				}).then(function (data) {
					updateObject(s, data);
				});
			}));
			return s;
	}

	function updateObject(target, newvalues) {
		_.each(_.intersection(_.keys(target), _.keys(newvalues)), function (property) {
			ko.isObservable(target[property]) ?
				target[property](newvalues[property]):
				target[property] = newvalues[property];
			});
		}

		function createUsedParameter(x) {
			var p = usedParameterConfigurationModel(x.data || x, slidesetId);
			p.markParameterDefaultSelection = ko.computed(_.partial(markParameterDefaultSelection, p));
			return p;
		}
		function createAvailableSlide(x) {
			var s = mapping.fromJS(x.data || x);

			s.editAvailableSlide = ko.computed(function editAvailableSlide() {
				if (!_.any(s.UsedBySlidesetIds()))
					return null
				return '/Slide/' + s.Id() + '/Configuration/?slidesetContext=' + s.UsedBySlidesetIds()[0];
			});

			s.deleteSlide = ko.computed(function deleteSlide() {
				if (s.UsedBySlidesetIds().length)
					return null
				return function deleteSlideNow() {
					api.deleteSlide(s.Id()).then(function () {
						_vm.AvailableSlides.remove(s);
					});
				}
			});

			return s;
		}
		function onKnockoutSortableReorder(fn) {
			//knockout.sortable doesn't really move objects, it makes 
			//2 changes with one item each. First a delete and then an add
			//detect these two events happening rapidly and in sequence
			var deleteCalled = false;
			return function onKnockoutSortableReorder(changes) {
				if (changes.length != 1)
					return;
				if (changes[0].status == 'deleted')
					deleteCalled = true;

				if (changes[0].status == 'added' && deleteCalled) {
					deleteCalled = false;
					return fn();
				}
			}
		}
		function debounceTyping(fn) { return _.debounce(fn, 500) }

	}
});