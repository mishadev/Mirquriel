define(
['knockout.mapping', 'localStorageWrapper'],
function (mapping, storage) {
'use strict';

	// AG NOTE: this could be removed, at the cost of users losing their storage data (would be reloaded by the application)
    // the optional "skipPrefix" argument (false by default) allows for bypassing of the prefix where desired
var PREFIX = 'ogre:/'+window.ow.ApplicationInstanceType;

return {
    storeOnClient: function storeOnClient(key, val, skipPrefix) {
        var value = _.isObject(val) ? mapping.toJSON(val) : val;

        try {
            // Makes saving state very slow, use only for debugging (not on production)
            /*
            var spaceNeeded = value.length;
            var spaceUsed = unescape(encodeURIComponent(JSON.stringify(storage))).length; // http://stackoverflow.com/questions/3027142/calculating-usage-of-localstorage-space
            var likelySpaceFree = 1024 * 1024 * 5 - spaceUsed;
            if (likelySpaceFree < 1024 * 1024 * 2) { // only write console message if space is running low
                console.log("storage storeOnClient " + key, "Space used: " + spaceUsed, "Likely space free (if 5MB max): " + likelySpaceFree, "Space needed: " + spaceNeeded);
            }
            */
            console.log("storage storeOnClient " + key, "Space needed for this object (object.length): " + value.length);
            storage.setItem(composeKey(key, skipPrefix), value);
        } catch (e) {
            console.error("Storage error:", e);
        }
    },
    removeOnClient: function removeOnClient(key, skipPrefix) {
    	storage.removeItem(composeKey(key, skipPrefix));
    },
    getOnClient: function getOnClient(key, skipPrefix) {
    	var x = storage.getItem(composeKey(key, skipPrefix));
        var parsed;
        try {
            parsed = JSON.parse(x);
        } catch(e) {}
        return parsed || x;
    }
}
   
function composeKey(key, skipPrefix) {
	return skipPrefix ? key : PREFIX + key;
}

} );