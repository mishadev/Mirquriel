define(['knockout', 'jquery'], function(ko, $){
//A computed that will unwrap returned deferred objects.
//Intially form here: https://github.com/knockout/knockout/wiki/asynchronous-dependent-observables
return function asyncComputed(evaluator, owner) {
    var res = ko.observable(), currentDeferred;
    res.state = ko.observable('resolved'); // Track whether we're waiting for a res
    res.error = ko.observable();

    ko.computed(function() {
        // Abort any in-flight evaluation to ensure we only notify with the latest value
        if (currentDeferred) currentDeferred.reject();

        var def = evaluator.call(owner);
        if(!def || (typeof def.then != 'function'))
            return res(def);
        res(null);
        res.error(null);
        res.state(def.state());
        currentDeferred = $.Deferred();
        currentDeferred.then(updateResult(res), updateResult(res.error));
        def.then(currentDeferred.resolve, currentDeferred.reject);
    
        function updateResult(fn) { return function updateResult() {
            res.state(def.state());
            fn.apply(owner, arguments);
        } }
    });

    return res;
}
})