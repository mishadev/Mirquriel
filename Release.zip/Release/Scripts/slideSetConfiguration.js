﻿define(
['jquery', 'knockout', 'underscore', 'parameters/parametersContext', 'apiUrls', 'rangeNotation', 'parameters/parametersContextBinder'],
function ($, ko, _, parametersContext, api, newRangeNotation, parametersContextBinder) {
	'use strict'

	// Represents the configuration of a slideset instance *before* one is generated. 
	// NOT the editor-area concept of configuring a slideset definition
	// Its parameters can be configured as well as the range of slides that the user is interested in opening
	return function slideSetConfiguration(slideSetDefinition, additionalParameters) {
		var allSelectionType = 'All',
			rangeSelectionType = 'Range';

		var urlBinding = ko.observable(false);

		var paramContext = parametersContext(slideSetDefinition.Params, additionalParameters, { getParameterOptions: getSlideSetParamOptions });

		var slideRange = newRangeNotation(slideSetDefinition.Slides.length, slideSetDefinition.DefaultSlideRange)
			, slideRangeSelection = createSlideRangeSelection()
		;
		var _viewModel = {
			slideSetDefinition: slideSetDefinition
			, parametersContext: paramContext
			, slideRangeSelection: ko.observable(null)
			, slideRangeNotation: slideRange.notation
			, slideRangeType: ko.observable()
			, selectSlideRangeManually: function () { _viewModel.slideRangeSelection(slideRangeSelection); return true; }
			, lastClickedSlideItem: ko.observable()
			, urlBinding: urlBinding
		};

		setRangeTypeToInitialState();
		parametersContextBinder(paramContext, urlBinding);

		_viewModel.range =  ko.computed(function () {
			return _viewModel.slideRangeType() === allSelectionType ? slideRange.allSelectedRange : slideRange.range();
		});

		_viewModel.slideRangeType.subscribe(function (val) {
			_viewModel.slideRangeSelection(val === allSelectionType ? null : slideRangeSelection);
		});

		_viewModel.hasSelectedSlides = ko.computed(function () {
			return _.any(_viewModel.range(), function (r) { return r });
		});

		_viewModel.enableOpenSlideSetButton = ko.computed(function () {
			return paramContext.isFulfilled() && _viewModel.hasSelectedSlides();
		});

		_viewModel.deserializeParameterWithName = function (name, value) {
			paramContext.deserializeParameterWithName(name, value);
		};

		return _viewModel;

		/////////////////////

		function setRangeTypeToInitialState() {
			var type = _.isEqual(slideRange.allSelectedRange, slideRange.range()) ?
				allSelectionType :
				rangeSelectionType;
			_viewModel.slideRangeType(type);
		}

		function createSlideRangeSelection() {
			return {
				slides: _.map(slideSetDefinition.Slides, function createSlideSelectionVm(slideDefinition, idx) {
					return {
						slideDefinition: slideDefinition
				 		, isSelected: ko.computed({
				 			read: function () {
				 				return slideRange.range()[idx];
				 			}
				 			, write: function (val) {
				 				slideRange.range.splice(idx, 1, val);
				 			}
				 		})
						//This code should be reverted to 06ab6d3e865632d6c9a9f3f13331a3fcc3e410cc commit once FF issue is fixed
						//firefox does not detect shift+click on a checkbox https://bugzilla.mozilla.org/show_bug.cgi?id=559506
						, slideRangeSelectionUpdated: function (item, event) {
							item.isSelected(!slideRange.range()[idx]);//reverting slide selection

							//if shift is not clicked setting last clicked item and getting out
							if (!event.shiftKey) {
								_viewModel.lastClickedSlideItem(idx);
								return;
							}
							//otherwise if last clicked item was set updating selection and setting last clicked to null
							if (_viewModel.lastClickedSlideItem() != null) {
								updateSelections(idx, _viewModel.lastClickedSlideItem(), slideRange.range()[idx]);
								_viewModel.lastClickedSlideItem(null);
							}
						}
					}
				})
				//,selectedSlideNumbers: slideRange.range
				, includeSelectedSlides: function () { _viewModel.slideRangeSelection(null); }
				, setAllSlidesSelectionTo: setAllSlidesSelectionTo
			};
		}

		function updateSelections(currentIndex, previousIndex, state) {
			var startIndex = (currentIndex < previousIndex) ? currentIndex : previousIndex;
			var endIndex = (previousIndex > currentIndex) ? previousIndex : currentIndex;

			for (var i = startIndex; i <= endIndex; i++)
				slideRange.range.splice(i, 1, state);
		}

		function getSlideSetParamOptions(parameter, allSelections) {
			return api.getSlideSetParamOptions({
				slideSetId: slideSetDefinition.SlideSetId
				, parameterId: parameter.Id
				, allSelections: allSelections
			});
		}

		function setAllSlidesSelectionTo(all) {
			return function () {
				if (all) slideRange.selectAll();
				else slideRange.deselectAll();
			}
		}
	}
});
