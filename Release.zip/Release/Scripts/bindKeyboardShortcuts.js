﻿define(
['jquery', 'underscore'],
function (
    $, _) {
    'use strict'

    // Keyboard shortcut binding module. Takes a list of objects with keycodes and callback properties
    // and assigns them to the element provided.  (Element is optional, defaults to 'document')
    // Use like this: slideSetViewerKeyboardShortcuts([{keycodes: [1,2,3], callback: function() { alert('keydown!'); } }]);

    return function (keycodesAndCallbacks, element) {
        element = element || document;
		//It's safer to put event listener on documentElement than on document it self because of cross context event propagation.
		element = _.isElement(element) ? element : element.documentElement;

        $(element).keydown(function (e) {
            _.each(keycodesAndCallbacks, function (shortcut) {
                if (_.contains(shortcut.keycodes, e.keyCode)) shortcut.callback();
            });
        });
    }
});