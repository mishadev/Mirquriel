define(
['jquery', 'knockout', 'underscore'],
function($, ko, _) {
	//Facades for interacting with the server. 
	// Methods: 
	// put, post, delete - facades over $.ajax with the verb and default options, handling of known
	//                     return codes. Return jquery Deferred. Take in the same options as $.ajax
	// save - put or post depending on preExisting flag: server.save(param.Id, {...})
    // getLocationHeader - parse out a location header from an xhr response

    var defaultJsonOptions = {
         dataType: "json"
        ,contentType: "application/json"
        ,processData: false
    };
    var defaultStatusCodeHandlers = { 
    	statusCode: {
			 400: saveBadRequest
			,404: saveNotFound
            ,401: unauthorized
			,200: $.noop	        	
        }
    };
    function massageData(data) {
		var data = _.isString(data) ? data : ko.toJSON(data);
		return data && {data: data}
    }
    function ajaxWith(op) {
    	var others = _.tail(arguments);
    	var args = _.union(												//cascade with overrides
        		[{}, defaultJsonOptions, defaultStatusCodeHandlers],	//defaults
        		_.tail(arguments),										//any other objects passed in
        		[op, massageData(op.data)]								//op and data
    		);
        return $.ajax($.extend.apply($, args));
    }
	return {
		put: function(op) {
            return ajaxWith(op, {type: "PUT"});
		}
		,post: function(op) {
            return ajaxWith(op, { type: "POST"});
		}
		,del: function(op) {
			return ajaxWith(op, {type: "DELETE"});
		}
		,save: function(preExisting, op) {
            return ajaxWith(op, { type: (ko.unwrap(preExisting) ? "PUT" : "POST") });
		}
		,jsonAjax: ajaxWith
        ,getLocationHeader: function(a, b, xhr){ return xhr.getResponseHeader('Location') }
	};

	/////////////////////////////////////////

	function unauthorized(xhr) {
	    console.error(xhr.responseText);
	    showError("You may be logged out of the site. Please open the site homepage in a new tab and log back in to continue.");
	}
    function saveBadRequest(xhr) {
    	console.error(xhr.responseText);
    	try {
    		var data = JSON.parse(xhr.responseText);
    		showError(data.Message);
    	} catch (e) {
    		showError("Invalid model");
    	}
    }
    function saveNotFound(xhr) {
    	showError("Possible concurrency exception. Please reload page. Details: " + xhr.responseText);
    }

    function showError(message) {
    	$("<div>" + message + "</div>").dialog({
    		autoOpen: true,
    		modal: true,
    		resizable: false,
    		width: 400,
    		title: 'Error',
    		buttons: {
    			"Ok": function () {
    				$(this).dialog("close");
    			}
    		}
    	});
    }

});