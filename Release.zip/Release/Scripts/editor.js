﻿define(
['jquery', 'knockout', 'apiUrls', 'serverUtils', 'jquery.form', 'knockout.slideView'],
function ($, ko, api, serverUtils) {
	'use strict';

	return function editor(model) {
		var _editor = {
			slideSets:				ko.observableArray([])
			,datamarts:				model.AvailableConnectionStringCodes
			,alwaysLoadThumbnail:	ko.observable(false)
			,loading:				ko.observable(false)			
		};

		_editor.createSlideSet = function () {
			api.createSlideset()
				.then(serverUtils.getLocationHeader)
				.then(navigateTo);
		};

		_editor.slideConfigurationUrl = function (slidesetId, slideId) {
			return api.slideConfigurationUrlTemplate(slidesetId, slideId);
		};

		_editor.slidesetConfigurationUrl = function (slidesetId) {
			return api.slidesetConfigurationUrlTemplate(slidesetId);
		};

		_editor.filterByDatamart = ko.observable(null);
		_editor.filteredSlideSets = ko.computed(function () {
			var filterText = _editor.filterByDatamart();
			return _.isUndefined(filterText)
				? _editor.slideSets()
				: _.where(_editor.slideSets(), { DatamartConnectionStringName: filterText });
		});
		

		loadSlideSets();

		return _editor;

		function navigateTo(uri) {
			window.location.href = uri;
		}

		function loadSlideSets() {
			_editor.loading(true);
			api.getSlideSetsForEditor().done(function (data) {
				_editor.slideSets(data);
				_editor.loading(false);
			});
		}
	}
});