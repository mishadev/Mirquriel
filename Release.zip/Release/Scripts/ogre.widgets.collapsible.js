define(
['jquery', 'underscore', 'knockout', 'jqueryUI', 'ow.widgets.persistState'],
function($, _, ko) {
"use strict"

/*
 Appends element contents with a collapse handle anchor. Clicking it will toggle the element's contents to slide up/down.
 Can be triggered programmatically via toggleCollapsed (uses easing) and toggleCollapsedImmediate (toggles immediately)
 current state can be queried from the isCollapsed property.
 Collapse handle will have an .ogre-collapsible-toggle class
 Collpasable contents will have a .ogre-collapsible-wrapper class

 There are several variations of this widget in this file. Look through it for the one you want.
*/
$.widget('ogre.collapsible', {
    options:{
         handleContainer:       null
        ,initiallyCollapsed:    false
    }
    ,_create: function() {
        this.element.addClass('ogre-collapsible')
        this.$body = this._getCollapsibleBodyWrapper();

        this.isCollapsed = false;
        this.$collapser = $('<a href="javascript:void(0)"></a>');
        this._appendHandle( $('<span class="ogre-collapsible-toggle">').append(this.$collapser) );
        this._addEventListener(this.$collapser);

        if(this.options.initiallyCollapsed)
            this.toggleCollapsedImmediate(false);
    }
	,_addEventListener: function (el) {
		$(el)
			.click(this.toggleCollapsed.bind(this))
			.addClass("ogre-collapsible-collapser");
	}
    ,_getCollapsibleBodyWrapper: function() {
        this.element.wrapInner('<div class="ogre-collpsible-wrapper">');
        return this.element.children('.ogre-collpsible-wrapper');
    }
    ,_appendHandle: function($handle) {
        $handle.prependTo(this.handleContainer || this.element);
    }
    ,toggleCollapsed: function(show, fnShow, fnHide) {
        //All parameters are optional

        show = _.isBoolean(show) ? show : this.isCollapsed;     //default is to inverse current state
        if(show == !this.isCollapsed)                           //already in the correct state
            return;

        fnShow = fnShow || _.bind(this.defaultShow, this);
        if(show)
            return fnShow(this);
        fnHide = fnHide || _.bind(this.defaultHide, this);
        fnHide(this);
    }

    //collapse or show without animation
    ,toggleCollapsedImmediate: function(show) {
        this.toggleCollapsed(show, _.bind(function show(){
            this.$body.show();
            this.slideDone(false)();
        }, this), _.bind(function hide() {
            this.$body.hide();
            this.slideDone(true)();            
        }, this) );
    }

    ,slideDone: function(isCollapsed) { return function() {
        this.element.toggleClass('ogre-collapsible-collapsed', isCollapsed);
        this.isCollapsed = isCollapsed;
    }.bind(this) }
    ,defaultShow: function() {
        this.$body.slideDown('normal', this.slideDone(false));
    }
    ,defaultHide: function() {
        this.$body.slideUp('normal', this.slideDone(true));        
    }
});
$.widget('ogre.collapsibleCollapsed', $.ogre.collapsible, {
    options: {
        initiallyCollapsed: true
    }
});

$.widget('ogre.collapsibleToChildHeader', $.ogre.collapsible, {
     options: {
        collapseToSelector: '>header'
    }
    ,_create: function(){
        this.$header = $(this.options.collapseToSelector, this.element);
        $.ogre.collapsible.prototype._create.apply(this, arguments);
    }
    ,_appendHandle: function($handle) {
		this._addEventListener(this.$header.first().prepend($handle));
    }
    ,_getCollapsibleBodyWrapper: function() {
        this.$header.nextAll().wrapAll('<div class="ogre-collpsible-wrapper">');
        return this.$header.next('.ogre-collpsible-wrapper');        
    }
});
$.widget('ogre.collapsibleToH3', $.ogre.collapsibleToChildHeader, {
    options: {
        collapseToSelector: '>h3'
    }
});
$.widget('ogre.collapsibleToH3Collapsed', $.ogre.collapsibleToH3, {
    options: {
        initiallyCollapsed: true
    }
});

$.ow.persistState.elementPersistence[':ogre-collapsible,:ogre-collapsibleCollapsed,:ogre-collapsibleToChildHeader,:ogre-collapsibleToH3,:ogre-collapsibleToH3Collapsed'] = {
    saveState: function($el) {
        var widget = _.find($el.data(), function(w) { return !_.isUndefined(w.isCollapsed) });
        return { collapsed: widget.isCollapsed }
    },
    restoreState: function($el, state) {
        if(!state) return;
        var widget = _.find($el.data(), function(w) { return _.isFunction(w.toggleCollapsedImmediate) });
        widget.toggleCollapsedImmediate(!state.collapsed);
    }
};

//setup knockout collapsible binding can be used as follows:
// collapsible: false //no collapsible
// collapsible: true  //collapsible widget
// collapsible: '>h4' //collapse to child h4 element
// collapsible: {collapseToSelector: null, initiallyCollapsed: true} //use collapsible widget and be initially collapsed
// collapsible: {collapseToSelector: '>h5', initiallyCollapsed: false} //use collapsibleToChildHeader widget to collapse to h5 
ko.bindingHandlers.collapsible = {
    init: function(el, valueAccessor) {
        var  val = ko.unwrap(valueAccessor())
            ,op = {collapseToSelector: null, initiallyCollapsed: false, immediate: true}
            ;
        if(!val)
            return;
        if(_.isObject(val))
            $.extend(op, val);
        else if(_.isString(val))
            op.collapseToSelector = val;
        var run = op.immediate ? _.run : _.defer;
        run(function() { $(el)[ op.collapseToSelector ? 'collapsibleToChildHeader' : 'collapsible' ](op) });

    }
}
});