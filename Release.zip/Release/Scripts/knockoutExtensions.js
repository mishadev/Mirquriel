define(
['knockout', 'jquery', 'underscore', 'moment', 'ow.widgets.persistState', 'knockout-sortable', 'knockout.binding.multiselect', 'knockout.binding.subscribe', 'knockout.binding.chosenBreadcrumb', 'knockout.binding.select2'],
function(ko, $, _, moment) {
	var unwrap = ko.unwrap;
	
	var koBindingHandlersEnableOrigin = ko.bindingHandlers.enable;
	ko.bindingHandlers.enable = {
		update: function (element, valueAccessor) {
			koBindingHandlersEnableOrigin.update(element, valueAccessor);
			if (!ko.unwrap(valueAccessor()) && document.activeElement === element)
				element.blur(); //need to proper events raising in FF (keypress events will not be despatch while target is disabled element)
		}
	};

	// An extender that will invoke a sort method on any values passed in. 
	// Usage:
	//    ko.observableArray([]).extend({sort: 'asc'}) //or 'desc' (default is 'asc')
	ko.extenders.sort = function(target, direction) {
		var sortFn = direction == 'desc' ? function(a, b) { return a < b ? 1 : -1 } 
										 : function(a, b) { return a > b ? 1 : -1 };
	    target.subscribe(function(newValue) {
	        newValue && newValue.sort(sortFn);
	    });
	    return target;
	};

	ko.bindingHandlers.brokenImage = {
		init: function(element, valueAccessor) {
			var $el = $(element).on('error', function() {
				$el.addClass('broken-image');
				$el.prop('src', ko.unwrap(valueAccessor()));
			});
		}
	}
	//Identical to the visible binding except the element will slide up/down
	ko.bindingHandlers.visibleBySliding = {
		update: function(element, valueAccessor) {
			var  shouldBeVisible = unwrap(valueAccessor())
				,animation = shouldBeVisible ? 'slideDown' : 'slideUp'
				;
			$(element)[animation]();
		}
	};

    // Extends the visible binding by cross-fading between elements. Will implicitly link all elements on the same page that use visibleFader into one cross-fade group.
    // Based on http://stackoverflow.com/questions/11434265/knockoutjs-fade-in-after-fading-out-something-else
	ko.bindingHandlers.visibleFader = {
	    update: function (element, valueAccessor) {
	    	if (!ko.unwrap(valueAccessor()))
	    		return;

	    	var $element = $(element),
				reveal = function () { $element.css('opacity', 1) },
				fadeSpeed = 500;

	        if (!this.previousElement) { // initial fade
	            $element.fadeIn(fadeSpeed, reveal);
	        } else {
	            $(this.previousElement).fadeOut(fadeSpeed, function () {
	                $element.fadeIn(fadeSpeed, reveal);
	            });
	        }
	        this.previousElement = element;
	    }
	};

	//A super-duper naive implementation of pretty printing JS
	//info on this technique: http://freshbrewedcode.com/jimcowart/2013/01/29/what-you-might-not-know-about-json-stringify/
	ko.bindingHandlers.prettyPrintJs = {
		update: function(el, val) {
			$(el).html(JSON.stringify(unwrap(val()), undefined, 2));
		}
	}
	
	//title attribute for the element
	ko.bindingHandlers.title = {
		update: function(el, val) {
			$(el).attr('title', val());
		}
	}

	// Truncate a multi-line element, replacing the last word that wouldn't fit with '...'
	// Parent element must have fixed height for this to work.
	ko.bindingHandlers.truncate = {
		update: function (element,valueAccessor,allBindingsAccessor,context) {
			var value = valueAccessor();
			var $element = $(element);
			var parentHeight = $element.parent().height();
			$element.text(value);
			while ($element.outerHeight() > parentHeight) {
				$element.text(function (index, text) {
					return text.replace(/\W*\s(\S)*$/, '...');
				});
			}
		}
	};

	//Set the value to the element's html5 data collection. Useful if you need to recover
	// a value from an element after binding has completed.
	// as this is not native to knockout, always consider using the native ko.dataFor() function first http://knockoutjs.com/documentation/unobtrusive-event-handling.html
	//Usage: data-bind="setData: $data"
	ko.bindingHandlers.setData = {
		update: function(el, valueAccessor) {
			$(el).data(unwrap(valueAccessor()));
		}
	};

	//Initialize a jQuery Ui Widget on this element.
	//<button id="click-here" data-bind="widget: {name: 'button' options: 'label:\'Click Here\', disabled: true'}, click: doSomething">Click Here</button>
	//will have the same effect as
	//<button id="click-here" data-bind="click: doSOmething">Click Here</button>
	//<script>$(function(){ $('#click-here').button(label: 'Click Here'), disabled: true })</script>
	//In the more common case when options are not needed you may simply write
	//<button id="click-here" data-bind="widget: 'button', click: doSomething">Click Here</button>
	ko.bindingHandlers.widget = {
		init: function(el, valueAccessor){
			var  val 		= valueAccessor()
				,options 	= ( _.isObject(val.options) ? val.options : _.isString(val.options) ? evaluateJsonishString(val.options) : null )
				,widget 	= val.name || val
				;
			if(!_.isFunction($.fn[widget]))
				return console.error("No such widget found:", widget);
			$(el)[widget](options);
		}
	}

	
	//Initialize a sizing slider widget on this element configured for
	//sizing thumbnails. Provide an optional jquery selector parameter
	//that will be the parent of the .slide-scaling elements to scale
	//eg "thumbSliderFor: '#slide-set-viewer'" will apply sizing to all '#slide-set-viewer .slide-scaling'
	//if no target is provided the default value for the slideSizeSlider widget will be used
	//
	//It is also possible for the binding value to be a configuration object to be passed down to the sizing widget 
	//eg thumbSliderFor: {target: '#SlideSetsViewer', value: 0.5} //will set the initial scaling to 1/2 scale
	ko.bindingHandlers.thumbSliderFor = {
		init: function (el, valueAccessor) {
		 	var  op = optionsForThumbSlider(valueAccessor)
		 		;
		 	_.defaults(op, ko.bindingHandlers.thumbSliderFor.sizeSliderDefaults);
			$(el).slideSizeSlider( ko.toJS(op) );

			if (ko.isObservable(op.value)) {
				$(el).on('slidesizesliderchange', _.leftShiftArgs(op.value));
				op.value.subscribe(function (val) { $(el).slideSizeSlider('scale', val); });
			}
		}
		,sizeSliderDefaults: {
	         min:           0.1
	        ,max:           1
	        ,step:          0.1
	        ,value: 		0.2
	    }
	}
	function optionsForThumbSlider(valueAccessor) {
		var op = valueAccessor();
		if( _.isString(op) ) op = op && { target: op };	//if its a non-empty string that's the selector
		if (op && op.target) op.target += ' .slide-scaling';
		return op;
	}

	//Simply logs the current context to the console. Useful for debugging
	ko.bindingHandlers._log = {
		update: function(element, valueAccessor, allBindingsAccessor, viewModel, bindingContext) {
			_log("Binding update", {
				 unwrappedValueAccessor: unwrap(valueAccessor())
				,valueAccessor: valueAccessor()
				,element: element
				,allBindingsAccessor: allBindingsAccessor
				,viewModel: viewModel
				,bindingContext: bindingContext
			});
		}
	}

	//Simple facade to enable the persistState widget on this element
	//Usage: <input type="checkbox" data-bind="checked: alwaysFixPosition, localPersist=true" />
	ko.bindingHandlers.localPersist = {
		init: function(el, valueAccessor) {
			$(el).persistState();
		}
	}

	//Present a utc date/time in a simple, localized format
	ko.bindingHandlers.simpleFormattedDateTime = {
		init: function(el, valueAccessor) {
			$(el).addClass('datetime')
		}
		,update: function(el, valueAccessor) {
			var val = unwrap(valueAccessor());
			if(null != val)
				$(el).text( moment.utc(val).local().format("YYYY-MM-DD hh:mm A") );
		}
	}

	//simple binder to display milliseconds as a time-remaining string
	ko.bindingHandlers.timeRemaining = {
		update: function(el, valueAccessor) {
			var ms = unwrap(valueAccessor())
			if(!ms || ms < 0) ms = 0;
			var perSecond = 1000, perMinute = 60*perSecond, perHour = 60*perMinute, hours, mins, secs;
			var x = [];
			hours = Math.floor(ms/perHour);
			mins = Math.floor((ms%perHour)/perMinute);
			secs = Math.floor(((ms%perHour)%perMinute)/perSecond);
			if(hours)	x.push(hours, "hr"+(hours>1?"s":""));
			if(mins) 	x.push(mins, "min"+(mins>1?"s":""));
			if(secs) 	x.push(secs, "sec"+(secs>1?"s":""));
			$(el).text( x.length ? x.join(" ") : "0" );
		}
	}

// http://stackoverflow.com/questions/7317907/how-to-add-insert-an-item-into-an-observablearray-at-a-certain-position-with-kno
ko.observableArray.fn.setAt = function (index, value) {
	this.valueWillMutate();
	this()[index] = value;
	this.valueHasMutated();
};

// Identical to ko.computed() except this provides a recalculate method that will force the computed to execute its funciton
// and recalculate dependencies.
// See: http://stackoverflow.com/questions/13769481/knockout-js-force-a-computed-to-run/13769729#13769940
ko.forceableComputed = function(fn, evaluatorFunctionTarget, options) {
	if(!_.isFunction(fn))
		throw "Using only the options parameter not implemented. But you can implement it here.";
	var  dummy = ko.observable()
		,forceDependency = function() {
			dummy();				
			return fn();
		}
		,computed = ko.computed(forceDependency, evaluatorFunctionTarget, options)
		;
	computed.recalculate = function() {
		dummy.notifySubscribers();
	}
	return computed;
};

//https://github.com/SteveSanderson/knockout/issues/502
ko.observableArray.fn.subscribeArrayChanged = function(onAdd, onRemove) {
    onAdd = callbackInvocation(onAdd);
    onRemove = callbackInvocation(onRemove);

    var previous = undefined;
    this.subscribe(function(p) {
        previous = unwrap( p.slice(0) );
    }, undefined, 'beforeChange');

    this.subscribe(function(current) {
        var editScript = ko.utils.compareArrays(previous, unwrap(current) );
        _.each(editScript, function(x){
        	if(x.status === "added") 	return onAdd(x.value);
        	if(x.status === "deleted") 	return onRemove(x.value);
        });
    });
};

ko.updateValuesFromJS = function(target, newvalues) {
	_.each(_.intersection(_.keys(target), _.keys(newvalues)), function (property) {
		ko.isObservable(target[property]) ?
			target[property](newvalues[property]) :
			target[property] = newvalues[property];
	});
}

function evaluateJsonishString(str) {
	var ctx = {res: null};
	with(ctx)
	eval('res = {' + str + '}');
	return ctx.res;
}
// Return a function that will trigger the supplied callback. Callback can be $.Callbacks, any function (including ko.observable)
function callbackInvocation(callback) { 
    if(!callback) return $.noop;
    var fn = callback.fire ? _.bind(callback.fire, callback) : callback;
    return fn;
}

	// Makes ko.computed to be able to evaluate value immediate
	// When computed is depends on another computed KO sometimes does not refresh the value
	ko.forcibleComputed = function (readFunc, context, options) {
		var trigger = ko.observable(),
			target = ko.computed(function () {
				trigger();
				return readFunc.call(context);
			}, null, options);
		target.evaluateImmediate = function () {
			trigger.valueHasMutated();
		};
		return target;
	};

	ko.bindingHandlers.truncatedText = {
		update: function (element, valueAccessor, allBindingsAccessor) {
			var originalText = ko.utils.unwrapObservable(valueAccessor())
			// 20 is a default maximum length
			if (!originalText)
				return;

			var length = ko.utils.unwrapObservable(allBindingsAccessor().maxTextLength) || 20,
				truncatedText = originalText.length > length ? originalText.substring(0, length) + "..." : originalText;
			
			//updating text binding handler to show truncatedText
			ko.bindingHandlers.text.update(element, function () {
				return truncatedText;
			});
		}
	};
});