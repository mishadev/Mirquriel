﻿define(['underscore', 'knockout'], function(_, ko){
	'use strict'

	// Creates an object with read and notation properties. 
	//   range is a zero based array with selected flags: range([false,true,false,true,true])
	//   notation is a string display that combines ranges to pages: notation([1,3-5,9])
	// Both are observables that will be kept in sync.
	return function newRangeNotation(max, defaultRangeNotation) {
		var rangeSeparator = ',',
			sequenceSeparator = '-';

		var range = ko.observableArray(getInitialRange(defaultRangeNotation, createSelectedRange()));

		return {
			range: range
			, notation: ko.computed({
				read: function () {
					var slidePageRanges = [];
					var firstSelectedIndex = null;
					for (var index = 0; index < range().length; index++) {
						var selected = range()[index];
						if (selected && firstSelectedIndex == null)
							firstSelectedIndex = index;
						else if (!selected && firstSelectedIndex != null) {
							slidePageRanges.push(buildPageRange(firstSelectedIndex, index - 1));
							firstSelectedIndex = null;
						}
					};

					if (firstSelectedIndex !== null)
						slidePageRanges.push(buildPageRange(firstSelectedIndex, range().length - 1));

					return slidePageRanges.join(rangeSeparator);
				},
				write:
					function (newVal) {
						range(parseNotation(newVal));
					}
			})
			// Simple shorthand for selecting the full range
			,selectAll: function () { range(createSelectedRange()); }
			,deselectAll: function () { range(createUnselectedRange()); }
			,allSelectedRange: createSelectedRange()
		};

		function buildPageRange(firstIndex, lastIndex) {
			firstIndex++; lastIndex++;
			if (firstIndex === lastIndex)
				return firstIndex.toString();
			if (lastIndex - firstIndex === 1)
				return firstIndex.toString() + rangeSeparator + lastIndex.toString();
			return firstIndex.toString() + sequenceSeparator + lastIndex.toString();
		}

		function parseNotation(notation) {
			if (!_.isString(notation) || !notation.length)
				return;

			var result = _.chain(notation.split(rangeSeparator))
				.map(function (range) {
					return range.trim().split(sequenceSeparator);
				})
				.reduce(function (res, figures) {
					if (figures.length === 1) {
						var figure = +figures[0];

						if (figure && figure <= res.length)
							res[figure - 1] = true;

					} else if (figures.length === 2) {
						var start = +figures[0],
							end = +figures[1];

						if (start && end) {
							var idx = Math.min(start, end);
							while (idx <= Math.max(start, end) && idx <= res.length)
								res[idx++ - 1] = true;
						}
					}
					return res;
				}, createUnselectedRange())
				.value();

			if (!_.isEqual(result, createUnselectedRange()))
				return result;
		}

		function getInitialRange(notation, def) {
			return parseNotation(notation) || def;
		}

		function createSelectedRange() {
			return createRange(true);
		}

		function createUnselectedRange() {
			return createRange(false);
		}

		function createRange(value) {
			return _.range(0, max).map(function () { return !!value; });
		}
	}
})