﻿define(
['knockout', 'sammy', 'apiUrls', 'hierarchyParametersEditor', 'commonParametersEditor'],
function (ko, sammy, api, hierarchyParametersEditor, commonParametersEditor) {
	'use strict';

	return function (model) {
		var _model = {
			availableDatamarts: model.AvailableDataMarts,
			selectedDatamart: ko.observable(model.SelectedDataMart),
			activeEditor: ko.observable(),
			editors: {
				commonParameters: commonParametersEditor(model.SelectedDataMart),
				hierarchyParameters: hierarchyParametersEditor(model.SelectedDataMart)
			}
		};
		var defaultEditor = _.first(_.keys(_model.editors));

		_model.activeEditor(defaultEditor);//set default editor
		_model.selectedDatamart.subscribe(function (datamart) {
			location.href = api.datamartParametersUrlTemplate(datamart);
		});

		var app = sammy(function() {
			this.get('#:tab', function (context) {
				var editor = context.params.tab;

				if (_.has(_model.editors, editor))
					_model.activeEditor(editor);
			});
			this.notFound = function () {
				location.hash = '#' + _model.activeEditor();
			}
		});
		app.run();

		return _model;
	}
});