﻿define(
['jquery', 'knockout', 'underscore', 'parametersEditorBase', 'knockout.mapping', 'apiUrls'],
function ($, ko, _, base, mapping, api) {
	'use strict';

	return function (datamart) {
		var sortingAvailable = true;
		var debounceEvaluateOrder = _.debounce(evaluateOrder, 100);

		var _parametersEditor = base({
			deleteParameter: api.deleteHierarchyParameter,
			saveParameter: api.saveHierarchyParameter,
			getParameterOptions: api.getHierarchyParamOptions
		});

		_.extend(_parametersEditor, { newParameter: newParameter });

		loadParameters();

		return _parametersEditor;

		function loadParameters() {
			api.getHierarchyParameters(datamart)
			.then(function (data) {
				_parametersEditor.parametersContext.loadParameters(data);
				_.each(_parametersEditor.parametersContext.parameters(), function (parameter) {
					_parametersEditor.saveOnAllChanges(parameter);
				});

				_parametersEditor.parametersContext.parameters.subscribe(debounceEvaluateOrder);
			});
		}

		function newParameter() {
			sortingAvailable = false;
			api.newHierarchyParameter({
				DatamartName: datamart,
				ParameterOrder: 1
			}).done(function (newItem) {
				var parameter = _parametersEditor.parametersContext.addParameter(newItem);
				_parametersEditor.saveOnAllChanges(parameter);
				sortingAvailable = true;
			});
		}

		function evaluateOrder(parameters) {
			if (!sortingAvailable) return;
			_.each(parameters, function (param, index) {
				param.ParameterOrder = index + 1;
				_parametersEditor.saveParameter(param);
			});
		}
	}
});