define(['knockout.mapping', 'underscore'], function(mapping, _) {
return function mapSlideSet(ss) {
	return mapping.fromJS(ss, copyIds({
            Params:                 mappingArrayCopyIds(),
            HierarchyParameters:    mappingArrayCopyIds(),
            Slides:                 mappingArrayCopyIds()
        }));
}

function copyIds(currentMapping){ return _.extend(currentMapping||{}, {copy: ['Id', 'SlideId', 'SlideSetId']} ) }
function mappingArrayCopyIds(currentMapping) {
    return _.extend(currentMapping||{}, {create: function(op) { 
        return mapping.fromJS(op.data, copyIds()); 
    } })
}
})