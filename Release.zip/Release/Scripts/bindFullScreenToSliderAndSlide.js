﻿define([
	'jquery', 'underscore', 'fullscreen'
],
function (
	$, _, fullscreen
) {
	'use strict'
	// Full-screen binding module. Takes a config object with selectors, observables and resizerStrategy
	// and sets up full-screen enter and exit handlers to execute when the full-screen state of the provided element is changed.  
	// (Element is optional, defaults to 'document')
	// Use like this: 
	// bindFullScreen.init({
	//    slideResizer: resizer
	//   ,sliderSelector: '.slidesets-viewer #slider'
	//   ,scaleToFitElementSelector: '.slide-view-container'
	//   ,fullScreenChangingCallback: _viewer.isInFullScreenMode
	// });

	
	return {
		init: function (config, element) {
			var sliderSelector = config.sliderSelector
				, scaleToFitElementSelector = config.scaleToFitElementSelector
				, fullScreenChangingCallback = config.fullScreenChangingCallback
				, slideResizer = config.slideResizer;

			var element = element || document,
				previousZoomLevel = null; // keep track of the zoom level for when full-screen mode is exited (restore slide to the same size it was before)

			$(element).bind("fullscreenchange", onFullScreenChange);

			function onFullScreenChange() {
				var fullScreenMode = fullscreen(document);
				if (_.isFunction(fullScreenChangingCallback)) fullScreenChangingCallback(fullScreenMode); // callback to notify about fullScreen state changeing;
				if (fullScreenMode) {
					_.delay(enterFullScreenMode, 100);//IE, Chrome does not recalculate properties immediately. _.defer() not working here
				} else {
					exitFullScreenMode();
				}
			}

			function enterFullScreenMode() {
				previousZoomLevel = slideResizer.slideSize();
				var fittedSize = slideResizer.changeSizeToFitElement(scaleToFitElementSelector);
				$(sliderSelector).slideSizeSlider("setExclusiveScale", fittedSize);
			}

			function exitFullScreenMode() {
				$(sliderSelector).slideSizeSlider("clearExclusiveScale");
				if (previousZoomLevel != null)
					slideResizer.slideSize(previousZoomLevel);
			}
		},
		toggleFullScreen: function (fullScreenElementSelector) {
			var e = $(fullScreenElementSelector)[0],
				state = fullscreen(e);
			fullscreen(e, !state);
		}
	}
});