﻿/*
Adds following behavior:
    Displays multiselect using position: fixed
    Displays multiselect above the button if there is no room below
    Due to fixed position closes multiselect on scroll
*/
define(["jquery", "bootstrap-multiselect"],
    function ($) {

        "use strict";

        var _super = $.fn.multiselect;

        var Multiselect = function (element, options) {

            _super.Constructor.apply(this, arguments);

            this.closeOnScrollHandler = closeOnScroll.bind(this);

            $(".section").on("scroll", this.closeOnScrollHandler);
            $(document).on("scroll", this.closeOnScrollHandler);

        }

        function closeOnScroll() {
            if (this.$ul.is(":visible"))
                this.$button.click();
        }

        Multiselect.prototype = $.extend({}, _super.Constructor.prototype, {
            constructor: Multiselect,

            _super: function () {
                var args = $.makeArray(arguments);
                _super.Constructor.prototype[args.shift()].apply(this, args);
            },

            destroy: function () {
                $(".section").off("scroll", this.closeOnScrollHandler);
                $(document).off("scroll", this.closeOnScrollHandler);
                this._super('destroy');
            }
        });

        $.fn.multiselect = $.extend(function (option, parameters) {

            return this.each(function () {
                var data = $(this).data('multiselect');
                var options = typeof option === 'object' && option;

                $.extend(options, {
                    onDropdownShow: function (event) {
                        var scrollPosition = $(document).scrollTop();
                        var position = this.$button.offset();
                        var leftPosition = position.left - 5;
                        var topPosition = (position.top + this.$button.outerHeight());
                        if ((topPosition + this.$ul.height()) > $(document).height())
                            topPosition -= this.$ul.height() + this.$button.outerHeight();

                        topPosition -= scrollPosition;
                        this.$ul.css({
                            'top': topPosition,
                            'left': leftPosition
                        });
                    }
                });
                // Initialize the multiselect.
                if (!data) {
                    data = new Multiselect(this, options);
                    $(this).data('multiselect', data);
                }

                // Call multiselect method.
                if (typeof option === 'string') {
                    data[option](parameters);

                    if (option === 'destroy') {
                        $(this).data('multiselect', false);
                    }
                }
            });

        }, $.fn.multiselect);

    });