define(['underscore'],
function (_) {
	'use strict';

	//it's sad but http://stackoverflow.com/questions/2775384/detect-when-a-new-property-is-added-to-a-javascript-object
	//so you should use with setItem, getItem methods
	function localStorageWrapper() {
		//basic approach from https://developer.mozilla.org/docs/Web/Guide/API/DOM/Storage#localStorage
		//GM - Note that we have to mark these properties as writeable for them to work with PhantomJs
		// https://github.com/ariya/phantomjs/issues/11856
		var oStorage = {};
		Object.defineProperty(oStorage, "getItem", {
			value: wrapLocalStorage("getItem"),
			writable: true,
			configurable: false,
			enumerable: false
		});
		Object.defineProperty(oStorage, "key", {
			value: wrapLocalStorage("key"),
			writable: true,
			configurable: false,
			enumerable: false
		});
		Object.defineProperty(oStorage, "setItem", {
			value: wrapLocalStorage("setItem"),
			writable: true,
			configurable: false,
			enumerable: false
		});
		Object.defineProperty(oStorage, "length", {
			get: function () { return window.localStorage["length"]; },
			configurable: false,
			enumerable: false
		});
		Object.defineProperty(oStorage, "removeItem", {
			value: wrapLocalStorage("removeItem"),
			writable: true,
			configurable: false,
			enumerable: false
		});

		return oStorage;

		function wrapLocalStorage(property) {
			return _.bind(window.localStorage[property], window.localStorage);
		}
	}

	return localStorageWrapper();
});