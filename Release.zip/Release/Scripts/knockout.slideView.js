define(
['knockout', 'jquery', 'underscore', 'slideRenderer', 'constants', 'knockout.mapping', 'ogre.widgets.slideWidgets'],
function(ko, $, _, newSlideRenderer, constants, mapping) {
	'use strict'

	var  unwrap 		= ko.utils.unwrapObservable
		,thumbScale 	= constants.THUMBNAIL_DEFAULT_HEIGHT / constants.SLIDE_VIEWBOX_HEIGHT
		;

	//Initialize a slideView widget on this element
	//for the parameter provide the slideDefinition to operate on. Will use
	//the slide's thumbnail property by default
	ko.bindingHandlers.slideView = {
		init: function(el, valueAccessor) {
			var slide = mapping.toJS(valueAccessor());
		    $(el).slideView({
                 thumbnail: 	slide.Links.thumbnailHtml
				,html: 			slide.Thumbnail
				,isRepeating:   slide.IsRepeatingSlide
				,scaleBy: 		slide.scaleBy || thumbScale
			});
		}
	};

	//Draw a slide for which the dataset has already been retreived. Expects a viewModel that is
	//  slideDefinition - slide definition to use (as returned from the server)
	//  data - data that slide drawing will use
	//  parameters - parameters that were used to generate data
	//  [pagenum] - page number
	//  [redrawing] - callback, $.Callbacks, or observable - invoked with the redrawing deferred when redrawing starts
	//  [widget, widgetName, scaleBy] - same as for slideView	
	ko.bindingHandlers.drawSlide = {
		init: drawSlideUsingWidget($.fn.slideView)
	}
	ko.bindingHandlers.drawClickableSlide = {
		init: drawSlideUsingWidget($.fn.clickableSlideView)
	}

	function drawSlideUsingWidget(widget) { return function drawSlideUsingWidget(el, valueAccessor) {
		var op = mapping.toJS(valueAccessor());
		if(op.slideInstance)
			op = _.extend({}, op.slideInstance, op);
		_.defaults(op, {
			 slideDefinition: op.slide
		});
		op.widget = widget;
		op.redrawing = _.leftShiftArgs( callbackInvocation(op.redrawing) ); //drop jquery event parameter. The widget's redrawing event will trigger this

		$(el).drawSlide(op);

		ko.utils.domNodeDisposal.addDisposeCallback(el, function () {
			$(el).remove(); //need to avoid widget's memory leaks
		});
	} }

    // Return a function that will trigger the supplied callback. Callback can be $.Callbacks, any function (including ko.observable)
    function callbackInvocation(callback) { 
        if(!callback) return $.noop;
        var fn = callback.fire ? _.bind(callback.fire, callback) : callback;
        return fn;
    }

});