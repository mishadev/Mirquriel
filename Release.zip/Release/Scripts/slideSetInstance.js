define(
['underscore', 'knockout', 'knockout.mapping', 'apiUrls', 'rangeNotation'],
function (_, ko, mapping, api, newRangeNotation) {
	'use strict'

	// Return an object representing the slideSetInstance from a slideSet definition
	// and a parameters object. A slideSetInstance executes data queries, 
	// expands any slideDefinitions that have a repeatableParameter into multiple slide models, and
	// reports any errors.
	//
	// After the exposed loading observable is resoved, the exposed slides() observable will contain an object representing
	// info on the slide rendered. Consider using this with the drawSlide binding/widget.
	//
	// loadInRealtime parameter - If set to true, the exposed slides property will be filled out as loading occurs. While this might allow users 
	// to see results sooner it also results in a frequently shifting slides array as requests for slide data arrive out of order and the array 
	// is re-sorted. Therefore, if the presence of an object is used to trigger drawing of draw-slides, and the index in the array matters (ie it 
	// is used to determine pageNumber) you will get page numbers that reflect where the slide was at the time the pipeline triggered, which
	// might not be its final position. To avoid, leave this value falsy and the slides() array will be filled all in one shot when all loading
	// has completed.
	//
	// showSlidesStartIndex and showSlidesNumber are for server-side printing, where PhantomJS renders just a slideset in an HTML window 
	// as part of the rasterization process.  For very large slidesets, the memory required to render lots (>100) of slides can cause
	// exceptions to be thrown in PhantomJS, so clients may configure OGRE to split server-side slideset-rendering-for-printing
	// into "batches" of slides.  In the client-facing viewer UI, these parameters are not supplied, so the viewer displays all the slides
	// in a slideset.
	//
	// [Happens elsewhere: We can then drop this into an observable (_setViewer.slideSetInstance) and knockout will render it]
	//
	return function slideSetInstance(slideSet, params, loadInRealtime, slideRange, showSlidesStartIndex, showSlidesNumber) {
		//TODO - GM - there are smarter ways to handle the loadInRealtime problem than just deferring to the end.
		//	eg when a slide is added we can check if loading of all preceeding slide definitions has completed and push it

		var loading					= $.Deferred()
			,slides					= ko.observableArray([])
			,numSlideDefinitions	= slideSet.Slides.length
			,redrawingCount			= ko.observable(0)
			,rangeNotation			= newRangeNotation(slideSet.Slides.length, slideSet.DefaultSlideRange);
		var _slideSetInstance = {
			 slides: 			( loadInRealtime ? slides : ko.observableArray([]) ) 
			,redrawingCount:	redrawingCount
			,loading: 			loading
			,isFullyLoaded:		ko.observable(false)
			,redrawingPercent:	ko.computed(redrawingPercent)
			,currentSlideIndex: ko.observable(0)
			,slideRange:		slideRange || rangeNotation.range()
			,currentSlideSet:    slideSet
		};

		_slideSetInstance.slidesToShow = ko.computed(slidesToShow);

		_slideSetInstance.currentSlide = ko.computed(getSlideFromIndex);
		
		_slideSetInstance.nextSlide = ko.computed(moveSlideDirection(1), null, {deferEvaluation: false});
		_slideSetInstance.prevSlide = ko.computed(moveSlideDirection(-1), null, { deferEvaluation: false });
		_slideSetInstance.moveToSlideNumber = function (number) {
			var vector = number - 1 - _slideSetInstance.currentSlideIndex();
			var fn = moveSlideDirection(vector)();
			if (fn)
				fn();
		}


		_slideSetInstance.moveToSlideWithId = moveToSlideWithId;

		if (!loadInRealtime)
			loading.always(function () { _slideSetInstance.slides(slides()); });
		loading.then(function() { _slideSetInstance.isFullyLoaded(true); });
		redrawingCount.subscribe(function (val) {
			if (val === 0) loading.resolve();
		});

		api.getLocalizationData().done(function(result) {
			_.each(slideSet.Slides, function (slide, index) { loadSlide(slide, index, result); });
			redrawingCount.notifySubscribers(redrawingCount());
		});

		return _slideSetInstance;

		///////////////////////////////////////////////////

		function getSlideFromIndex() {
			var pageIndex = _slideSetInstance.currentSlideIndex();
			var currentSlide = _slideSetInstance.slides()[pageIndex] ? _slideSetInstance.slides()[pageIndex] : null;
			if(currentSlide != null)
				_.extend(currentSlide, {
					pageNumber: (pageIndex + 1)
				});

			return currentSlide;
		}

		function moveSlideDirection(vector) {
			return function moveSlideDirection() {
				var newIndex = _slideSetInstance.currentSlideIndex() + vector;
				return _slideSetInstance.slides()[newIndex]
					? function moveNewPage() { _slideSetInstance.currentSlideIndex(newIndex); }
					: null;
			}
		}

		function moveToSlideWithId(slideId, occurence) {
			occurence = (_.isUndefined(occurence) || occurence < 1) ? 1 : occurence;

			var matchingIndices = _.chain(_slideSetInstance.slides())
				.map(function (slide, index) {
					// we must pass along the index in the full array of slides so that we can set the slideset's currentSlideIndex to it later
					return { slideId: slide.slideDefinition.SlideId, index: index };
				})
				.where({ slideId: slideId })
				.pluck('index')
				.value();

			var indexOfSlideToShow = occurence <= matchingIndices.length ? matchingIndices[occurence - 1] : _.last(matchingIndices);
			_slideSetInstance.currentSlideIndex(indexOfSlideToShow);
		}

		function slidesToShow() {
			var start = showSlidesStartIndex > 0 ? showSlidesStartIndex : 0;
			var end = showSlidesNumber > 0 ? showSlidesStartIndex + showSlidesNumber : undefined;

			// this takes advantage of the fact that in Javascript, [1, 2, 3].slice(startIndex, undefined) is the same as [1,2,3].slice(startIndex)
			return _slideSetInstance.slides().slice(start, end);
		}

		function loadSlide(slideDefinition, index, localizationData) {
			if (!_slideSetInstance.slideRange[index])
				return;
			api.getSlideData({slideSetId: _slideSetInstance.currentSlideSet.SlideSetId, slideId: slideDefinition.SlideId}, params)
				.done(function (queryResult) {
					var modelsForSlide = createModels(slideDefinition, queryResult, localizationData); 	//multiple if using repeatable parameters
					_.each(modelsForSlide, _.partial(setAt, slideDefinition.Ordering)); // sort slides into correct order as indicated by 'ordering' property
				})
				.always(trackRequest());
		}

		// createModels ends up being called once for each slide that appears in the final slideSetInstance
		// this is achieved by calling itself recursively if a 'slide' actually represents multiple repeating slides
		// (which is identified by the queryResult being an array rather than a single object)
		function createModels(slideDefinition, queryResult, localizationData) {
			if(_.isArray(queryResult) )	//deconstruct queryResult if its an array by calling back in recursively
				return _.flatten(_.map(queryResult, function(data) {
					 return createModels(slideDefinition, data, localizationData);
				}));

			var slideModel = {
				 instanceId: 	  _.uniqueId('slide-instance-')
				,slideDefinition: slideDefinition
				,slideData: 	  queryResult
				,redrawErrors: 	  ko.observable("")
			};

			if (slideModel.slideData.data)
				_.defaults(slideModel.slideData.data, localizationData); //optionally adds 'text' and 'column' properties with localization data
			return [slideModel];
		}

		// put an individual slideModel in its correctly place in slides, as determined by ordering
		function setAt(ordering, slideModel) {
			var indexToInsertBefore = _.findIndex(slides, function(s){
				return s.slideDefinition.Ordering > ordering;
			});
			if(!~indexToInsertBefore) indexToInsertBefore = slides().length
			slides.splice(indexToInsertBefore, 0, slideModel);
		}

		function redrawingPercent() {
			return Math.round(100 * (1 - redrawingCount() / (numSlideDefinitions||1)));
		}

	    // tracks how many slides are still in the process of being created, keeping count in redrawingCount()
		function trackRequest() {
			redrawingCount( redrawingCount()+1 );
			return function trackRequest() {
				redrawingCount( redrawingCount()-1 );
			};
		}
	}
})