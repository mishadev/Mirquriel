define(['knockout', 'underscore'],
function(ko, _){
'use strict'
//Generate a string name for a report by combining a name with parameters from a paramContext
//Usage:
//    generateReportName({name: "a report", paramContext: paramContext })
//  or
//    generateReportName({name: "a report", parameterDescriptions: ["parameter 1", "parameter 2"] })
return function generateReportName(op) {
	if(!op.name)
		return null;
	var paramContextSuffix = ko.unwrap(op.paramContext) && _.chain(ko.unwrap(op.paramContext).params).invoke('userSelection').compact().pluck('desc').value();
    return _.compact(_.flatten([ko.unwrap(op.name), paramContextSuffix, op.parameterDescriptions])).join(' - ');     
}
});